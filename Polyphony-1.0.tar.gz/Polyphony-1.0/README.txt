Polyphony software is open source and is covered by a GPL license, a copy of which should be included in this distribution.

Polyphony is dependent on many other software packages and databases. Many are optional and allow the calculation of additional properties.
See doc/index.html for help.
