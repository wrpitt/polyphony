#!/usr/bin/env python


import os, glob, sys

def get_user_details() :
    # Get users id, group id and home directory
    home_dir=os.path.expanduser('~')
    uid = os.getuid()
    gid = os.getgid()
    sudo = False    
    if uid == 0 : # run with sudo
        sudo = True
        uid = int(os.getenv("SUDO_UID"))
        gid = int(os.getenv("SUDO_GID"))
    return home_dir, uid, gid, sudo

def setup_config_file(polyphony_data_dir) :
    
    config_file=polyphony_data_dir+"polyphony.cfg"
    print "Setting up config file", config_file

    # insert users polyphony_data_dir path into polyphong.cfg
    file = open(config_file)
    text = file.read()
    file.close()
    file = open(config_file, 'w')
    print "polyphony_data_dir", polyphony_data_dir
    file.write(text.replace('@polyphonydatadir@',polyphony_data_dir))
    file.close()
    
    # Change ownership of data directory and config file to current user from root
    try :
        os.chown(polyphony_data_dir, uid, gid)
        os.chown(config_file, uid, gid)   
    except OSError :
        raise OSError("Unable to change ownership of polyphony data directory to user.")

def install_dependencies() :
    # install dependencies if necessary (only available on ubuntu)
    if os.uname()[3].find("Ubuntu") != -1 :
        print "Ubuntu: trying to install dependencies."
        from subprocess import call
        try :
            return_code = call("aptitude install python python-numpy python-scipy python-matplotlib python-biopython ipython", shell=True)
        except :
            print "Failed to install dependencies."
    else :
        print "Non-Ubuntu os. Please install numpy, scipy, matplotlib, biopython before running this script."

def clean_out_old_version() :
    # Find if already installed
    #
    try :
        import Polyphony
        polyphony_install_directory = Polyphony.__path__[0]
        print "Polyphony found at: ", polyphony_install_directory 
        print "Warning this directory will be removed on typing \"sudo python setup.py install\" and it will be replaced with this version of the software"
        polyphony_installed = True
    except ImportError:
        polyphony_installed = False
        
    # Remove older installation if it exists (only when using sudo for installation)
    #
    if polyphony_installed :
        try: 
            import shutil,string,glob
            shutil.rmtree(polyphony_install_directory)
            print "Removing ",polyphony_install_directory
            path = string.join(polyphony_install_directory.split('/')[:-1],'/')
            egg_files = glob.glob(path+"/Polyphony*")
            if len(egg_files) > 0 :
                for file in egg_files :
                    print "Removing ", file
                    if os.path.isdir(file) :
                        import shutil
                        shutil.rmtree(file)
                    else :
                        os.remove(file)
        except OSError:
            raise OSError("Unable to remove old version of Polyphony.")

def remove_old_manifest() :
    # BEFORE importing distutils, remove MANIFEST. distutils doesn't properly
    # update it when the contents of directories change.
    if os.path.exists('MANIFEST'): os.remove('MANIFEST')

def check_correct_user_status(setup_option, sudo) :
    if setup_option == "build" and sudo == True :
        print "Please run setup.py build without sudo"
        exit(1)
    if setup_option == "sdist" and sudo == True :
        print "Please run setup.py sdist without sudo"
        exit(1)

def get_setup_option(args) :
    if len(args) > 1 :
        try :       
            setup_option = args[args.index('install')]
        except :
            try :
                setup_option = args[args.index('build')]
            except :
                try :
                    setup_option = args[args.index('sdist')]
                except :
                    print "Set up option not recognised. Should be build, install or sdist"
                    exit(1)
    return setup_option

def check_for_existing_config_file(polyphony_data_dir) :
    """
    Look for local config file from previous install. We don't necessarily want to overwrite this everytime a new version of Polyphony is installed.
    """
    config_file=polyphony_data_dir+"polyphony.cfg"
    config_file_exists = os.path.exists(config_file)
    if config_file_exists :
        print "Existing polyphony.cfg found in ", polyphony_data_dir
    return config_file_exists
    
## main program ##

setup_option = get_setup_option(sys.argv)
print "Option specified :", setup_option
home_dir, uid, gid, sudo = get_user_details()
check_correct_user_status(setup_option, sudo)

## location of Polyphony data directory can be edited prior to installation ##   
polyphony_data_dir=home_dir+'/Polyphony/'
## ###

# If an old config file exists, leave it alone. Otherwise install a fresh copy. 
config_file_exists = check_for_existing_config_file(polyphony_data_dir)
if config_file_exists :
    new_data_files = []
else :
    new_data_files = [(polyphony_data_dir, ['polyphony.cfg'])]

if setup_option == "build" :
    remove_old_manifest()
    
if setup_option == "install" :
    clean_out_old_version()
    
    #if sudo :
    #    install_dependencies()
    
if setup_option == "sdist" :
    remove_old_manifest()

from distutils.core import setup
setup(name='Polyphony',
    version = '1.0',
    description='Python software for analysing protein structure ensembles',
    author='Will Pitt',
    author_email='will.pitt@ucb.com',
    url='http://wrpitt.bitbucket.org/polyphony/',
    packages=['Polyphony'],
    package_dir={'Polyphony': 'src/lib'},
    data_files=new_data_files,
    scripts = glob.glob('src/scripts/*.py'),
    requires=['NumPy', 'SciPy', 'biopython', 'ipython', 'matplotlib']
    )

if setup_option == "install" :
    setup_config_file(polyphony_data_dir)

