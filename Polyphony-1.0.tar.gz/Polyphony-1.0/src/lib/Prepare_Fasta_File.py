"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Bio.Alphabet import ProteinAlphabet
#from Bio.Align.Generic import Alignment# obsolete in later versions of Biopython
from Bio.Align import MultipleSeqAlignment
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
from Bio.PDB import PDBParser
from Bio import SeqIO, AlignIO
from Polyphony.Residues import Residue_Array_Base
from Polyphony.Utils import ids_from_id, run_silently, to_one_letter_code


import os, re, urllib2, difflib, glob, shutil, string

class Prepare_Input_Data(object) :

    """
    Class bringing together functions that can be used to prepare a fasta file, with sequences made up from related pdb files. Provides functionality for the identification of homologs using RCSB sequence clusters. Downloads pdb files if necessary. Pdb files and processed individual pdb chain files are stored the "pdbs" and "chains" subdirectory of the data directory specified in polyphony.cfg. Local pdbs can also be used. For these new pdb-like codes are generated and a filename, code lookup table generated. If an alignment file is pregenerated (e.g. using a structural alignment program) then the check_alignment_file function can be used that the sequences derived from the pdb files match.
    """
    
    def __init__(self, CONFIG) :
        self.config = CONFIG
        self.check_directories_exist()
        
    def check_directories_exist(self) :
        """
        All output is stored in a directory tree whose path specified in the polyphony.cfg (data). All pdb files are stored
        in data/pdbs and cleaned chain files (one per chain, no ligands, passed through Biopython PDB read and write) are
        stored in data/chains. This function checks that these directories exist and if not, creates them.
        """
        data_directory = self.config.get('directories','data')
        if not os.path.isdir(data_directory): 
           os.mkdir(data_directory)
           
        pdb_directory = data_directory+"pdbs"
        if not os.path.isdir(pdb_directory): 
           os.mkdir(pdb_directory)
           
        chain_directory = data_directory+"chains"
        if not os.path.isdir(chain_directory): 
           os.mkdir(chain_directory)     
    
    def get_sequences(self, pdb_chain_list, padded = True, update = False) :
        """
        Get sequences for each of pdb chains in list. This could involve downloading the pdb files from the web.
        If update is true then the sequence will be extracted from each pdb file, even if the sequences was already recorded
        on a previous occasion.
        """
        sequences={}
        for chain in pdb_chain_list :
            residue_array = Residue_Array_Base(chain_id=chain, config=self.config, update=update)
            if residue_array.length == 0 :
                continue
            if padded :
                sequences[chain] = residue_array.get_padded_sequence()
            else :
                sequences[chain] = residue_array.get_sequence()
        return sequences
        
    def write_fasta_file(self, sequences, fasta_filename):
        """
        Create a fasta alignment file containing padded sequences for each of the chains in
        the inputted list. If all chains are for the same protein then no alignment should
        be necessary.
        """
        proteinAlphabet = ProteinAlphabet()    
        unaligned = MultipleSeqAlignment([],alphabet=proteinAlphabet)
        
        # Create alignment from sequences
        max_length = max([len(sequences[i]) for i in sequences])
        sequence_list = []
        
        ids = sequences.keys()
        
        # Sort ids by model number
        model_nums = [ids_from_id(id)[1] for id in ids]
        if model_nums.count(None) == 0 :
            ids = sorted(ids, key=lambda id: int(ids_from_id(id)[1]))
        print ids
        for chain in ids :
            seq = sequences[chain]
            # Add '-'s to C-termini to make them all the same length
            seq += "".join(["-" for i in range(len(seq),max_length)])
            seqrec = SeqRecord(Seq(seq, proteinAlphabet), id=chain)
            unaligned.append(seqrec)

        # Write to a fasta format file
        fa_file_handle = open(fasta_filename,"w")
        SeqIO.write(unaligned,fa_file_handle,"fasta")
        fa_file_handle.close()

    def parse_cluster_xml(self, xml) :
        """
        Extract pdb code and chain id's from a RCSB sequence cluster report XML e.g.
        http://www.pdb.org/pdb/rest/sequenceCluster?cluster=95&structureId=1m48.A
        """
        # Written by Lorenzo Palmieri and Will Pitt
        chain_list = []
        xml = xml.split('\n')
        for line in xml :
            if line == "" :
                break
            if re.search("\<pdbChain",line) :
                row = line.replace("\""," ").replace("."," ").split()
                pdb_id = row[2] 
                chain_id = row[3] 
                chain_list.append(pdb_id+"_"+chain_id) 
        return chain_list
        
    def get_similar_chain_ids(self, chain_id,similarity) :
        """
        Use RCSB RESTful service to download identities of pdbs of proteins with similar sequences. Sequence
        similar clusters are precalculated for certain percentage sequence identity cutoffs. Return list of
        pdbcode_chaincode strings.
        """
        rest_server = self.config.get('websites','pdb_rest')
        generic_url = rest_server+"sequenceCluster?cluster=%s&structureId=%s.%s"
        pdb_code, model_no, chain_letter = ids_from_id(chain_id)
        url = generic_url % (similarity, pdb_code, chain_letter)
        print url
        f = urllib2.urlopen(url)
        xml = f.read()
        chain_list = self.parse_cluster_xml(xml)
        return chain_list
    
    def create_fasta_file_by_similarity(self, chain_id, similarity, update=False) :
        """
        Download RCSB sequence cluster, download pdb files if necessary,
        and create a sequence alignment file in fasta file format. Sequence alignment
        will be needed unless all chains are of the same protein
        """
        chain_list = self.get_similar_chain_ids(chain_id,similarity)
        if len(chain_list) == 0 :
            print "!! No chains found. Try again."
            exit()
        print "Chains in specified sequence similarity cluster = ", chain_list
        sequences = self.get_sequences(chain_list, padded=True, update=update)
        output_filename = "clust_"+chain_id+"_"+similarity+".fasta"
        self.write_fasta_file(sequences,output_filename)
        
    def _write_pdb_chain_file(self, pdb_obj):
        """
        Write out protein chain in separate file
        """
        chain_path = self.config.get('directories','data')+"chains/"
        filename = chain_path+self.chain+".pdb" 
        # if file does not exist, create it
        pdb_code, model_no, chain_letter = ids_from_id(self.chain)
        if os.access(filename,os.F_OK) == False or os.path.getsize(filename) == 0 :
            io=PDBIO()
            io.set_structure(pdb_obj)
            io.save(filename, SelectChain(chain_letter))

    def generate_fake_code(self, last_code) :
        """
        Generate a new fake pdb code by generating sequential base 36, 4 digit numbers and add a 'F' on the end. 
        """
        BASE36 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

        # Convert last code to integer
        last_int = int(last_code[:4], 36)
        
        # Add one to get new integer for code
        new_int = last_int + 1
        if new_int > int('zzzz', 36) :
            raise OverflowError("Maximum fake pdb codes ("+str(int('zzzz', 36))+") exceeded")
            
        # Convert integer to base 36 number
        new_code = ""
        while new_int > 0: 
            digit = new_int % 36 
            new_code = BASE36[digit] + new_code
            new_int /= 36
        
        # Pad out with 0's
        new_code = ("%4s" % (new_code)).replace(' ','0')
        
        # Add F to indicate fake code
        new_code += 'F'
        
        return new_code
    
    def fake_code_from_filename(self, filename) :
        """
        Generate a fake pdb code from a file name. Any underscores will be replaced with hyphens.
        """
        new_code = filename.split('/')[-1].split('.')[0]
        new_code = new_code.replace('_','-')
        new_code = string.upper(new_code)
        return new_code     
        
    def read_existing_fake_codes(self) :
        """
        Read list of existing fake pdb codes already assigned and stored in a file in the Polyphony data directory
        """
    
        own_pdb_code_lookup_file = self.config.get('files','pdb_code_lookup')
        
        # Read in any existing file, code combinations
        fake_pdb_codes = {}
        last_code = "0000F"
        if not os.path.isfile(own_pdb_code_lookup_file) :
            # file doesn't exist, no previous pdb files from directories read in
            lookup_file = open(own_pdb_code_lookup_file, "w")
        else :
            lookup_file = open(own_pdb_code_lookup_file, "r+")
            for line in lookup_file :
                if line[0] != '#' :
                    line_list = line.split(',')
                    if len(line_list) == 2 :
                        code = line_list[0].strip()
                        filename = line_list[1].strip()
                        fake_pdb_codes[filename] = code
                        last_code = code
        lookup_file.close()

        return fake_pdb_codes, last_code, lookup_file
    
    def add_fake_code_to_lookup_file(self, new_code, new_filename) :
        """
        Add new fake code code to lookup file in Polyohony data directory
        """
        own_pdb_code_lookup_file = self.config.get('files','pdb_code_lookup')
        if not os.path.isfile(own_pdb_code_lookup_file) :
            # file doesn't exist, no previous pdb files from directories read in
            lookup_file = open(own_pdb_code_lookup_file, "w")
        else :
            lookup_file = open(own_pdb_code_lookup_file, "a")
        lookup_file.write(new_code+", "+new_filename+'\n')
        lookup_file.close()
    
    def get_fake_code(self, file, use_existing_names=True) :
        """
        Create new fake pdb code for pdb format file, if that file has not been seen before. If use_existing_names is set True then the new code will be taken from the filename, after replacing underscores with hyphens.
        """
        fake_pdb_codes, last_code, lookup_file = self.read_existing_fake_codes()
        full_path = os.path.abspath(file)
        if full_path in fake_pdb_codes :
            return fake_pdb_codes[full_path], False
        else :
            if use_existing_names :
                new_code = self.fake_code_from_filename(file)
                if new_code in fake_pdb_codes.values() :
                    raise RuntimeError("Filename "+file+" has already been used in a different directory. Please rename or remove it from ~/Polyphony/pdb_code_lookup.txt and try again.") 
            else :
                new_code = self.generate_fake_code(last_code)
            self.add_fake_code_to_lookup_file(new_code, full_path)
            return new_code, True        
            
    def store_pdb_file(self, code, file, update) :
        """
        Store pdb file in Polyphony data directory for future use.
        """
        pdb_path = self.config.get('directories','data')+"pdbs/"
        new_filename = pdb_path+code+".pdb"
        print "new_filename", new_filename
        if update or not os.path.isfile(new_filename) :
            # copy to central pdb file directory
            shutil.copy(file, new_filename)
    
    def create_fasta_file_from_pdbs(self, directory, use_existing_names, update, models) :
        """
        Create a fasta alignment from a set of pdb files in a given directory. Fake 5 letter PDB codes will be assigned to each structure and a filename - pdb code lookup file created. Files to be used end have the pdb extension. Assumes that all chains in all files are for homologous (alignable) proteins. Any files from the PDB will also be reassigned a code on the assumption that they may differ from the original.
        """
                    
        # Central storage area for pdb files to be used by Polyphony
        parser=PDBParser()
        sequences={}
        
        # For each pdb file in directory, create fake pdb code, write to central directory, extract chains, write them to the central directory and create fasta file from sequences. 
        for file in glob.glob(directory+"/*.pdb") :
                        
            # Create fake pdb code, write to central directory
            try :
                code, new_code = self.get_fake_code(file, use_existing_names)
            
            except RuntimeError :
                print file," not included!"
                continue
            
            # read in structure
            print file
            structure=parser.get_structure(code, file)

            # extract sequence from each chain
            if not models :
                # Store pdb file for each separate model in data directory for future use
                print code, new_code, file
                self.store_pdb_file(code, file, update)
                # Extract sequence for each chain
                for chain in structure[0] :
                    chain_id = code+"_"+chain.id
                    print "chain_id", chain_id
                    try :
                        residue_array = Residue_Array_Base(chain_id=chain_id, config=self.config, update=update)
                    except Exception, e :
                        if e.args[0] == "No residues" :
                            continue
                        else :
                            raise e
                    sequences[chain_id] = residue_array.get_sequence()
                    
            # extracts all chains from all models
            else :
                raise NotImplementedError
                #for imod in range(len(structure)) :                    
                #    # Store pdb file for each separate model in data directory for future use
                #    pdb_code = code + "_" + str(imod)
                #    file = pdb_code+str(imod)+".pdb"
                #    self.store_pdb_file(pdb_code, file, update)
                #
                #    for chain in structure[imod] :
                #        if chain.id == 0 :
                #            chain_id = pdb_code+"_"
                #        else :
                #            chain_id = pdb_code+"_"+chain.id
                #        residue_array = Residue_Array_Base(chain_id=chain_id, config=self.config, update=update)
                #        if residue_array.length == 0 :
                #            continue
                #        sequences[chain_id] = residue_array.get_sequence()
                    
        output_filename = "dir"+os.path.realpath(directory).replace('/','_')+".fasta"
        self.write_fasta_file(sequences,output_filename)
        
    def create_fasta_file_from_pdb(self, filename, prefix, mrange, update) :
        """
        Create a fasta alignment from a single multimodel pdb file which has previously been split into individual files named prefixI.pdb where I is the model number starting with zero. A fake 5 letter PDB codes will be assigned to each structure and a filename - pdb code lookup file created. Files to be used end have the pdb extension. 
        """
                    
        # Central storage area for pdb files to be used by Polyphony
        parser=PDBParser()
        sequences={}
        
        # Create fake pdb code, write to central directory
        code, new_code = self.get_fake_code(filename)
        
        # Selected range
        if mrange == None :
            mrange = range(len(glob.glob(prefix+"*.pdb")))
        else :
            mrange = range(mrange[0], mrange[1], mrange[2]) 
                
        # extracts all chains from all models
        for imod in mrange :
            file = prefix+str(imod)+".pdb"
            # read in structure
            pdb_code = code + "_" + str(imod)
            print pdb_code, file
            #structure = run_silently(parser.get_structure, pdb_code, file)
            structure = parser.get_structure(pdb_code, file)
            # Store pdb file for each separate model in data directory for future use
            self.store_pdb_file(pdb_code, file, update)
            for chain in structure[0] :
                print "chain id", chain.id, chain
                if chain.id == 0 :
                    chain_id = pdb_code+"_"
                else :
                    chain_id = pdb_code+"_"+chain.id
                residue_array = Residue_Array_Base(chain_id=chain_id, config=self.config, update=update)
                if residue_array.length == 0 :
                    continue
                sequences[chain_id] = residue_array.get_sequence()
                    
        output_filename = filename.split('.')[0]+".fasta"
        self.write_fasta_file(sequences, output_filename)

    def check_alignment_file(self, alignment_filename, update=False) :
        """
        Use provided sequence alignment file. Download pdbs (if necessary) and check sequences correspond exactly. Sequence ids
        must be in the form pdbcode(4)_chainletter(1)
        """
        file_extension = alignment_filename.split('.')[-1]
        aligned = AlignIO.read(open(alignment_filename), file_extension)
        # ensure that the id is pdbcode(4)_chainletter(1). Fasta files from Jalview have the residue range appended to the id
        
        # Check ids are correct format
        num_problem_ids = 0
        chain_list = []
        for seq in aligned :
            if seq.id[-2] != "_" :
                print "Sequence id ", seq.id, " not in correct format"
                num_problem_ids += 1
                continue
            chain_list.append(seq.id)
            
        if num_problem_ids > 0 :
            print "!!! All sequence ids must have form pdbcode_chainletter e.g. 1p38_A"
            exit(1)
        
        if len(chain_list) < 2 :
            print "!!! Less than 2 sequences found."
            exit(1)
            
        # Write fasta file from pdb files using ids found in provided alignment file
        pdb_sequences = self.get_sequences(chain_list, padded=False, update=update)
        #temp_filename = self.config.get('directories','tmp')+"temp.fasta"
        #self.write_fasta_file(sequences,temp_filename)
        
        # Check sequences are identical in provided file and one created from pdb file using biopython
        #unaligned = AlignIO.read(open(temp_filename), "fasta")
        aligned_list = list(aligned)
        num_diffs = 0
        for seq in aligned_list :
            pdb_sequence = pdb_sequences[seq.id].replace('-','')
            input_sequence = str(seq.seq).replace('-','')
            
            # If difference is found, highlight changes
            if pdb_sequence != input_sequence :
                num_diffs += 1
                #d = difflib.Differ()
                #comparison = list(d.compare(pdb_sequence,input_sequence))
                #pdb_diff = ""
                #input_diff = ""
                #for i in comparison :
                #    if i[0] == ' ' :
                #        pdb_diff += ' '
                #        input_diff += ' '
                #    elif i[0] == "-" :
                #        pdb_diff += '^'
                #    elif i[0] == "+" :
                #        input_diff += '^'
                print seq.id
                print "pdb  ", pdb_sequence
                #print "     ", pdb_diff
                print "input", input_sequence
                #print "     ", input_diff
            
        # No mercy. No changes will be tolerated !!
        if num_diffs > 0 :
            print "Please fix these differences before continuing to use Polyphony"
        else :
            print "Sequences all match those found the pdb files. This alignment file is compatible with Polyphony software"
                
        return aligned

        

    

