"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Utils import Calculate_Write_Read, print_timing, ids_from_id, to_one_letter_code
from Polyphony.Property_Arrays import Structure_Property_Array, Structural_Alignment_Property_Array

from Bio.PDB import Select, PDBList, PDBParser, PDBIO
import string, os, numpy, itertools, urllib2

class SelectChain(Select):
    """
    Selects specified chain and rejects unrecognised amino acids or ligands. Used with Bio.PDB selection mechanism.
    """
    def __init__(self,chain_name = " ", model_no = None) :
        self.model_no = model_no
        self.chain_name = chain_name
        
    def accept_model(self, model) :
        """
        Select model if specified
        """
        if self.model_no != None :
            return model.id == self.model_no
        else :
            return True

    def accept_chain(self, chain):
        """
        Specified chain == selected chain ?
        """
        #if chain.id==self.chain_name or chain.id == ' ':
        if chain.id==self.chain_name :
            return True
        else:
            return False

    def accept_residue(self, residue):
        """
        Residue OK? Exclude waters, residues with no calpha, and residues with numbering less than 1
        """
        CA_missing = False
        try:
            CA = residue["CA"].get_coord()
        except:
            CA_missing = True
        resnum = residue.id[1]
        if not CA_missing and residue.id[0]!='W' and to_one_letter_code.has_key(residue.get_resname().upper()) and resnum > 0:
            return True
        else:
            return False
        
    def get_residues(self, chain) :
        """
        Return list of acceptable residues
        """
        residues = []
        for residue in chain.get_iterator() :
            if self.accept_residue(residue) :
                residues.append(residue)
        return residues

class Residue_Array_Base(Calculate_Write_Read) :
    """
    Object to collect and store on disk per residue information for a protein chain that is part of a sequence alignment. Saves parsing pdb files (slow) every time the information
    is required.
    """
    
    data_dim = 2                    # 2 dimensional data i.e. 2 value per residue: type and number
    data_type = int                 # residue type and number are stored as integers
    dim_names = ["residue type", "residue number"]
    data_directory = "residues"     # directory where calculated results are stored
    padding = 0                     # number of residues to mask out either side of gaps and at termini
    
    single_letter_residue_codes = "ACBEDGFIHKMLNQPSRTWVYXZ"
    
    def __init__(self, chain_id, config, update = False) :
        """
        Extract sequence from a Bio.AlignIO object and index number
        """
        self.chain = chain_id
        self.config = config
        self.update = update
        self.data = Calculate_Write_Read.__init__(self, self.chain, update)
        self.length = len(self.data)

    def _res2idx(self, single_letter_residue_code) :
        """ convert from single letter residue code to index number """
        return self.single_letter_residue_codes.find(single_letter_residue_code)
        
    def _idx2res(self, index_number) :
        """ convert from index number residue code to single letter """
        return self.single_letter_residue_codes[index_number]
    
    def get_sequence(self) :
        """
        Return string containing amino acid sequence of chain
        """
        return "".join([self._idx2res(i) for i in self.data[:,0]])
        
    def max_resnum(self) :
        """
        Return the highest residue number
        """
        return max(self.data[:,1])
        
    def get_residue_numbers(self) :
        """
        Return array of pdb residue numbers in chain
        """
        return self.data[:,1]
        
    def get_padded_sequence(self):
        """
        Fills out sequence with "-" instead of missing residues. Returns a string.
        """
        current_aa = 1
        padded_sequence = ""
        for aa in self.data :
            resNam = aa[0]
            resNum = aa[1]
            if current_aa < resNum  :
                # assume large sequence discrepency is not real
                #if not((resNum - current_aa) > 100 and current_aa != 1) :
                for fill in range(current_aa, resNum) :
                    padded_sequence += "-"
            padded_sequence += self._idx2res(resNam)
            current_aa = resNum + 1
        return padded_sequence

    def find_discontinuous_residues(self):
        """
        Returns list of residue indices where the previous residue number != current residue number minus 1
        """
        breaks = []
        for i in range(1,self.length) :
            if self.data[i][1] - self.data[i-1][1] > 1 :
                breaks.append(i)
        return breaks

    def _calculate(self) :
        """
        Extract residue names and numbers and store in an array.
        """
        pdb_code, model_no, chain_letter = ids_from_id(self.chain)
        pdb_obj = self._read_in_pdb(pdb_code)
        try :
            chain_obj = pdb_obj[0][chain_letter]
        except :
            print "!! Error loading "+pdb_code+" chain "+chain_letter
            print "please check the RCSB website and the ftp server at", self.config.get('websites','pdb_ftp')
            print "remove this structure from the alignment if necessary."
            exit(1)
        
        residue_array = self._create_array(chain_obj)
        if len(residue_array) == 0:
            print "!! No recognised residues in "+pdb_code+" chain "+chain_letter
            raise Exception("No residues")
        else :
            self._write_pdb_chain_file(pdb_obj, chain_letter)

        return residue_array

    def _write_pdb_chain_file(self, pdb_obj, chain_letter):
        """
        Write out protein chain in separate file
        """
        chain_path = self.config.get('directories','data')+"chains/"
        filename = chain_path+self.chain+".pdb" 
        # if file does not exist or update == True, create it
        if os.access(filename,os.F_OK) == False or os.path.getsize(filename) == 0 or self.update :
            io=PDBIO()
            io.set_structure(pdb_obj)
            io.save(filename, SelectChain(chain_letter))
                
    def _read_in_pdb(self, pdb_id) :
        """
        Check that the pdb file already exists. If not, download it from an FTP site. Saves downloaded file
        for future use and returns Bio.PDB object.
        """
        # Create standard filename
        pdb_ext = ".pdb"
        pdb_path = self.config.get('directories','data')+"pdbs/"
        pdb_id = string.upper(pdb_id)
        pdb_file = pdb_path+pdb_id+pdb_ext

        # if file does not exist, download it
        if os.access(pdb_file,os.F_OK) == False :
            print "file not found : "+pdb_file

            #  download file
            pdb_ftp_server = self.config.get('websites','pdb_ftp')
            pdbl=PDBList(server=pdb_ftp_server)
            try :
                pdbl.retrieve_pdb_file(pdb_id, pdir=pdb_path)
            except urllib2.HTTPError :
                pass

            # change case and extension if necessary
            downloaded_file = pdb_path+"pdb"+string.lower(pdb_id)+".ent"

            # check file was created
            if os.access(downloaded_file,os.F_OK) == False :
                print "Failed to find file locally or on FTP site for : "+pdb_id
                return 
            
            os.rename(downloaded_file,pdb_path+pdb_id+pdb_ext)


        # Create Bio.PDB structure object
        pdbParser=PDBParser(PERMISSIVE=1)
        pdb_obj = pdbParser.get_structure(pdb_id, pdb_file)
        return pdb_obj
    
    def _create_array(self, chain_obj) :
        """
        Extract allowed residues from chain, convert to index numbers and save in an array.
        """
        selector = SelectChain()
        residues = selector.get_residues(chain_obj)
        residue_info = []
        for residue in residues :
            resnam=residue.get_resname().upper()
            resCode = to_one_letter_code[resnam]
            resNum = residue.id[1]
            residue_info.append(self._res2idx(resCode))
            residue_info.append(resNum)
        data = numpy.ma.array(residue_info, self.data_type)
        data.shape = len(residue_info)/2,2
        data.mask = False
        return data

class Unaligned_Residue_Array(Calculate_Write_Read) :
    """
    Class to generate and store all residues in a alignment file but without gaps
    """

    data_directory = "unaligned_residue_arrays"   # directory where calculated results are stored
    data_file_extension = ".npy"           # extension of data files

    def __init__(self, structural_alignment, update=False) :
        self.id =  structural_alignment.id
        self.structural_alignment = structural_alignment
        self.config = structural_alignment.config
        self.data = Calculate_Write_Read.__init__(self, self.id, update)
        
    def _calculate(self) :
        """
        Take single sequence/structure chain property arrays and put them into a single multiple unaligned sequence array
        """
        residue_lists = []
        ids = self.structural_alignment.ids()
        self.lengths = []
        for id in ids :
            res_arr = Residue_Array_Base(chain_id=id, config=self.config)
            residue_lists.append(res_arr.data)
            self.lengths.append(res_arr.length)

        self.length =  max(self.lengths)
        self.size = self.structural_alignment.size()
        self.data_dim = Residue_Array_Base.data_dim
        self.data_type = Residue_Array_Base.data_type

        # Create masked array to hold data
        data = numpy.ma.zeros(self.size*self.length*self.data_dim,self.data_type)
        data.shape = self.size, self.length, self.data_dim
        data.mask = True # mask all positions by default
        
        # Put list values into masked array
        for i in range(self.size) :
            ilen = self.lengths[i]
            data.data[i,0:ilen] = residue_lists[i]
            data.mask[i,0:ilen] = False

        return data
    
    def max_resnum(self) :
        """
        Return the largest residue number amoungst all the sequences
        """
        return numpy.max(self.data[:,:,1])
    
    def get_length(self) :
        """
        Return the maximum length of any sequence in the array 
        """
        return self.data.shape[1]

class Residue_Array(Structure_Property_Array, Residue_Array_Base) :
    """
    Normal property array to be constructed from a line in a sequence alignment file
    """

    def __init__(self, alignment, alignment_index, update=False) :
        self.chain = alignment.alignment[alignment_index].id
        self.config = alignment.config
        self.update = update
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)      
        self.length = len(self.data)

class Residue_Alignment_Array(Structural_Alignment_Property_Array) :
    """
    Class for calculating (or reading) sequences and gaps for each protein chain in a given alignment. Does this by creating a Residue_Array for each chain. 
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> res_array = Residue_Alignment_Array(aligned, update=False)

    """

    data_directory = "residue_arrays"   # directory where calculated results are stored
    data_file_extension = ".npy"        # extension of data files
    
    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, Residue_Array, update)    

    def calculate_distance_matrix(self, all_mask=False) :
        """
        Sequence dissimilarity in terms of percentage sequence difference 
        """
        similarity_mat = self.get_percent_sequence_identity_matrix(all_mask)
        disimilarity_mat = 100.0 - similarity_mat
        return disimilarity_mat
            
    def get_percent_sequence_identity(self, iseq, jseq, all_mask=False) :
        """
        Calculate sequence identity percentage between ith and jth sequence. Percentage is 100.0 * sum identical residues / num positions without gaps in either sequence.  
        """
        seq_identity = self.data[iseq,:,0] == self.data[jseq,:,0]
        seq_identity.mask |= all_mask
        num_unmasked = self.length - numpy.sum(seq_identity.mask)
        if num_unmasked > 0 :
            return 100.0 * numpy.sum(seq_identity) / num_unmasked
        else:
            return 0.0
        
    #@print_timing
    def get_percent_sequence_identity_matrix(self, all_mask=False) :
        """
        return a 2d numpy array of sequence identity precentages
        """
        print "Calculating percent identity matrix for alignment of size", self.size, "x", self.length

        pc_mat = numpy.identity(self.size) # matrix with 1.0 on diagonal
        
        # Iterator to all sequence combinations
        pairs = itertools.combinations(self.data,2)
        
        # Function to calculate pairwise mean sequence identity (gaps are masked)
        percent_id = lambda x: numpy.mean(numpy.equal(x[0],x[1]))

        # Calculate all pairwise identities
        pcs = itertools.imap(percent_id, pairs)
        
        # Matrix row,col indices for upper trangle
        indices = itertools.combinations(range(self.size),2)

        # Fill in upper triangle
        for i,j in itertools.izip(indices,pcs) :
            pc_mat[i] = j

        # Copy to lower triangle
        pc_mat += numpy.triu(pc_mat,1).T
        
        # Convert to percentage
        pc_mat *= 100.0
                
        return pc_mat
   
    def cluster_by_sequence_identity(self, cut_off = 90) :
        """
        return list of lists of ids where all chains within a sublist have sequence identity percentages above the cut_off
        """
        identity_mat = self.get_percent_sequence_identity_matrix()

        clusters = []
        for i in range(0, self.length-1) :
            for j in range(i+1, self.length) :
                if identity_mat[i,j] > cut_off :
                    # pair are close enough so create new combined cluster
                    
                    # Find existing cluster membership for pair
                    c0 = c1 = set()
                    for k in range(len(clusters)) :
                        if i in clusters[k] :
                            c0.add(k)
                        if j in clusters[k] :
                            c1.add(k)
                    
                    # Update list of clusters 
                    new_cluster = set((i,j))
                    c0c1 = set.union(c0,c1)
                    for k in c0c1 :
                        new_cluster.add(clusters[k]) # add existing cluster to new cluster
                        clusters.remove(clusters[k]) # remove existing cluster
                    clusters.append(new_cluster)
                
        # convert from list of sets to list of lists
        clusters = [list(i) for i in clusters]
        
        
        ## Find linear order by descending percentage sequence identity 
        #sorted = numpy.argsort(identity_mat.flatten())
        #sorted = sorted[::-1]
        #
        ## Create list of unique pairs of sequence indices where %id > cutoff 
        #pairs = [[i/self.size,numpy.mod(i,self.size)] for i in sorted]
        #pairs_above_cutoff = [i for i in pairs if identity_mat[i[0],i[1]] > cut_off and i[0] < i[1]]
        #
        ## Cluster all sequence ids together by single linkage
        #clusters = []
        #for pair in pairs_above_cutoff :
        #    #c0 = c1 = -1
        #    c0 = c1 = set()
        #    for i in range(len(clusters)) :
        #        if pair[0] in clusters[i] and pair[1] in clusters[i] :
        #            # both already in cluster
        #            c0.add(i)
        #            c1.add(i)
        #        if pair[0] in clusters[i] :
        #            # first structure is already in a cluster
        #            c0.add(i)
        #        elif pair[1] in clusters[i] :
        #            # second structure is already in a cluster
        #            c1.add(i)
        #    if c0 == c1 == set() :
        #        # Neither of pair is already in a cluster so create new cluster to contain them
        #        clusters.append(set(pair))
        #    else :
        #        # Remove original clusters that either of pair belonged to and create one combined new one
        #        new_cluster = set(pair)
        #        c0c1 = set.union(c0,c1)
        #        for i in c0c1 :
        #            new_cluster.add(clusters[i])
        #            clusters.remove(clusters[i])
        #        clusters.append(new_cluster)
        #        
        ## convert from list of sets to list of lists
        #clusters = [list(i) for i in clusters]
        #
        ## remove duplicate clusters (not sure how this can happen !)
        ##clusters = dict((x[0], x) for x in clusters).values()
            
        return clusters
    
    def calculate_variability(self, sliding_window=1) :
        """
        Variability is the number of different residue types divided by number of non-gapped positions as a percentage, optionally averaged over sliding window. Variability
        is this number standardised. 
        """
        # Count number of residue types per alignment position
        counts = numpy.zeros(self.length)
        for i in range(self.length) :
            counts[i] = numpy.sum(numpy.bincount(self.data[:,i,0].compressed())>0)
        
        # variability is number of different residues divided by number of non-gapped position as a percentage
        num_non_gaps = self.size - numpy.sum(self.data.mask[:,:,0], axis = 0)
        var = (100.0 * counts)/ num_non_gaps

        # Calculate sliding window average
        if sliding_window > 1 :
            self.variability = numpy.zeros(self.length)
            window_index = self.get_sliding_window_index(sliding_window)
            self.variability[sliding_window/2:self.length-sliding_window/2] = numpy.average(var[window_index],axis=1)
        else :
            self.variability = var

        ## Normalise
        #min = numpy.min(self.variability)
        #rang = numpy.max(self.variability) - min
        #self.variability = 100.0 * (self.variability-min)/rang
        
        # Normalise
        avg = numpy.ma.median(self.variability)
        sd = numpy.ma.std(self.variability)
        variability = numpy.ma.array((self.variability-avg)/sd)
        variability.mask = num_non_gaps < self.size/2 # mask columns with >50% gaps 

        return variability
    
    def variable_positions(self, cutoff=2.0) :
        """
        Returns array of bools, of length self.length. True values indicate variable alignment positions.
        Variability is defined as having a percentage num different residues per total residues (self.size for ungapped alignment positions)
        """
        var = self.calculate_variability()
        return var > cutoff

