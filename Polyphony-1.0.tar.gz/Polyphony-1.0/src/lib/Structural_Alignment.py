"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Initial import CONFIG
from Polyphony.Utils import jalview_pdb_chain_label, ids_from_id
from Polyphony.Residues import Residue_Array_Base, Unaligned_Residue_Array
from Bio.PDB import *
from Bio import AlignIO
#from Bio.Align.Generic import Alignment# obsolete in later versions of Biopython
from Bio.Align import MultipleSeqAlignment
from Bio.Seq import Seq

import numpy, re
from collections import defaultdict

class Structural_Alignment(object) :
    """
    Loads precomputed sequence alignment and one structure (chain) for each sequence. The sequence in the alignment file must
    match the protein structure sequence. Disordered residues should be included in the sequence alignment as "U" so that
    sequential residue numbers match between structure and sequence. Gaps (insertions/deletions) should be indicated with
    a "-" as normal.

    Examples
    --------
    
    >>> # Create structural alignment
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    
    """
    
    def __init__(self) :
        """
        Create empty Structural_Alignment object
        """
        self.config = CONFIG
        self.alignment = []

    def __getitem__(self, index):
        """
        Get a slice of the structural alignment
        """
        new_obj = Structural_Alignment()
        new_obj.id = self.id+"_subset"
        new_obj.alignment = self.alignment[index]

    def __repr__(self) :
        return str(self.alignment) + "\n\n" + str(self.find_gaps())

    def add_alignment(self, filename) :
        """
        Populate alignment from a sequence alignment file. Assign id to this object based upon the provided filename.
        """
        self.alignment = self._read_alignment_file(filename)
        self.id = filename.split("/")[-1].split(".")[0]
        for id in self.ids() :
            if "/" in id :
                raise RuntimeError("Please remove /somethings from the ids in your alignment file, e.g. residue range added by Jalview, and try again.")
        #self.res2pos,self.ires2pos,self.pos2res,self.pos2ires = self._create_residue_indices()

    def _read_alignment_file(self, filename) :
        """
        Read sequence alignment file.
        """
        file_extension = filename.split('.')[-1]
        file = open(filename, "r")
        aligned = AlignIO.read(file, file_extension)
        file.close()
        return aligned
    
    def write_alignment_file(self, filename) :
        """
        Write alignment file 
        """
        file_extension = filename.split('.')[-1]
        file = open(filename, "w")
        AlignIO.write([self.alignment], file, file_extension)
        file.close()
                            
    def length(self) :
        """
        The number of alignment positions in the alignment.
        """
        if self.size() != 0 :
            return len(self.alignment[0].seq)
        else :
            return 0
        
    def size(self) :
        """
        The number of sequences in the alignment
        """
        return len(self.alignment)

    def ids(self) :
        """
        The identfiers for the sequences in the alignment
        """
        if self.size() != 0 :
            return [i.id for i in self.alignment]
        else :
            return []
            
    def ids_for_groups(self, groups) :
        """
        Return the chain ids for the given groups
        """
        ids = self.ids()
        if type(groups[0]) == list :
            return [[ids[i] for i in group] for group in groups]
        else :
            return [ids[i] for i in groups]
            
    def subset(self, group) :
        """
        Return an Structural_Alignment object containing only those sequence indices in group
        """
        group = numpy.array(list(set(group)),int) # ensure no duplicates and numeric type
        group = group[group>=0] # ensure all greater => 0
        group = group[group<self.size()] # ensure all less than self.size
        new_obj = Structural_Alignment()
        new_obj.id = "temp_"+self.id+"_subset"
        sub_align = MultipleSeqAlignment([],alphabet=self.alignment._alphabet)
        sub_align._records = [self.alignment._records[i] for i in group]
        new_obj.alignment = sub_align
        return new_obj

    def slice(self,alignment_positions) :
        """
        Return an Structural_Alignment object containing only those residue alignment positions specified in input
        
        Input parameters
        ----------------
        
        alignment_positions: list of type int
            a list of alignment positions to be selected.

        """
        new_obj = Structural_Alignment()
        new_obj.id = "temp_"+self.id+"_subset"
        sub_align = MultipleSeqAlignment(self.alignment._alphabet)
        # Clunch to get list indexed slice of each sequence in alignment
        for seq in self.alignment :
            new_sequence = Seq("".join(numpy.array(list(seq.seq))[alignment_positions]),seq.seq.alphabet)
            new_seq = seq.__class__(new_sequence, id=seq.id, name=seq.name, description=seq.description)
            for key, value in seq.letter_annotations.iteritems():
                new_seq._per_letter_annotations[key] = value[alignment_positions]
            sub_align._records.append(new_seq)
        #sub_align._records = [rec[alignment_positions] for rec in self.alignment._records[0:self.size()]]
        new_obj.alignment = sub_align
        return new_obj
    
    def _get_unaligned_residues(self, chain_id=None, update=False) :
        """
        Get arrays of residue names and numbers for sequence protein chain and put into a list. If chain_id is specified then only return values for this structure.
        """
        if chain_id == None :
            array = Unaligned_Residue_Array(self, update)
            #residue_arrays = []
            #for id in self.ids() :
            #    residue_arrays.append(Residue_Array_Base(chain_id=id, config=self.config))
            #return residue_arrays
            return array
        else :
            return Residue_Array_Base(chain_id=chain_id, config=self.config)

    def get_labels(self) :
        """
        Return labels for all sequences in the alignment. Currently the labels are the same as the ids
        """
        return self.ids()
        #return self.get_jalview_labels()
    def get_jalview_labels(self) :
        """
        Return labels for Jalview which will allow automatic linking to a pdb structure. This in turn means that a variety information can downloaded from web-based services.
        """
        labels = []
        for id in self.ids() :
            labels.append(jalview_pdb_chain_label(id))
        return labels

    def label_from_id(self, chain_id) :
        """
        convert id to id. Currently just returns the input
        """
        return chain_id
        #return jalview_pdb_chain_label(chain_id)

    def find_longest_structure(self, indices=None) :
        """
        Return the id of the structure with the most ordered residues
        """
        max_len = 0
        if indices == None :
            indices = range(self.size())
        gaps = self.find_gaps()
        for idx in indices :
            length = self.length() - numpy.sum(gaps[idx])
            if length > max_len :
                max_len = length
                longest = idx
        return self.ids()[longest]

    def get_representative_structure(self, indices=None) :
        """
        returns the identifier for a representative structure which is currently the longest (least number of missing residues)
        """
        return self.find_longest_structure(indices=indices)        

    def is_gap(self,res) :
        """ Given a single letter residue code return True if it a valid gap symbol """
        return res == "-" or res == "U"

    def find_gaps(self) :
        """
        Return numpy bool array with same dimensions as alignment with True in positions where a gap exists.
        """
        gaps = numpy.zeros(self.size()*self.length(),bool)
        gaps.shape = self.size(),self.length()
        struct_indx = 0
        for struct in self.alignment :
            # Find gaps in sequence alignment
            gaps[struct_indx] = [self.is_gap(res) for res in struct.seq]
            struct_indx += 1
        return gaps
        
    def calc_distance(self, residue_idx1, residue_idx2, atom_name1 = "CA", atom_name2 = "CA", sort=True) :
        """
        Calculate a distance (in Angstoms) between atoms in all structures in the alignment.
        """
        res2pos,ires2pos,pos2res,pos2ires = self._create_residue_indices()
        ids = self.ids()
        distances = []
        for idx in range(self.size()):
            
            # Residue ids
            resid1 = int(pos2res[idx, residue_idx1])
            resid2 = int(pos2res[idx, residue_idx2])

            # ids for chain
            id = ids[idx]
            pdb_code, model_no, chain_letter = ids_from_id(id)
            
            # create Biopython.PDB object
            structure = self._read_structure(id)
            
            # extract specific atoms
            try :
                atom1=structure[0][chain_letter][resid1][atom_name1]
                atom2=structure[0][chain_letter][resid2][atom_name2]

                # calculate the distance between them
                distance=atom1-atom2                
                print distance
                distances.append(distance)
            except KeyError:
                print "Atoms not found"
                distances.append(0.0)
        
        if sort :
            indices_ordered = list(numpy.argsort(distances))
            ids_ordered = list(numpy.array(ids)[indices_ordered])
            distances.sort()
            return indices_ordered, ids_ordered, distances
        else :
            return distances

    def calc_angle(self, residue_idx1, residue_idx2, residue_idx3, atom_name1 = "CA", atom_name2 = "CA", atom_name3 = "CA", sort=True) :
        """
        Calculate an angle (in degrees) between atoms in all structures in the alignment.
        """
        from Bio.PDB import calc_angle
        import math
        
        res2pos,ires2pos,pos2res,pos2ires = self._create_residue_indices()
        ids = self.ids()
        angles = []
        for idx in range(self.size()):
            
            # Residue ids
            resid1 = int(pos2res[idx, residue_idx1])
            resid2 = int(pos2res[idx, residue_idx2])
            resid3 = int(pos2res[idx, residue_idx3])

            # ids for chain
            id = ids[idx]
            pdb_code, model_no, chain_letter = ids_from_id(id)
            
            # create Biopython.PDB object
            structure = self._read_structure(id)
            
            # extract specific atoms
            try :
                atom1=structure[0][chain_letter][resid1][atom_name1]
                atom2=structure[0][chain_letter][resid2][atom_name2]
                atom3=structure[0][chain_letter][resid3][atom_name3]
                
                # calculate the angle between them
                vector1=atom1.get_vector()
                vector2=atom2.get_vector()
                vector3=atom3.get_vector()
                angle=math.degrees(calc_angle(vector1, vector2, vector3))
                print angle
                angles.append(angle)
            except KeyError:
                print "Atoms not found"
                angles.append(0.0)
        
        if sort :
            indices_ordered = list(numpy.argsort(angles))
            ids_ordered = numpy.array(ids)[indices_ordered]
            ids_ordered = [str(i) for i in ids_ordered] # otherwise list contains numpy.string_ type
            angles.sort()
            return indices_ordered, ids_ordered, angles
        else :
            return angles

    def calc_dihedral(self, residue_idx1, residue_idx2, residue_idx3, residue_idx4, atom_name1 = "CA", atom_name2 = "CA", atom_name3 = "CA", atom_name4 = "CA", sort=True) :
        """
        Calculate an angle (in degrees) between atoms in all structures in the alignment.
        """
        from Bio.PDB import calc_dihedral
        import math
        
        res2pos,ires2pos,pos2res,pos2ires = self._create_residue_indices()
        ids = self.ids()
        angles = []
        for idx in range(self.size()):
            
            # Residue ids
            resid1 = int(pos2res[idx, residue_idx1])
            resid2 = int(pos2res[idx, residue_idx2])
            resid3 = int(pos2res[idx, residue_idx3])
            resid4 = int(pos2res[idx, residue_idx4])

            # ids for chain
            id = ids[idx]
            pdb_code, model_no, chain_letter = ids_from_id(id)
            
            # create Biopython.PDB object
            structure = self._read_structure(id)
            
            # extract specific atoms
            try :
                atom1=structure[0][chain_letter][resid1][atom_name1]
                atom2=structure[0][chain_letter][resid2][atom_name2]
                atom3=structure[0][chain_letter][resid3][atom_name3]
                atom4=structure[0][chain_letter][resid4][atom_name4]
                
                # calculate the angle between them
                vector1=atom1.get_vector()
                vector2=atom2.get_vector()
                vector3=atom3.get_vector()
                vector4=atom4.get_vector()
                
                angle=math.degrees(calc_dihedral(vector1, vector2, vector3, vector4))
                print angle
                angles.append(angle)
            except KeyError:
                print "Atoms not found"
                angles.append(0.0)
        
        if sort :
            indices_ordered = list(numpy.argsort(angles))
            ids_ordered = numpy.array(ids)[indices_ordered]
            ids_ordered = [str(i) for i in ids_ordered] # otherwise list contains numpy.string_ type
            angles.sort()
            return indices_ordered, ids_ordered, angles
        else :
            return angles
    
    def _read_structures(self) :
        """
        Read the PDB chain files and return dictionary object containing BioPython objects index by id.
        """
        # Create a BioPython PDB parser
        parser = PDBParser()
        structures = {}
        # read all the PDB files. Must read all of them ok as there is a one to one mapping to the sequence alignment
        for id in self.ids():
            target = self.config.get('directories','data')+"chains/"+id+".pdb"
            print "Reading PDB chain " + id
            try:
                structures[id] = parser.get_structure(id, target)
            except IOError, message:
                print "Open error for file %s." % target
                print message
                exit()
        return structures
                
    def _read_structure(self, chain_id) :
        """
        Read a single pdb file and return a Biopython.PDB structure object.
        """
        parser = PDBParser()
        target = self.config.get('directories','data')+"chains/"+chain_id+".pdb"
        print "Reading PDB chain " + chain_id
        try:
            struct = parser.get_structure(chain_id, target)
        except IOError, message:
            print "Open error for file %s." % target
            print message
            exit()
        return struct
                
    def _create_residue_indices(self, update=False) :
        """
        Create index to use to go from residue number to alignment array position
        """
        unaligned = self._get_unaligned_residues(update=update)
        max_res_num = unaligned.max_resnum() + 1
        max_len = unaligned.get_length()
        size = self.size()
        length = self.length()
        
        # residue number to alignment position
        res2pos = numpy.ma.zeros(max_res_num*size, int)
        res2pos.mask = numpy.ones(max_res_num*size, bool)
        res2pos.shape = size, max_res_num
        # residue array index number to alignment position
        ires2pos = numpy.ma.zeros(max_len*size, int)
        ires2pos.mask = numpy.ones(max_len*size, bool)
        ires2pos.shape = size, max_len
        # alignment position to residue number
        pos2res = numpy.ma.zeros(length*size, int)
        pos2res.mask = numpy.ones(length*size, bool)
        pos2res.shape = size, length
        # alignment position to residue array index number
        pos2ires = numpy.ma.zeros(length*size, int)
        pos2ires.mask = numpy.ones(length*size, bool)
        pos2ires.shape = size, length
        
        # for each sequence
        for istruct in range(size) :
            residues = unaligned.data[istruct]
            seq = self.get_sequence(istruct)
            ith_res = 0
            # for each alignment position
            for ipos in range(length) :
                aa = seq[ipos]
                if aa != '-' :
                    resNum = residues.data[ith_res,1]
                    # residue number to alignment position
                    res2pos.data[istruct, resNum] = ipos
                    res2pos.mask[istruct, resNum] = False
                    # residue property array index to alignment position
                    ires2pos.data[istruct, ith_res] = ipos
                    ires2pos.mask[istruct, ith_res] = False
                    # alignment position to residue number
                    pos2res.data[istruct, ipos] = resNum
                    pos2res.mask[istruct, ipos] = False
                    # alignment position to residue property array index
                    pos2ires.data[istruct, ipos] = ith_res
                    pos2ires.mask[istruct, ipos] = False
                    ith_res += 1
    
        return res2pos,ires2pos,pos2res,pos2ires
    
    def index_from_id(self, id) :
        """
        Return the index of a structure, given its id.
        """
        try :
            return self.ids().index(id)
        except :
            raise KeyError('Id not found in alignment')
        
    def get_sequence(self, index):
        """
        Return sequence, as a list of characters, of structure the with given alignment index
        """
        return list(self.alignment._records[index].seq)
        
    def get_sequence_from_id(self, id) :
        """
        Return sequence, as a list of characters, of structure with the given id
        """
        idx = self.index_from_id(id)
        return list(self.alignment._records[idx].seq)
    
    def get_residues(self, chain_id) :
        """
        Read in pdb file, store Biopython.PDB structure object and return a list of residue objects. 
        """
        # BioPython code to access the residues (assume 1st model and chain because working with single chain pdb file)
        models = self._read_structure(chain_id)
        model    = models[0]
        chains   = model.get_list()
        chain    = chains[0]
        residues = chain.get_list()

        #below not needed
        #chain    = model[chain_id[-1]]
        #selector = SelectChain()
        #residues = selector.get_residues(chain)
        return residues
    
    def get_chain(self, chain_id) :
        """
        Read in pdb file, store Biopython.PDB structure object and return a chain object. 
        """
        # BioPython code to access the residues (assume 1st model and chain because working with single chain pdb file)
        models = self._read_structure(chain_id)
        model    = models[0]
        chains   = model.get_list()
        chain    = chains[0]
        return chain
    
    def get_header_info(self) :
        """
        Return dictionary of pdb header information for each protein structure. Top level keys are chain codes e.g. 1P38_A (case sensitive). Subkeys are one of:
        [name, head, deposition_date, release_date, structure_method, resolution, structure_reference]
        """
        titles = {}
                
        # Create a BioPython PDB parser
        parser = PDBParser()
        # read all the PDB files. Must read all of them ok as there is a one to one mapping to the sequence alignment
        for id in self.ids():
            #pdb_code = id.split('_')[0]
            pdb_code, model_no, chain_letter = ids_from_id(id)
            target = self.config.get('directories','data')+"pdbs/"+pdb_code+".pdb"
            print "Reading header from PDB structure " + pdb_code
            file=open(target,'r')
            header_dict=parse_pdb_header(file)
            file.close()
            titles[id] = header_dict
        
        return titles
    
    def grep_header_records(self, regexp) :
        """
        Grep each pdb file in the alignment using provided regular expression
        """
        parser = re.compile(regexp)
        for id in self.ids() :
            pdb_code, model_no, chain_letter = ids_from_id(id)
            target = self.config.get('directories','data')+"pdbs/"+pdb_code+".pdb"
            print pdb_code,
            f = open(target)
            for line in f.readlines():
                match = parser.search(line)
                if match :
                    print line
            print
            f.close()
        
    def create_structure_report(self, filename="structure_data.csv", columns=["structureId","experimentalTechnique","depositionDate","resolution","structureMolecularWeight","unitCellAngleAlpha","unitCellAngleBeta","unitCellAngleGamma","spaceGroup","lengthOfUnitCellLatticeA","lengthOfUnitCellLatticeB","lengthOfUnitCellLatticeC"]) :
        """
        Create a csv format text output summarising the PDB structures in your alignment. Read about RCSB custom reports for details of other column names at http://www.rcsb.org/pdb/software/wsreport.do 
        """

        # Get the set of PDB codes in the alignment and the set of non-PDB (in-house) codes  
        pdb_codes = set()
        non_pdb_codes = set()
        for id in self.ids() :
            pdb_code, model_no, chain_letter = ids_from_id(id)
            if len(pdb_code) == 4 : 
                pdb_codes.add(pdb_code)
            else :
                non_pdb_codes.add(pdb_code)

        file = open(filename,"w")
        if len(pdb_codes) != 0 :
            # Get data for PDBs using the RCSB resftul service
            url="http://www.rcsb.org/pdb/rest/customReport"
            pdbs = ",".join(pdb_codes)
            url += "?pdbids="+pdbs
            columns = ",".join(columns)
            url += "&customReportColumns="+columns
            url += "&format=csv"
            print url
            import urllib
            u = urllib.urlopen(url)
            data = u.read()
            lines = data.replace("<br />","\n")
            file.write(lines)

        if len(non_pdb_codes) != 0 :
            # Get data for in-house structures using Biopython.PDB parser
            header_dict = self.get_header_info()
            titles = '\n'+", ".join(header_dict[[i for i in header_dict][0]].keys())+'\n'
            file.write(titles)
            for code in non_pdb_codes :
                chain_code = [i for i in header_dict.keys() if ids_from_id(i)[0] == code][0]
                data = [i for i in header_dict[chain_code].values() if type(i) == str]
                line = code+","+", ".join(data)+'\n'
                file.write(line)
        
        file.close()
            
    def get_consensus_sequence(self, subset=None) :
        """
        Return list of characters which represent the consensus sequence.
        """
        
        # initiate count dictionary list
        aa_counts = []
        for i in range(self.length()) :
            aa_count_dict = {}
            aa_counts.append(aa_count_dict)
            
        # go through each sequence in turn keeping a count of each amino acid code at each alignment position
        if subset == None :
            structures = self.alignment
        else :
            structures = self.alignment[subset]
            
        for struct in structures :
            for i in range(self.length()):
                res = struct.seq[i]
                if not self.is_gap(res) : # could be improved with gap mask and list comprehension?
                    aa_counts[i][res] = aa_counts[i].get(res,0) + 1
                    
        # Find amino acid code with the highest count for each alignment position
        consensus_sequence = []
        for i in range(self.length()) :
            if len(aa_counts[i]) != 0 :
                consensus_sequence.append(sorted(aa_counts[i].items(),key=lambda x:(x[1], x[0]))[-1][0])
            else :
                consensus_sequence.append('-')
        return consensus_sequence
           
    def group_by_pdb(self) :
        """
        Return list of lists containing different chains from the same pdb
        """
        groups = defaultdict(list)
        for idx in range(self.size()) :
            id = self.ids()[idx]
            pdb_code, model_no, chain_letter = ids_from_id(id)
            groups[pdb_code].append(idx)
            
        return groups.values()

        