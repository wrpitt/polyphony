"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony import chemometrics
from Polyphony.Plotting import plot_scatter
import pylab, numpy
from numpy import newaxis as nA


def plot_pca_scree(arr, labels):
    """
    Plot scree plots for arr of first 3 pcs. Shows the fraction of total variance in the data as explained in decreasing order.
    """
    labels = numpy.array(labels)
    size = len(labels)
    pylab.subplot(311)
    ind = arr[0,:].argsort()[::-1]  
    pylab.plot(arr[0,ind],'r-')
    pylab.xticks(pylab.arange(size),labels[ind], size = 'x-small',rotation=90)
    pylab.title("PC1 sorted arr")
    pylab.subplot(312)
    ind = arr[1,:].argsort()[::-1]  
    pylab.plot(arr[1,ind],'b-')
    pylab.xticks(pylab.arange(size),labels[ind], size = 'x-small',rotation=90)
    pylab.title("PC2 sorted arr")
    pylab.subplot(313)
    ind = arr[2,:].argsort()[::-1]  
    pylab.plot(arr[2,ind],'g-')
    pylab.xticks(pylab.arange(size),labels[ind], size = 'x-small',rotation=90)
    pylab.title("PC3 sorted arr")
    pylab.show()

def plot_pca_scatters3(scores,loadings,xlabels,ylabels, groups = None, legend=None, spectrum=False, show_labels=False) :
    """
    Plot scatter plots of scores and loadings for each pair of first three pcs
    """
    pylab.subplot(231)
    plot_scatter(scores[:,0],scores[:,1], ylabels, groups=groups, size=30, spectrum=spectrum, show_labels=show_labels, show=False)
    pylab.title("PC1 vs PC2 scores")
    pylab.subplot(232)
    plot_scatter(scores[:,0],scores[:,2], ylabels, groups=groups, size=30, spectrum=spectrum, show_labels=show_labels, show=False)
    pylab.title("PC1 vs PC3 scores")
    pylab.subplot(233)
    plot_scatter(scores[:,1],scores[:,2], ylabels, groups=groups, size=30, spectrum=spectrum, show_labels=show_labels, show=False)
    pylab.title("PC2 vs PC3 scores")
    pylab.subplot(234)
    plot_scatter(loadings[0,:],loadings[1,:], xlabels, groups=None, size=30, spectrum=spectrum, show_labels=show_labels, show=False)
    pylab.title("PC1 vs PC2 loadings")
    pylab.subplot(235)
    plot_scatter(loadings[0,:],loadings[2,:], xlabels, groups=None, size=30, spectrum=spectrum, show_labels=show_labels, show=False)
    pylab.title("PC1 vs PC3 loadings")
    pylab.subplot(236)
    plot_scatter(loadings[1,:],loadings[2,:], xlabels, groups=None, size=30, spectrum=spectrum, show_labels=show_labels, show=False)
    pylab.title("PC2 vs PC3 loadings")
   
    pylab.show()

def plot_pca_scatters2(scores,loadings,xlabels,ylabels, groups = None) :
    """
    Plot scatter plots for the 1st PC vs. the 2nd
    """
    pylab.subplot(211)
    plot_scatter(scores[:,0],scores[:,1], ylabels, groups=groups)
    pylab.title("PC1 vs PC2 scores")
    pylab.subplot(212)
    plot_scatter(loadings[0,:],loadings[1,:], xlabels, groups=groups)
    pylab.title("PC1 vs PC2 loadings")
    pylab.show()

def plot_PC1_vs_PC2(scores, xlabels, ylabels, groups = None, alpha=0.5, size=150, legend=None, spectrum=False, show_labels=False) :
    """
    Plot scores plot, PC1 against PC2
    """
    if groups != None :
        # Get group index for structures
        group_indices = numpy.zeros(len(scores))
        group_indices += 99
        group_idx = 0
        for group in groups :
            for member in group :
                group_indices[member] = group_idx
            group_idx += 1
            
        # Create structured array for sorting and viewing    
        if show_labels :
            dtype = ('f4,f4,a20,i2')
            data_array = numpy.dstack((scores[:,0], scores[:,1], ylabels, group_indices))[0]
            list_array = [(float(i[0]),float(i[1]),i[2],float(i[3])) for i in data_array]
        else :
            dtype = ('f4,f4,i2')
            data_array = numpy.dstack((scores[:,0], scores[:,1], group_indices))[0]
            list_array = [(float(i[0]),float(i[1]),float(i[2])) for i in data_array]
            
        struct_array = numpy.zeros((len(data_array),),dtype=dtype)
        struct_array[:] = list_array
        struct_array.sort()
    
        # Print to screen
        for i in struct_array :
            print i
        
    # Plot
    plot_scatter(scores[:,0],scores[:,1], ylabels, groups=groups, show_labels=show_labels, alpha=alpha, size=size, spectrum=spectrum, show=False)
    #pylab.title("PC1 vs PC2 scores")
    pylab.show()
    
def calc_pca(array, xlabels, ylabels, max_pcs = 10, show_plot="grid", groups=None, legend=None, spectrum=False, show_labels=True) :
    """
    Do a principal component analysis. Currently uses the NIPALS method in pychem.mva. Produces scatter plots of scores and loadings for the 1st 3 PCs. Returns arrays containings the scores and loadings.
    """
    ysize = array.shape[0] # number of observations
    xsize = array.shape[1] # number of variables per observation
    if show_labels :
        assert xsize == len(xlabels)
        assert ysize == len(ylabels)

    print "Doing PCA on matrix of size",xsize,"x",ysize

#    tt,pp,pr,eigs = chemometrics.pca_svd(array)

    # Three principal components needed for plots
    if max_pcs < 3 :
        max_pcs = 3
        
    scores,loadings,pr,eigs = chemometrics.pca_nipals(array, max_pcs)
    

    print "\nCumulative proportions of variance explained:"
    print pr[1:max_pcs+1]
    
    if show_plot == "grid" :
        plot_pca_scatters3(scores,loadings,xlabels,ylabels,groups=groups, legend=legend, spectrum=spectrum, show_labels=show_labels)
    elif show_plot == "simple" :
        point_size = 40000/len(scores)
        plot_PC1_vs_PC2(scores, xlabels, ylabels, groups=groups, legend=legend, size=point_size, spectrum=spectrum, show_labels=show_labels)
    
    #plot_pca_scree(scores,ylabels)
    #plot_pca_scree(loadings,xlabels)
    
    return scores, loadings

def calc_pca_from_distance_matrix(distmat, labels, max_pcs = 10, groups = None) :
    """
    Do principal components analysis, given a distance matrix. Uses numpy.linalg.eigh to calculate eigen values and vectors. Produces scatter plots of loading for first 3 PCs. EXPERIMENTAL.
    """
    
    # Calculate eigenvalues and eigen vectors
    e,EV = numpy.linalg.eigh(distmat)
    
    # Sort index for descreasing eigenvalues
    ind = numpy.argsort(e)
    ind = ind[::-1]
    
    # Extract loadings top eigen vectors
    loadings = EV[:,ind[:max_pcs]]
    loadings = numpy.transpose(loadings)
    eigen_value_sum = numpy.sum(e)
    cumulative_proportion_variance_explained = 100.0 * numpy.add.accumulate(e[ind])/eigen_value_sum
    #cumulative_proportion_variance_explained = numpy.add.accumulate(e[ind])

    print e[ind[:max_pcs]]
    print cumulative_proportion_variance_explained[:max_pcs]
    
    pylab.subplot(221)
    plot_scatter(loadings[0,:],loadings[1,:], labels, cutoff=0.1, groups=groups)
    pylab.title("PC1 vs PC2 loadings")
    pylab.subplot(222)
    plot_scatter(loadings[0,:],loadings[2,:], labels, cutoff=0.1, groups=groups)
    pylab.title("PC1 vs PC3 loadings")
    pylab.subplot(223)
    plot_scatter(loadings[1,:],loadings[2,:], labels, cutoff=0.1, groups=groups)
    pylab.title("PC2 vs PC3 loadings")
    pylab.subplot(224)
    pylab.plot(e[ind])
    pylab.show()
    
def do_pca_dfa(X, xlabels, ylabels, groups) :
    """
    Perform PC-DFA with full cross validation using dfa_xval_pca function from pychem.mva. EXPERIMENTAL.
    """
    group_array = numpy.zeros(len(xlabels),int)
    group_idx = 1
    for group in groups :
        for member in group:
            group_array[member] = group_idx
        group_idx += 1
    group_array.shape = len(xlabels),1
    mask_array = numpy.zeros(len(xlabels),int)
    mask_array[-2:] = 1
    mask_array.shape = len(xlabels),1
    
    print groups
    
    scores,loadings,eigs = chemometrics.dfa_xval_pca(X,'NIPALS',10,group_array,mask_array,3,'covar')
    print scores.shape,loadings.shape
    print eigs
    
    plot_pca_scatters3(scores,numpy.transpose(loadings),ylabels,xlabels,groups)     
    #plot_pca_scree(scores,ylabels)
    #plot_pca_scree(loadings,xlabels)

def do_PCA_on_property_array(property_array, max_pc_chains_to_ignore=10, components=[0,1], dimensions=[], show_plot="grid", groups=None, legend=None, spectrum=False, show_labels=True) :
    """
    Calculate PCA on data matrix, produce plots and return scores and loadings.
    
    Parameters
    ----------
    property_array : Polyphony.Propert_Array object
        the property data for a whole alignment
        
    max_pc_chains_to_ignore : int
        a complete block of data must be used for this data. This parameter sets the maximum percentage of structures to be ignore when choosing this block of resides. Default = 10
        
    components : list of ints
        the scores and loadings are summed over the given list of principle components. Starts at 0 for the first PC.
        
    Returns
    -------
    scores_array : 1d numpy array
        scores from PCA, length equal to the size (number of structures) of the alignment for which the input properties were calculated. 
    
    loadings_array : 1d numpy array
        loadings from PCA, length equal to the length of the alignment for which the input properties were calculated.
        
    Examples
    --------
    >>> # load alignment
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>>
    >>> # get backbone conformation property array
    >>> properties = Properties()
    >>> array = properties.get_array("backbone", aligned)
    >>>
    >>> # calculated summed scores and loadings from first 2 PCs
    >>> scores, loadings = do_PCA_on_property_array(array, components=[0,1,2])
        
    """
    
    # If subset of dimensions selected then slice them out of full array
    if len(dimensions) > 0 :
        # check multidimensional array
        if property_array.data_dim == 1 :
            raise RuntimeError(property+"is a single dimension descriptor. Don't use the dimensions input parameter")
        print "Selected descriptors:", [property_array.dim_names[i] for i in dimensions]
    
    array, chain_indices, column_indices = property_array.get_complete_matrix(max_pc_chains_to_ignore, dimensions=dimensions)
        
    if show_labels :
        # Y labels are remaining chain ids
        ylabels = numpy.array(property_array.alignment.ids())
        ylabels = ylabels[chain_indices]
        
        # X labels are remaining alignment positions
        xlabels = column_indices/property_array.data_dim
    else :
        xlabels = None
        ylabels = None
    
    if groups != None :
        # Remove excluded chains from groups
        if len(groups) > 1 :
            print groups
            print len(groups)
            new_groups = [[numpy.where(chain_indices==i)[0][0] for i in group if i in chain_indices] for group in groups]
        else :
            new_groups = [[numpy.where(chain_indices==i)[0][0] for i in groups[0] if i in chain_indices]]
    else :
        new_groups = None
            
    scores, loadings = calc_pca(array,xlabels,ylabels,max_pcs = max(components)+1, show_plot=show_plot, groups=new_groups, legend=legend, spectrum=spectrum, show_labels=show_labels)
    
    # Sum loadings over given components
    sum_loadings = numpy.zeros(len(column_indices))
    for i in range(len(components)) :
        pc = loadings[components[i],:]
        sum_loadings += pc

    # Sum scores over given components    
    sum_scores = numpy.zeros(len(chain_indices))
    for i in range(len(components)) :
        pc = scores[:,components[i]]
        sum_scores += pc
    
    # Put sum of scores for selected principle components into a masked array with dimensions self.size
    scores_array = numpy.ma.zeros(property_array.size)
    scores_array.mask = True
    scores_array[chain_indices] = sum_scores
    scores_array.mask[chain_indices] = False

    # Write scores to file
    ids = property_array.alignment.ids()
    scores_file = open("scores.csv","w")
    idx = 0
    for i in range(property_array.size) :
        scores_file.write(ids[i])
        if i in chain_indices :
            for j in range(len(components)) :
                scores_file.write("," + str(scores[idx,j]))
            idx += 1
        else :
            for j in range(len(components)) :
                scores_file.write(",")
        scores_file.write("\n")
    scores_file.close()

    # Put sum of loadings for selected principle components into a masked array with dimensions self.length, self.data_dim
    loadings_array = numpy.ma.zeros(property_array.length*property_array.data_dim)
    loadings_array.mask = True
    loadings_array[column_indices] = sum_loadings
    loadings_array.mask[column_indices] = False
    loadings_array.shape = property_array.length,property_array.data_dim
    
    return scores_array, loadings_array
