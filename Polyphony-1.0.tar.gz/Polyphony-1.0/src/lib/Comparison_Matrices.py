"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Utils import Calculate_Write_Read
import numpy, scipy
from scipy import cluster

class Comparison_Matrix(Calculate_Write_Read) :
    
    """
    Class for manipulating distance matrices. It is a subclass of Calculate_Write_Read to allow storage on disk of such matrices. Matrices can be based upon whole structure (vertical) or residue position (horizontal) comparisons. The former is handled with the Structure_Matrix subclass and the latter the Residue_Matrix subclass. Objects of this class should be be created explicitly.
    """

    def __init__(self, alignment_property_array, update = False) :
        self.parent = alignment_property_array
        self.id = self.parent.id+self.file_suffix
        self.data_directory = self.parent.data_directory
        self.data = Calculate_Write_Read.__init__(self, self.id, update)
        #if len(self.data.shape) > 2 :
        #    self.data_dim = self.data.shape[2]
        #else:
        #    self.data_dim = 1
        self.length = self.data.shape[1]

    def __repr__(self) :
        for row in self.data :
            print numpy.array2string(row, precision=2, separator=',', suppress_small=True)
        return ""    
        
    def get_closest_pairs(self, maxpairs, separation=0, desc = True) :
        """
        return a list of most closest (with smallest distance) pairs in the matrix.
        """
        # Sort flatten data
        sorted = numpy.ma.argsort(self.data.flatten(),fill_value=0.0)
        if desc : # sort in descending order
            sorted = sorted[::-1]
        # identify which row and column pair gave each distance in the sorted list
        #pairs = [[i/self.length, numpy.mod(i,self.length)] for i in sorted[::2]]
        pairs = [[i/self.length, numpy.mod(i,self.length)] for i in sorted]
        # sorted list of residue i-residue j pairs there are where i!=j
        non_self_pairs = [i for i in pairs if abs(i[0]-i[1]) > separation]
        # check selected maxpairs is not too large, if it reduce it
        maxpairs = min(maxpairs,len(non_self_pairs))
        # top maxpairs pairs only
        best = [i for i in non_self_pairs[:maxpairs]]
        # top maxpairs residue pairs and their covariance values
        bestvalues = [(i,self.data[i[0],i[1]]) for i in best]
        #masks = numpy.array([self.data.mask[i[0],i[1]] for i in best]).sum()
        #print "number of masks in best =", masks
        return bestvalues
                
    def get_ids(self) :
        """
        Return list of structure chain ids.
        """
        return self.parent.get_ids()

    def get_labels(self) :
        """
        Return list of structure chain ids labels.
        """
        return self.parent.alignment.get_labels()
        
    def label_from_id(self, id) :
        """
        Convert id to label.
        """
        return self.parent.alignment.label_from_id(id)
            
    def single_linkage_clusters(self, cut_off) :
        """
        Return list of lists of ids where all chains within a sublist have distance less than or equal to the cut_off. Single linkage clustering by naive algorithm.
        """
        clusters = []
        for i in range(0, self.length-1) :
            for j in range(i+1, self.length) :
                if self.data[i,j] <= cut_off :
                    # pair are close enough so create new combined cluster
                    
                    # Find existing cluster membership for pair
                    c0 = c1 = set()
                    for k in range(len(clusters)) :
                        if i in clusters[k] :
                            c0.add(k)
                        if j in clusters[k] :
                            c1.add(k)
                    
                    # Update list of clusters 
                    new_cluster = set((i,j))
                    c0c1 = list(set.union(c0,c1))
                    c0c1.sort(reverse=True)
                    for k in c0c1 :
                        new_cluster |= clusters[k] # add existing cluster to new cluster
                        clusters.remove(clusters[k]) # remove existing cluster
                    clusters.append(new_cluster)
                
        # convert from list of sets to list of lists
        clusters = [list(i) for i in clusters]
            
        return clusters
    
    def fcluster(self, cut_off) :
        """
        """
        condensed_matrix = scipy.spatial.distance.squareform(self.data)
        linkage_matrix = cluster.hierarchy.linkage(condensed_matrix, method='complete')
        return cluster.hierarchy.fcluster(linkage_matrix, cut_off, criterion='maxclust')

class Residue_Matrix(Comparison_Matrix) :
    
    """
    Class for generation and storage of residue position correlation matrices. If the property array being used to describe each residue is multidimensional, then the matrix will have dimensions (l x d)^2 where l is the length of the alignment and d is the dimensionality of the property type.
    """

    file_suffix = "_res_mat"   # directory where calculated results are stored

    def __init__(self, alignment_property_array, update = False) :
        Comparison_Matrix.__init__(self, alignment_property_array, update)
        # Check precomputed data has the same dimensions as provided array
        if self.data.shape[0] != alignment_property_array.length * alignment_property_array.data_dim:
            print "Precomputed data doesn't match property array. Recomputing"
            Comparison_Matrix.__init__(self, alignment_property_array, update=True)
            assert self.data.shape[0] == alignment_property_array.length * alignment_property_array.data_dim
        
    def _calculate(self) :
        data = self.parent.calculate_residue_correlation_matrix()
        return data

    def reduce_to_one_per_residue(self) :
        """
        Convert matrix from (l x d)^2 to l^2, where l is the length of the alignment and d is the dimensionality of the property type. Currently does this by taking the average of the absolute values.
        """
        l = self.length
        x = self.parent.data_dim
        # residue data is in data_dim*data_dim blocks. This horrendous bit of code reorders the matrix so that block elements are contiguous.
        index = numpy.array([[ [ [i+j+l*k for j in range(x)] for k in range(x) ] for i in range(h*l,h*l+l,x)] for h in range(0,l,x)]).flatten()
        reordered_data = self.data.flatten()[index].reshape(-1,x**2)
        num_comparisons = x**2
        self.data = numpy.ma.sum(numpy.absolute(reordered_data),axis=1)/num_comparisons
        l = self.parent.length
        self.data.shape = l,l
        self.data_dim = 1
        self.length = l
        
    def get_correlation_matrix(self) :
        """
        Return the correlation matrix as a numpy array
        """
        return self.data
    
    def get_distance_matrix(self) :
        """
        Return the distance matrix as a numpy array
        """
        return (1 - self.data)/2.0

    def get_compressed_distance_matrix(self) :
        """
        Return distance matrix with masked values excluded.
        """
        distmat = self.get_distance_matrix()
        treemat = numpy.ma.compressed(distmat)
        treemat_dim = numpy.sqrt(len(treemat))
        treemat.shape = treemat_dim,treemat_dim
        for i in range(len(distmat)) :
            if distmat.mask[i].sum() < len(distmat) :
                ids = [j for j in range(len(distmat)) if not distmat.mask[i,j]]
                break
        return treemat,ids

class Structure_Matrix(Comparison_Matrix) :
    
    """
    Class for generation and storage of structure distance matrices. The matrix will have dimensions s^2 where s is the size of the alignment (number of structures/chains). Distance matrices are stored for future use.
    """

    file_suffix = "_struct_mat"   # directory where calculated results are stored

    def __init__(self, alignment_property_array, update = False) :
        Comparison_Matrix.__init__(self, alignment_property_array, update)
        # Check precomputed data has the same dimensions as provided array
        if self.data.shape[0] != alignment_property_array.size :
            print "Precomputed data doesn't match property array. Recomputing"
            Comparison_Matrix.__init__(self, alignment_property_array, update=True)
            assert self.data.shape[0] == alignment_property_array.size
        
    def _calculate(self) :
        data = self.parent.calculate_distance_matrix()
        return data
    
    def get_distance_matrix(self) :
        """
        Return the distance matrix as a numpy array
        """
        return self.data
    
    def standardise_data(self) :
        """
        Return copy of matrix for which values have been mean centred and divided by the standard deviation
        """
        avg_difference = numpy.average(self.data)
        sd_difference = numpy.std(self.data)
        standardised = self.data.copy()
        standardised -= avg_difference
        standardised /= sd_difference
        return standardised
            
            
        