"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

"""
Instructions for using this template to create your own property array.

1. Replace "TEMPLATE" with a name of your choice
2. Add a line for this property in ~/Polyphony/polyphony.cfg
3. Modify the _calculate function to calculate your property for a single protein
4. Customise the reduce, write_jalview_feature_file, calculate_distance_matrix functions.
5. Add property specific functions if you like

"""

from Polyphony.Property_Arrays import Structure_Property_Array, Structural_Alignment_Property_Array
import numpy

class TEMPLATE_Array(Structure_Property_Array) :
    
    """
    Class to calculate per residue properties for a single chain
    """
    
    data_type = float               # the type of the property
    data_dim = 3                    # the number of dimensions for each residue e.g. 3 for x,y,z of c-alpha atoms
    dim_names = ["a","b","c"]       # name of each dimension for plotting 
    data_directory = "TEMPLATE"     # directory where calculated results are stored
    data_file_extension = ".npy"    # extension of data files (always the same)
    padding = 0                     # number of residues to mask out either side of gaps and at termini
    
    def __init__(self, alignment, alignment_index, update = False) :
        """
        object constructor - can be left unchanged
        """
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)

    
    def _calculate(self) :
        """
        Return masked array of shape (alignment length, data_dim) or (alignment length) containing the calculated property values
        """
        
        ## example procedure
        ##

        # Get Bio:PDB residue objects
        residues = self.alignment.get_residues(self.pdb_chain_code)
        
        # Create empty masked array
        if self.data_dim == 1 : 
            data_array = numpy.ma.zeros((len(residues),self.data_dim))
        else :
            data_array = numpy.ma.zeros(len(residues))            
        data_array.mask = False

        # Put values into array, masking any uncalculatable values
        for i in range(len(residues)) :
            """
            try : 
                data_array[i] = SOMETHING
            except :
                data_array.mask[i] = True
            """
        return data_array

    ## Property array specific functions go here

class TEMPLATE_Alignment_Array(Structural_Alignment_Property_Array) :
    
    """
    Class to collect residue properties for a whole alignment
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> array = TEMPLATE_Alignment_Array(aligned, update=False)

    """

    data_directory = "TEMPLATE_arrays"   # directory where calculated results are stored
    data_file_extension = ".npy"         # extension of data files
    
    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, TEMPLATE_Array, update)    
    
    ## Property array specific functions go here
    
    def reduce(self) :
        """
        Reduce 3d array to 2d array of self.data_dim > 1. 
        """
        return self.reduce() # geometric mean by default
        
    #def calculate_distance_matrix(self, all_mask=False) :
    #    """
    #    Calculate a distance matrix using the manhatten distance metric.
    #    """
    #    if not type(all_mask) == bool :
    #        all_mask = self._expand_array(all_mask) 
    #    return self.calculate_manhatten_distance_matrix(all_mask)


    def write_jalview_feature_file(self, filename) :
        """
        Create Jalview feature file.
        """
                
        self.make_jalview_feature_file(filename, "TEMPLATE_CLASS (make something up)", "TEMPLATE", "00FF00", "008800", 1.5, 2.5) # Min, max colour in hex, min, max value of 2d reduced values

 