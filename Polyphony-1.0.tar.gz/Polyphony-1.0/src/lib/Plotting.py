"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import pylab, math, numpy
import scipy.ndimage.filters as ndi
from matplotlib.ticker import MultipleLocator, FormatStrFormatter, FixedLocator
from matplotlib import pyplot
import matplotlib, copy
"""
Set of functions to aid plotting Polyphony alignment properties.
"""

# html colours
colours = ["blue", "red", "cyan", "magenta", "green", "yellow", "black", "brown", "darkblue", "darkcyan", "darkgoldenrod", "darkgray", "darkgreen", "darkkhaki", "darkmagenta", "darkolivegreen", "darkorange", "darkorchid", "darkred", "darksalmon", "darkseagreen", "aliceblue", "antiquewhite", "aqua", "aquamarine", "azure", "beige", "bisque", "blanchedalmond", "blueviolet", "burlywood", "cadetblue", "chartreuse", "chocolate", "coral", "cornflowerblue", "cornsilk", "crimson", "darkslateblue", "darkslategray", "darkturquoise", "darkviolet", "deeppink", "deepskyblue", "dimgray", "dodgerblue", "firebrick", "floralwhite", "forestgreen", "fuchsia", "gainsboro", "ghostwhite", "gold", "goldenrod", "gray", "greenyellow", "honeydew", "hotpink", "indianred", "indigo", "ivory", "khaki", "lavender", "lavenderblush", "lawngreen", "lemonchiffon", "lightblue", "lightcoral", "lightcyan", "lightgoldenrodyellow", "lightgreen", "lightgrey", "lightpink", "lightsalmon", "lightseagreen", "lightskyblue", "lightslategray", "lightsteelblue", "lightyellow", "lime", "limegreen", "linen", "maroon", "mediumaquamarine", "mediumblue", "mediumorchid", "mediumpurple", "mediumseagreen", "mediumslateblue", "mediumspringgreen", "mediumturquoise", "mediumvioletred", "midnightblue", "mintcream", "mistyrose", "moccasin", "navajowhite", "navy", "oldlace", "olive", "olivedrab", "orange", "orangered", "orchid", "palegoldenrod", "palegreen", "paleturquoise", "palevioletred", "papayawhip", "peachpuff", "peru", "pink", "plum", "powderblue", "purple", "red", "rosybrown", "royalblue", "saddlebrown", "salmon", "sandybrown", "seagreen", "seashell", "sienna", "silver", "skyblue", "slateblue", "slategray", "snow", "springgreen", "steelblue", "tan", "teal", "thistle", "tomato", "turquoise", "violet", "wheat", "white", "whitesmoke", "yellowgreen"]
#colours = ['b','r','c','m','g','y','k']

def _make_second_bottom_spine(ax=None, label=None, offset=0, labeloffset=20):
    """Makes a second bottom spine. From Joe Kington Stackoverflow contrib"""
    if ax == None:
        ax = pyplot.gca()
    second_bottom = matplotlib.spines.Spine(ax, 'bottom', ax.spines['bottom']._path)
    second_bottom.set_position(('outward', offset))
    ax.spines['second_bottom'] = second_bottom

    if label is not None:
        # Make a new xlabel
        ax.annotate(label, 
                xy=(0.5, 0), xycoords='axes fraction', 
                xytext=(0, -labeloffset), textcoords='offset points', 
                verticalalignment='top', horizontalalignment='center')

def plot_alignment_properties(data, name, xlabels, titles, legend=None, show=True, xrange=None, yrange=None, colour_groups=None, spectrum=False, xlabel_font_size='x-small') :
    """
    Plot multidimensional data as line graphs. First dimension are y-variables plotted as separate lines/points, if there is a 3rd dimension, separate subplots are generated.
    "data" is a multidimensional numpy array; "name" is the filename used when saving an image file of the plot; "xlabels" are a list of x-axis labels and must have the length
    as dimension 2 of data; "title" are a list of plot/subplot labels; legend = list of legend names which must be the same length as data (1st dimension); if show=True an interactive plot is
    produced; "yrange" can be used to limit the range of the y-axis - should be tuple (miny,maxy).
    """
    
    data_dim = 1
    col = "dimgray"
    
    majorLocator   = MultipleLocator(100)
    majorFormatter = FormatStrFormatter('%d')
    minorLocator   = MultipleLocator(20)
    minorFormatter = FormatStrFormatter('%d')
    #pylab.subplots_adjust(bottom=0.2)

    num_lines = len(data)
    if spectrum :
        colour_map = pylab.cm.get_cmap("rainbow",num_lines)
        norm_map = pylab.cm.ScalarMappable(cmap=colour_map,norm=matplotlib.colors.Normalize(0,num_lines))

    if len(data.shape) > 2 :
        data_dim = data.shape[2]
        if data_dim > 9 :
            print "Warning not all variables are plotted"
        data_dim = min(data_dim,9)
        for subplot in range(data_dim) :
            subplot_index = data_dim*100+10+subplot+1
            plt = pylab.subplot(subplot_index)
            
            #plt.spines['bottom'].set_position(('outward', 40))
            #second_bottom = matplotlib.spines.Spine(plt, 'bottom', plt.spines['bottom']._path)
            #second_bottom.set_position(('outward', 10))
            #plt.spines['second_bottom'] = second_bottom
            #plt.spines['second_bottom'].axis = plt.xaxis
            #plt.spines['second_bottom'].axis.set_data_interval(0,100)
            #plt.spines['second_bottom'].axis.set_minor_locator(minorLocator)
            #plt.spines['second_bottom'].axis.set_major_locator(majorLocator)
            #ticks = plt.spines['second_bottom'].axis.get_major_ticks()
            #print "ticks"
            #print [i.get_label() for i in ticks]
        
            num_lines = len(data)
            for i in range(num_lines) :
                col = colours[0]
                plot = True
                if spectrum :
                    col = norm_map.to_rgba(i)
                elif colour_groups != None :
                    plot = False
                    for igroup in range(len(colour_groups)) :
                        if i in colour_groups[igroup] :
                            col = colours[(igroup+1)%len(colours)-1]
                            plot = True
                            break
                else :
                    col = colours[(i+1)%7-1]
                if plot :
                    plt.plot(data[i,:,subplot],color = col, marker='+', linewidth=2, alpha=0.8)
            
            if xlabels == None :
                plt.xaxis.set_major_locator(majorLocator)
                plt.xaxis.set_major_formatter(majorFormatter)                
                plt.xaxis.set_minor_locator(minorLocator)
                plt.xaxis.set_minor_formatter(minorFormatter)
                plt.xaxis.get_label().set_fontsize(20) # does nothing !^%$"%$
            elif type(xlabels) == str or type(xlabels) == list or len(xlabels.shape) == 1:    
                if len(xlabels[0]) > 1 :
                    pylab.xticks( pylab.arange(len(xlabels)), tuple(xlabels), size = xlabel_font_size, rotation=270)
                else :    
                    pylab.xticks( pylab.arange(len(xlabels)), tuple(xlabels), size = xlabel_font_size)
            elif len(xlabels.shape) == 2 :
                if len(xlabels[subplot,0]) > 1 :
                    pylab.xticks( pylab.arange(len(xlabels[subplot])), tuple(xlabels[subplot]), size = xlabel_font_size, rotation=270)
                else :    
                    pylab.xticks( pylab.arange(len(xlabels[subplot])), tuple(xlabels[subplot]), size = xlabel_font_size)
                    
                
            pylab.title(titles[subplot], fontsize=24)            
            pylab.plt.xlim((0,len(data[i])))
            if legend != None :
                # Shink current axis's height by 10% on the bottom
                box = plt.get_position()
                plt.set_position([box.x0, box.y0 + box.height * 0.1 * (subplot + 1), box.width, box.height * 0.9])

            if xrange != None :
                pylab.xlim(xrange[0], xrange[1])
            if yrange != None :
                pylab.ylim(yrange[0], yrange[1])
                
            

            #plt.xlabel('Dose')

            #
            ##for the minor ticks, use no labels; default NullFormatter
            #plt.xaxis.set_minor_locator(minorLocator)
            #
            #axis2 = plt.twiny() # create a second axes
            #axis2.spines["bottom"].set_position(("axes", -.1)) # move it down
            #axis2.plot(data[i,:,subplot],color = col, marker='+', linewidth=2, alpha=0.8)
            #axis2.xaxis.set_major_locator(FixedLocator([0,1,2,3]))
            #axis2.set_xticklabels(tuple(xlabels[subplot]), size = 'x-small')

            
            

    elif len(data.shape) == 2:
        plt = pylab.subplot(111)
        for i in range(data.shape[0]) :
            plot = True
            if colour_groups != None :
                plot = False
                for igroup in range(len(colour_groups)) :
                    if i in colour_groups[igroup] :
                        col = colours[(igroup+1)%len(colours) - 1]
                        plot = True
                        break
            else :
                col = colours[(i+1)%7 - 1] 
            if plot :
                plt.plot(data[i],color = col, marker='+', linewidth=2, alpha=0.8)
        if xlabels == None :
            plt.xaxis.set_major_locator(majorLocator)
            plt.xaxis.set_major_formatter(majorFormatter)                
            plt.xaxis.set_minor_locator(minorLocator)
            plt.xaxis.set_minor_formatter(minorFormatter)
        elif len(xlabels[0]) > 1 :
            pylab.xticks( pylab.arange(len(xlabels)), tuple(xlabels), size = 'x-small', rotation=270)
        else :    
            pylab.xticks( pylab.arange(len(xlabels)), tuple(xlabels), size = 'x-small')

        pylab.title(titles[0], fontsize=24)
        pylab.plt.xlim((0,len(data[i])))
        if legend != None :
            # Shink current axis's height by 10% on the bottom
            #axes = pylab.gca()
            #box = axes.get_position()
            #axes.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
            #box = plt.get_position()
            #plt.set_position([box.x0, box.y0 + box.height * 0.1 * (subplot + 1), box.width, box.height * 0.9])
            axes = pylab.gca()
            box = axes.get_position()
            axes.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
    else :
        plt = pylab.subplot(111)
        plt.plot(data,color = colours[0], marker='+', linewidth=2, alpha=0.8)
        if xlabels == None :
            plt.xaxis.set_major_locator(majorLocator)
            plt.xaxis.set_major_formatter(majorFormatter)                
            plt.xaxis.set_minor_locator(minorLocator)
            plt.xaxis.set_minor_formatter(minorFormatter)
        elif len(xlabels[0]) > 1 :
            pylab.xticks( pylab.arange(len(xlabels)), tuple(xlabels), size = 'x-small', rotation=270)
        else :    
            pylab.xticks( pylab.arange(len(xlabels)), tuple(xlabels), size = 'x-small')
        pylab.title(titles[0], fontsize=24)
        if legend != None :
            # Shink current axis's height by 10% on the bottom
            axes = pylab.gca()
            box = axes.get_position()
            axes.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
            
    if xrange != None :
        pylab.xlim(xrange[0], xrange[1])
    if yrange != None :
        pylab.ylim(yrange[0], yrange[1])
    
        
    if legend != None :
        
        leg = pylab.legend(legend, loc='upper center', bbox_to_anchor=(0.5, -0.05), fancybox=True, shadow=True, ncol=15)
        for t in leg.get_texts():
            t.set_fontsize('xx-small')
    
    pylab.savefig(name+".png")
    if show :
        pylab.show()
    # Reset figure
    #pylab.figure()
    #pylab.clf()

fibonacci = numpy.array([0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025, 121393, 196418, 317811])

def plot_contour_and_scatter(xy_array, bin_size, xmin, xmax, ymin, ymax, tick_spacing, colours=None, axis_labels=[]) :
    """
    take array of shape n, 2 where n is the number of points and plot a contour with scatter on top. 
    """ 
    x_grid_size = 1.0 + (xmax- xmin)/bin_size
    y_grid_size = 1.0 + (ymax- ymin)/bin_size
    grid = numpy.zeros(x_grid_size*y_grid_size)
    grid.shape = x_grid_size,y_grid_size

    for [x_coord,y_coord] in xy_array :

        # Find nearest grid point
        x_point = (x_coord-xmin)/bin_size
        y_point = (y_coord-ymin)/bin_size

        # Convert to integer and increase grid point count by one
        try :
            x_coord = int(round(x_point))
            y_coord = int(round(y_point))
        except ValueError :
            continue

        # Check that grid point is within range
        x_coord = max(x_coord,0.0)
        y_coord = max(y_coord,0.0)
        x_coord = min(x_coord,x_grid_size-1) 
        y_coord = min(y_coord,y_grid_size-1)
        grid[y_coord,x_coord] += 1
        
    # Smooth contours with gaussian filter
    grid = ndi.gaussian_filter(grid,1.25)
    
    levels = fibonacci[fibonacci<numpy.max(grid)]
    
    #pylab.contourf(grid,levels, cmap=pylab.get_cmap("GnBu"), alpha=0.2)
    pylab.contour(grid,levels, colors='orange')
    x = (xy_array[:,0]-xmin)/bin_size
    y = (xy_array[:,1]-ymin)/bin_size
    mask = x.mask | y.mask
    x.mask = mask
    y.mask = mask
    colours = [colours[i] for i in range(len(colours)) if not mask[i]]
    x = x.compressed().tolist()
    y = y.compressed().tolist()
    pylab.scatter(x,y, c=colours, alpha=0.5)
        
    pylab.xlim((0,x_grid_size-1))
    pylab.ylim((0,y_grid_size-1))
    pylab.xticks(pylab.arange(0,x_grid_size,tick_spacing/bin_size),pylab.arange(xmin,xmax+tick_spacing,tick_spacing), fontsize=16)
    pylab.yticks(pylab.arange(0,y_grid_size,tick_spacing/bin_size),pylab.arange(ymin,ymax+tick_spacing,tick_spacing), fontsize=16)
    
    if len(axis_labels) == 2 :
        pylab.xlabel(axis_labels[0], fontsize=24)
        pylab.ylabel(axis_labels[1], fontsize=24)

    pylab.show()

def plot_scatter(x,y,labels,cutoff=0, groups = None, show_labels = True, alpha=0.9, size=10, spectrum=False, show=True) :
    """
    Plot a scatter plot using pylab/matplotlib. Label each point using the given labels. Optionally colour by groups.  
    """
    if type(x) == numpy.ma.core.MaskedArray and type(y) == numpy.ma.core.MaskedArray:
        masks = x.mask | y.mask
        x = x[masks==False]
        y = y[masks==False]
        if show_labels :
            labels = numpy.array(labels)[masks==False]
    
    
    num_points = len(x)
    if groups != None and len(groups) == 1 :
        num_points = len(groups[0])

    if spectrum :
        colour_map = pylab.cm.get_cmap("rainbow",num_points) # blue to red
        norm_map = pylab.cm.ScalarMappable(cmap=colour_map,norm=matplotlib.colors.Normalize(0,num_points))
        colour_array = numpy.array([norm_map.to_rgba(i) for i in range(num_points)]) 
    else :
        colour_array = numpy.array([colours[0] for i in range(num_points)])


    if groups != None and len(groups) > 1:
        group_idx = 0
        num_choices = len(colours)
        for group in groups :
            choice = (group_idx + 1) % num_choices - 1
            if len(x[group]) != 0 :
                pylab.scatter(x[group],y[group], s=size, c=colours[choice], alpha=alpha)
            group_idx += 1
    elif groups != None and len(groups) == 1 and spectrum:
        pylab.scatter(x[groups[0]],y[groups[0]], s=size, c=colour_array, alpha=alpha)
    elif spectrum :
        pylab.scatter(x,y, s=size, c=colour_array, alpha=alpha)
    else :
        pylab.scatter(x,y, s=size, c='r', alpha=alpha)
    if show_labels :
        x_offset = (max(x) - min(x))/100 
        y_offset = (max(y) - min(y))/100 
        idx = 0
        for xc,yc in zip(x,y) :
            if abs(xc) >= cutoff or abs(yc) >= cutoff :
                pylab.text(xc-x_offset,yc+y_offset,labels[idx],horizontalalignment='right', verticalalignment='center', fontsize=8)
            idx += 1
            
    pylab.savefig("scatter.png")
    if show :
        pylab.show()
    
