"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import numpy, scipy
from Bio.Cluster import treecluster

class Node(object) :
    
    """
    Defines a Tree node. Has three properties left and right subtree connections and a distance value.
    """
    
    def __init__(self, left,right,distance) :
        self.left = left
        self.right = right
        self.distance = distance
    
    def __repr__(self) :
        return "("+str(self.left)+","+str(self.right)+") : "+str(self.distance)+"\n"
            
class Tree(object) :
    
    """
    Create tree and manipulate from distance NxN matrix, node names of size N. Wrapper for Bio.Cluster treecluster C program. See http://bonsai.ims.u-tokyo.ac.jp/~mdehoon/software/cluster/cluster.pdf for documentation. This tree type is designed to be **immutable**. Any changes to nodes numbers of connections will result in errors. Each node can have left and right subtrees. The size of a node is the number of leaf nodes in its smallest subtree. 
    
    Parameters
    ----------
    
    distmat : numpy array
        nxn square array containing distance values
        
    nodeNames : list
        n labels
        
    method : char
        's': pairwise single-linkage clustering; 'm': pairwise maximum- (or complete-) linkage clustering; 'a': (default) pairwise average-linkage clustering; 'c': pairwise centroid-linkage clustering
        
    scale : bool
        if set True (default) then scales branch lengths 0-100
        
    Examples
    --------
    
    >>> # Get/calculate selected property
    >>> properties = Properties()
    >>> array = properties.get_array("backbone", aligned, update)
    >>> 
    >>> # Calculate structure difference matrix
    >>> structmat = array.calculate_distance_matrix()
    >>> 
    >>> # Calculate tree using hierarchical clustering
    >>> ids = aligned.ids()
    >>> tree = Tree(structmat, ids, method = 'a', scale=False)
    >>> 
    >>> # Write out tree in newick format
    >>> tree.write_Newick_file(property+".newick")

    """
    
    def __init__(self, distmat, nodeNames, method = 'a', scale = True) :
        """
        Create tree from distance NxN matrix, node names of size N. Method default is agglomerative. See Bio.Cluster documentation for options. Scale = [True|False] default True.
        This scales branch distances to 0-1. Tree plotting programs such as Jalview 
        """
        
        print "Calculating tree from distance matrix"
        
        # Calculate tree using Bio.Cluster
        tree = treecluster(method=method,distancematrix=distmat.copy())

        # Scale to maximum distance is 1.0. Ensures that values are compatible with tree viewing packages such as Jalview
        if scale == True :
            tree.scale()
            #max_dist = max(distances)
            #if max_dist != 0.0 :
            #    for i in range(len(distances)) :
            #        distances[i] = 100.0 * distances[i]/max_dist 
        
        # Extract data and put into lists
        lefts = [tree[i].left for i in range(len(tree))]
        rights = [tree[i].right for i in range(len(tree))]
        distances = [tree[i].distance for i in range(len(tree))]

        # Create nodes
        self.distmat = distmat
        self.tree = [Node(lefts[i],rights[i],distances[i]) for i in range(len(tree))]
        self.ctree = tree
        self.nodeNames = nodeNames
        self.size = {}
        # Calculate size of each node based on the number of leafs below it in the tree
        for node in self.tree :
            left_leaves,right_leaves = self.left_right_leaves(node)
            self.size[node] = (len(left_leaves),len(right_leaves))
        self.left_left = {}
        self.right_right = {}
        self.left_right = {}
        self.left_left_sc = {}
        self.right_right_sc = {}
        self.left_right_sc = {}
        self.left_rep = {}
        self.right_rep = {}
        self.cluster_number = {}
        
    def __repr__(self) :
        str = ""
        for node in self.tree :
            str += node.__repr__()
        return str
        
    def __getitem__(self, idx) :
        return self.tree[idx]
        
    def _contains(self, node, nodes) :
        """
        return True if node is in list of nodes, otherwise return False
        """
        for i in nodes :
            if i.left == node.left and i.right == node.right :
                return True
        return False

    def _printTree(self, node, file) :
        """
        recursive function for creating Newick format tree
        """
        left = node.left
        right = node.right
        dist = '%.6f'%node.distance
        file.write("(")
        if (left) < 0 :
            # left
            self._printTree(self.tree[-left-1], file)
        else :
            file.write(str(self.nodeNames[left]))
        file.write(":"+str(dist)+",")
        if (right) < 0 :
            self._printTree(self.tree[-right-1], file)
        else :
            file.write(str(self.nodeNames[right]))
        file.write(":"+str(dist)+")")
    
    def get_root_node(self) :
        """
        Return the root node
        """
        return self.tree[len(self.tree)-1]
    
    def get_names_for_node_numbers(self,node_numbers) :
        """
        Return list of node names for a list of node numbers
        """
        names = []
        for node_number in node_numbers :
            names.append(self.nodeNames[node_number])
        return names

    def gather_leaves(self, node, leaves) :
        """
        Return a list of all leaf nodes below a given node
        """
        left = node.left
        right = node.right
        if (left) < 0 :
            self.gather_leaves(self.tree[-left-1], leaves)
        else :
            leaves.append(left)
        if (right) < 0 :
            self.gather_leaves(self.tree[-right-1], leaves)
        else :
            leaves.append(right)
            
    def left_right_leaves(self,node) :
        """
        Return two lists, the containing leaf nodes in the left and right hand branches respectively from a given node.
        """
        left_leaves = []
        right_leaves = []
        left_fork = node.left
        if left_fork < 0 :
            self.gather_leaves(self.tree[-left_fork-1], left_leaves)
        else :
            left_leaves.append(left_fork)
        right_fork = node.right
        if right_fork < 0 :
            self.gather_leaves(self.tree[-right_fork-1], right_leaves)
        else :
            right_leaves.append(right_fork)
        return left_leaves,right_leaves
    
    def all_leaves(self) :
        """
        Return list of all leaf nodes
        """
        lefts,rights = self.left_right_leaves(self.get_root_node())
        return lefts+rights
        
    def write_Newick_file(self, filename) :
        """
        Create a Newick format file within given file name for whole tree.
        """
        tree_file = open(filename, "w")
        rootnode = self.get_root_node()
        self._printTree(rootnode, tree_file)
        tree_file.write(";\n");
        tree_file.close()
    
    def compare_nodes(self, node1, node2) :
        """
        Return 1 if node1 is bigger than node2, 0 if they are equal, -1 if node2 is bigger. Node size is defined as the number leaf nodes in the smallest subbranch.
        """
        smallest_branch1 = min(self.size[node1][0],self.size[node1][1])
        smallest_branch2 = min(self.size[node2][0],self.size[node2][1])
        if smallest_branch1>smallest_branch2:
            return 1
        elif smallest_branch1==smallest_branch2:
            return 0
        else:
            return -1
        
    def get_biggest_nodes(self, number_of_nodes=1) :
        """
        Return number_of_nodes biggest nodes as a list in descending order.
        """
        nodes = [i for i in self.tree]
        nodes.sort(self.compare_nodes, reverse=True)
        return nodes[:number_of_nodes]

    def get_biggest_grouping(self) :
        """
        Return list of leaf nodes attached to the biggest node.
        """
        node = self.get_biggest_nodes()
        return list(self.left_right_leaves(node))
                    
    def biggest_left_right_others(self, number_of_nodes = 1) :
        """
        This finds the biggest (or more) pair of subtrees where the size is determined by the number of nodes in the smaller subtree. It returns a list containing sublists in threes. Each triplet of lists are leaf nodes in the left, right subbranches of nodes and all other leaf nodes in the tree. 
        """
        biggest_nodes = self.get_biggest_nodes(number_of_nodes)
        groups = []
        others = set(self.all_leaves())
        for node in biggest_nodes :
            lefts,rights = self.left_right_leaves(node)
            groups.append(lefts)
            groups.append(rights)
            others = others.difference(lefts).difference(rights)
        groups.append(list(others))
        return groups
    
    def flat_clusters(self, t) :
        """
        Create num_clusters flat clusters. The current implementation uses scipy.cluster heirarchical clustering rather than a method from within Biopython.
        """
        # Use scipy flatclustering method
        if type(t) == int :
            clist = self._scipy_clusters(t, criterion='maxclust')
        else :
            clist = self._scipy_clusters(t, criterion='distance')
            
        num_clusters = max(clist)+1
        clist = list(clist)

        # Create list of lists of alignment indices
        groups = [[j for j in range(len(clist)) if clist[j] == i] for i in range(num_clusters)]
        return groups
    
    def node_names_for_groups(self, groups):
        """
        Return a list of leaf node names for list of lists of node indices
        """
        group_names = [[self.nodeNames[j] for j in groups[i]] for i in range(len(groups))]
        return group_names
    
    def cut(self, num_clusters) :
        """
        Cut the tree into a num_clusters groupings and return list of list of node indices.
        """
        clist =  self.ctree.cut(num_clusters)
        print clist
        num_clusters = max(clist)+1
        groups = [[j for j in range(len(clist)) if clist[j] == i] for i in range(num_clusters)]
        return groups
    
    def _scipy_clusters(self, t, criterion='maxclust') :
        """
        Generate flat clusters using scipy.cluster.
        
        Parameters
        ----------

        t : float
            the number of clusters or the min distance within a cluster
            
        criterion : string
            can be 'maxclust' (default) which limits to the number of clusters to t, or 'distance' which set the max distance between nodes in a cluster to t
        """
        from scipy import cluster
        condensed_matrix = scipy.spatial.distance.squareform(self.distmat)
        linkage_matrix = cluster.hierarchy.linkage(condensed_matrix, method='complete')
        clist = cluster.hierarchy.fcluster(linkage_matrix, t, criterion=criterion)
        clist = clist - 1 # cluster numbers begin a 1
        return clist

    def _calculate_cluster_centroids(self, num_clusters, clist, data) :
        """
        Calculate centroid for each cluster and put result in a numpy masked array
        """
        from Bio.Cluster import clustercentroids
        centroids = numpy.ma.zeros((num_clusters, data.shape[1]))
        centroids.mask = False
        cdata, cmask = clustercentroids(data.data, mask=data.mask==False, clusterid=clist)
        for i in range(num_clusters) :
            centroids.data[i] = cdata[i]
            centroids.mask[i] = cmask[i] == 0
        return centroids

    def _find_closest_to_centroid(self, num_clusters, clist, centroids, data) :
        """
        Find structure, within each cluster, that is closest to centroid 
        """

        # Create list of lists of alignment indices
        groups = [[j for j in range(len(clist)) if clist[j] == i] for i in range(num_clusters)]

        # Find structure, within each cluster, that is closest to centroid 
        closest_indices = []
        closest_ids = []
        for i in range(num_clusters) :
            # Euclidean distance
            diffs = data[groups[i]] - centroids[i]
            diffs_sqr = diffs ** 2
            dists = numpy.ma.sum(diffs_sqr, axis=1)
            # Find smallest distance
            closest_indx = groups[i][dists.argsort()[0]]
            closest_indices.append(closest_indx)
            closest_ids.append(self.nodeNames[closest_indx])
        return closest_indices, closest_ids

    def non_redundant_set(self, distance_cutoff, array) :
        """
        Return a list of non-redundant structures. Cut the tree into clusters where all structures within a cluster are within distance_cutoff of each other, find the centroid of each cluster in property space, then find the structure closest to this centroid. The current implementation uses scipy.cluster heirarchical clustering rather than the standard method from within Biopython.
        
        Parameters
        ----------

        distance_cutoff : float
            maximum distance between any structure within a cluster.  
            
        array : Structural_Alignment_Property_Array object
            the structural property array used to calculate the centroid of each cluster
            
        Returns
        -------
        
        closest_indices : list of int
            the alignment indices of the selected structures
            
        closest_ids : list of str
            the name codes of the selected structures
        
        """
        # Extract data from property array object and reshape into 2D array if necessary
        data = array.data.copy()        
        data.shape = array.size, array.length * array.data_dim
        
        # print stats on distances
        print "min, max, mean, median distance", numpy.ma.min(self.distmat), numpy.ma.max(self.distmat), numpy.ma.mean(self.distmat), numpy.ma.median(self.distmat)

        # Use scipy flatclustering method
        clist = self._scipy_clusters(distance_cutoff, criterion='distance')

        num_clusters = max(clist)+1
        clist = list(clist)
        print "redundant cluster sizes: ", [clist.count(i) for i in range(num_clusters)] 

        # Find cluster centoids
        centroids = self._calculate_cluster_centroids(num_clusters, clist, data)
        
        # Find closest structure to each centroid
        closest_indices, closest_ids = self._find_closest_to_centroid(num_clusters, clist, centroids, data)
            
        return closest_indices, closest_ids
        
    def cluster_representatives(self, num_clusters, array) :
        """
        Return a list of representative structures. Cut the tree into a num_clusters clusters, find the centroid of each cluster in property space, then find the structure closest to this centroid. The current implementation uses scipy.cluster heirarchical clustering rather than the standard method from within Biopython.
        
        Parameters
        ----------

        num_clusters : int
            the number of clusters required
            
        array : Structural_Alignment_Property_Array object
            the structural property array used to calculate the centroid of each cluster
            
        Returns
        -------
        
        closest_indices : list of int
            the alignment indices of the selected structures
            
        closest_ids : list of str
            the name codes of the selected structures
        
        """
        # Extract data from property array object and reshape into 2D array if necessary
        data = array.data.copy()        
        data.shape = array.size, array.length * array.data_dim


        # Use scipy flatclustering method
        clist = self._scipy_clusters(num_clusters)

        # Use recalculated hierarchical cluster
        #clist = self.ctree.cut(num_clusters)

        # Use k-mean clustering
        #from Bio.Cluster import kcluster
        #clist, error, nfound = kcluster(data.data, nclusters=num_clusters, mask=data.mask==False, weight=None, transpose=0, npass=1, method='m', dist='c', initialid=None)
        
        # Use K-mediods clustering 
        #from Bio.Cluster import kmedoids
        #clist, error, nfound = kmedoids(self.distmat, nclusters=num_clusters, npass=1000, initialid=None)
        #print error, nfound
        #closest_indices = numpy.array(list(set(clist)))
        #closest_indices -= 1 # numbers output k kmedoids begin at 1?
        #closest_ids = [self.nodeNames[i] for i in closest_indices]
        #return closest_indices, closest_ids

        num_clusters = max(clist)+1
        clist = list(clist)
        print "cluster sizes: ", [clist.count(i) for i in range(num_clusters)] 

        # Find cluster centoids
        centroids = self._calculate_cluster_centroids(num_clusters, clist, data)
        
        # Find closest structure to each centroid
        closest_indices, closest_ids = self._find_closest_to_centroid(num_clusters, clist, centroids, data)
            
        return closest_indices, closest_ids
        
    def num_nodes(self) :
        """
        Return the number of leaf nodes in the tree.
        """
        return len(self.nodeNames)

        