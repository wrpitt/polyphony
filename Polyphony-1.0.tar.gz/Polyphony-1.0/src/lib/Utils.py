"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import time, os, numpy, sys
import scipy.stats as stats
from Polyphony.Initial import CONFIG
from optparse import OptionParser

def ids_from_id(chain_id, blank_chain_null=False) :
    """
    Extract pdb code, model number and chain letter from structure id
    """
    ## remove Jalview residue range postfix
    #chain_id = chain_id.split('/')
    #if len(chain_id) > 1 :
    #    chain_id = chain_id[0]
    #
    # split in to pdb id, chain letter and optionally model number
    id_list = chain_id.split('_')
    pdb_code = id_list[0]
    chain_letter = id_list[-1]
    if len(chain_letter) == 0 :
        if blank_chain_null :
            chain_letter = ''
        else :
            chain_letter = ' '
            
    if len(id_list) == 3 : # chain_id of format 2K39_1_A where 1 is the model number
        model_no = int(id_list[1])
        pdb_code += "_"+str(model_no)
    else :
        model_no = None
    return pdb_code, model_no, chain_letter    

class Properties(object) :
    """
    Class allowing calculation of residue based property arrays are a given alignment in a generic way. The selection of property types is read from the polyphony.cfg file. This allows the use of plugin property calculation classes.
    
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> properties = Properties()
    >>> array = properties.get_array("backbone", aligned, update)

    """
    
    def __init__(self) :
        items = CONFIG.items("properties")
        # Human readable name for each property
        self._names = [i[0] for i in items]
        # File where property definition class resides
        self._modules = {}
        for i in items : self._modules[i[0]] = i[1].split(",")[0].strip()
        # Name of Property_Alignment_Array classes
        self._classes = {}
        for i in items : self._classes[i[0]] = i[1].split(",")[1].strip()
        
    def get_array(self, property_name, alignment, update=False) :
        """
        return array of given property type for given Structural_Alignment. Property will be
        calculated from scratch if update=True otherwise it will be read from disk (if available precalculated)

        Parameters
        ----------
        
        property_name : string
            one of the property names in the polyphony.cfg file e.g. "backbone"
    
        alignment : Structural_Alignment instance
            the alignment to which the descriptor applies
    
        update : bool
            if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.       
        """

        if self._is_recognised(property_name) :
            module_name = self._modules[property_name]
            Class_name = self._classes[property_name]

        # import required class if not already imported
        exec("from " + module_name + " import " + Class_name)
        
        # get array values
        array = eval(Class_name)(alignment, update) 
        return array
    
    def _is_recognised(self, property_name) :
        """
        Return True if property_name is only of the names found in the config file. Otherwise return list of options.
        """
        if not property_name in self._names :
            raise KeyError("'"+property_name+"' was not recognised. Options are: "+str(self._names))
        return True
    
    def get_names(self) :
        """
        Return list of allowed property names
        """
        return self._names
    
    def get_options(self) :
        """
        Return single string of property names for option parser help
        """
        return "|".join(self._names)
        
class Calculate_Write_Read(object) :
    
    """
    Base class for sequence property array classes and any other classes that contain numpy arrays of data which
    can be time consuming to calculate. It contains methods that provide the mechanism for the storage and re-use of
    these arrays. The defaults is to store in values in numpy masked arrays. Gaps and other residue positions for which properties
    cannot be calculated are masked out, so that averages and other calculations are calculated without fuss.
    
    Derived classes must provide _calculate(self) function that returns calculated data as a numpy array.
    The _calculate_and_write method is designed to be run once on object initiation and will either calculate
    new data and store it for future use or read precalculated data. The update=True option will force recalculation.
    """

    def __init__(self, id, update) :
        """
        Try and read precalcated data stored in a specified file. If that
        file does not exist, calculate the data instead and store it in said
        file. If update==True calculate anyway.
        """
        self.id = id
        filename = self._get_file_name(id)
        prefix = id[:4].lower() 
        if update == False and prefix != "temp":
            try :
                return self._read(filename)
            except IOError :
                print "Unable to read ", filename
                return self._calculate_and_write(filename, update)
        else: 
            return self._calculate_and_write(filename, update)

    def _read(self, filename) :
        """
        Read precomputed results into an array
        """
        #sys.stdout.write('\r')
        sys.stdout.write("Reading array of type "+self.__class__.__name__+" for "+self.id+"\n")        
        sys.stdout.flush()
        if os.access(filename,os.F_OK) == False :
            raise IOError
        else :
            return numpy.ma.load(filename)
        
    def _calculate_and_write(self, filename, update) :
        """
        Calculate data and store in a file.
        """
        #sys.stdout.write('\r')
        sys.stdout.write("Creating array of type "+self.__class__.__name__+" for "+self.id+"\n")                
        sys.stdout.flush()
        data = self._calculate()
        self._write(data, filename)
        return data
                        
    def _get_file_name(self, id) :
        """
        Create a filename based upon information in the Polyphony.cfg data (directory root), the derived class (subdirectory)
        and the provided id (file name).
        """
        directory = CONFIG.get('directories','data')+self.data_directory
        # if directory doesn't exist, make it (thanks Lorenzo)
        if not os.path.isdir(directory): 
           os.mkdir(directory)
        filename = directory+"/"+id+".npy"
        return filename

    def _write(self, data, filename) :
        """
        Store array in binary file.
        """
        numpy.ma.dump(data, filename)

def print_timing(func):
    """
    Put "@print_timing" on the file prior to the function definition for which you would like to time the execution 
    """
    def wrapper(*arg, **kwargs):
        t1 = time.time()
        res = func(*arg, **kwargs)
        t2 = time.time()
        print '%s took %0.3f ms' % (func.func_name, (t2-t1)*1000.0)
        return res
    return wrapper

class dummyStream(object) :
    """
    DummyStream behaves like a stream but does nothing ie no messages are sent to the screen. 
    """
    def __init__(self): pass
    def write(self,data): pass
    def read(self,data): pass
    def flush(self): pass
    def close(self): pass

def run_silently(func, *args) :
    """
    If you want to surpress any output or error messages produced by and given
    function, run it as a parameter of run_silently. Arguments must be provided as a comma separated list.
    """
    # Turn off printing (too verbose warnings)
    old_stdout,old_stderr=sys.stdout,sys.stderr 
    sys.stdout,sys.stderr=dummyStream(),dummyStream()
    # run function
    results = func(*args)        
    # Turn printing back on
    sys.stdout,sys.stderr=old_stdout,old_stderr
    # return results
    return results

def jalview_pdb_chain_label(chain_id) :
    """
    This format of sequence id for a pdb file sequence will allow Jalview to recognise the
    sequence and to interrogate various databases for sequence annotations. However, it won't
    work if the sequence differs from the Jalview reference sequence.
    """
    pdb_code, model_no, chain_letter = ids_from_id(self.pdb_chain_code)

    return "PDB|"+pdb_code+"|"+pdb_code+"|"+chain_letter

def _add_file_option(parser) :
    parser.add_option("-f", "--file", dest="fasta_file", help="name of a fasta file created with create_fasta_file.py", metavar="FILE")

def _add_property_option(parser) :
    # Get Polyphony properties
    properties = Properties()
    parser.add_option("-p", "--property", dest="property", help="type of property to calculate, can be ["+properties.get_options()+"]",
                      choices=properties.get_names(), default="backbone")

def _add_update_option(parser) :
    parser.add_option("-u", "--update", dest="update", help="use this option if you want to recalculate property data", default=False, action="store_true")

def _add_align_pos_option(parser) :
    parser.add_option("-a", "--alignment_positions", dest="alignment_positions", help="list of one or more integers separated by commas, representing alignment positions (which start at 0)")

def _add_dimensions_option(parser) :
    parser.add_option("-d", "--dimensions", dest="dimensions", help="list of one or more integers separated by commas representing property dimensions (which start at 0) e.g. \"212,220,232\" ")

def _check_file(filename) :
    if filename == None :
        sys.exit("!!!Error. Please provide use -f fasta_file_name or -h for help")
    if filename.split('.')[-1] != "fasta" :
        sys.exit("!!!Error. Your file name should have the .fasta extension.")

def _update_warning(update) :
    if update == True :
        print "Property data will be updated. This can take some time for a large alignment."

def _int_list(istring) :
    ilist = istring.split(',')
    return [int(i) for i in ilist]
    
def read_command_line_file_property_positions_and_dimensions(usage=None):
    """
    Read and check command line options. A fasta alignment file must be provided. A property name should also be specified as well as other possible options.
    """
    # Define commnad line parser options
    parser = OptionParser(usage=usage)    
    _add_file_option(parser)
    _add_property_option(parser)
    _add_update_option(parser)
    _add_align_pos_option(parser)
    _add_dimensions_option(parser)

    (options, args) = parser.parse_args()
    
    # Check options selected by user
    _check_file(options.fasta_file)
    _update_warning(options.update)
    
    return options.fasta_file, options.update, options.property, _int_list(options.alignment_positions), _int_list(options.dimensions)

def read_command_line_file_property_and_groups(usage=None):
    """
    Read and check command line options. A fasta alignment file must be provided. A property name should also be specified as well as other possible options.
    """
    # Get Polyphony properties
    properties = Properties()
    # Define commnad line parser options
    parser = OptionParser(usage=usage)    
    parser.add_option("-f", "--file", dest="fasta_file", help="name of a fasta file created with create_fasta_file.py", metavar="FILE")
    parser.add_option("-p", "--property", dest="property", help="type of property to calculate, can be ["+properties.get_options()+"]",
                      choices=properties.get_names(), default="backbone")
    parser.add_option("-g", "--groups", dest="groups", type="int", help="optional group by sequence identity cutoff. Use by specifying a percentage to use e.g. 90", default=90)
    parser.add_option("-u", "--update", dest="update", help="use this option if you want to recalculate property data", default=False, action="store_true")
    
    (options, args) = parser.parse_args()        
    
    if options.fasta_file == None :
        sys.exit("!!!Error. Please provide use -f fasta_file_name or -h for help")
        
    if options.fasta_file.split('.')[-1] != "fasta" :
        sys.exit("!!!Error. Your file name should have the .fasta extension.")
        
    if options.update == True :
        print "Property data will be updated. This can take some time for a large alignment."
    
    return options.fasta_file, options.update, options.property, options.groups

def read_command_line_file_and_property(usage=None):
    """
    Read and check command line options. A fasta alignment file must be provided. A property name should also be specified as well as other possible options.
    """
    # Get Polyphony properties
    properties = Properties()
    # Define commnad line parser options
    parser = OptionParser(usage=usage)    
    parser.add_option("-f", "--file", dest="fasta_file", help="name of a fasta file created with create_fasta_file.py", metavar="FILE")
    parser.add_option("-p", "--property", dest="property", help="type of property to calculate, can be ["+properties.get_options()+"]",
                      choices=properties.get_names(), default="backbone")
    parser.add_option("-u", "--update", dest="update", help="use this option if you want to recalculate property data", default=False, action="store_true")
    
    (options, args) = parser.parse_args()        
    
    if options.fasta_file == None :
        sys.exit("!!!Error. Please provide use -f fasta_file_name or -h for help")
        
    if options.fasta_file.split('.')[-1] != "fasta" :
        sys.exit("!!!Error. Your file name should have the .fasta extension.")
        
    if options.update == True :
        print "Property data will be updated. This can take some time for a large alignment."
    
    return options.fasta_file, options.update, options.property

def read_command_line_file_property_and_number(usage=None) :
    """
    Read and check command line options. A fasta alignment file must be provided. A property name should also be specified as well as a number.
    """
    # Get Polyphony properties
    properties = Properties()
    # Define commnad line parser options
    parser = OptionParser(usage=usage)    
    parser.add_option("-f", "--file", dest="fasta_file", help="name of a fasta file created with create_fasta_file.py", metavar="FILE")
    parser.add_option("-p", "--property", dest="property", help="type of property to calculate, can be ["+properties.get_options()+"]",
                      choices=properties.get_names(), default="backbone")
    parser.add_option("-n", "--number", dest="number", help="input a number", type = "float")
    parser.add_option("-u", "--update", dest="update", help="use this option if you want to recalculate property data", default=False, action="store_true")
    
    (options, args) = parser.parse_args()        
    
    if options.fasta_file == None :
        sys.exit("!!!Error. Please provide use -f fasta_file_name or -h for help")
        
    if options.fasta_file.split('.')[-1] != "fasta" :
        sys.exit("!!!Error. Your file name should have the .fasta extension.")
        
    if options.number == None :
        sys.exit("!!!Error. Please provide a number with the -n option.")

    if options.update == True :
        print "Property data will be updated. This can take some time for a large alignment."
    
    return options.fasta_file, options.update, options.property, options.number

def read_command_line_file_and_string(usage=None) :
    """
    Read and check command line options. A fasta alignment file must be provided. A property name should also be specified as well as a number.
    """
    # Get Polyphony properties
    properties = Properties()
    # Define commnad line parser options
    parser = OptionParser(usage=usage)    
    parser.add_option("-f", "--file", dest="fasta_file", help="name of a fasta file created with create_fasta_file.py", metavar="FILE")
    parser.add_option("-g", "--string", dest="string", help="input a string", type = "str")
    parser.add_option("-u", "--update", dest="update", help="use this option if you want to recalculate property data", default=False, action="store_true")
    
    (options, args) = parser.parse_args()        
    
    if options.fasta_file == None :
        sys.exit("!!!Error. Please provide use -f fasta_file_name or -h for help")
        
    if options.fasta_file.split('.')[-1] != "fasta" :
        sys.exit("!!!Error. Your file name should have the .fasta extension.")
        
    if options.string == None :
        sys.exit("!!!Error. Please provide a string with the -g option.")

    if options.update == True :
        print "Property data will be updated. This can take some time for a large alignment."
    
    return options.fasta_file, options.update, options.string

def read_command_line_file_property_and_bool(usage=None) :
    """
    Read and check command line options. A fasta alignment file must be provided. A property name should also be specified as well as a number.
    """
    # Get Polyphony properties
    properties = Properties()
    # Define commnad line parser options
    parser = OptionParser(usage=usage)    
    parser.add_option("-f", "--file", dest="fasta_file", help="name of a fasta file created with create_fasta_file.py", metavar="FILE")
    parser.add_option("-p", "--property", dest="property", help="type of property to calculate, can be ["+properties.get_options()+"]",
                      choices=properties.get_names(), default="backbone")
    parser.add_option("-b", "--bool", dest="bool", help="use this option to select on/off behaviour", default=False, action="store_true")
    parser.add_option("-u", "--update", dest="update", help="use this option if you want to recalculate property data", default=False, action="store_true")
    
    (options, args) = parser.parse_args()        
    
    if options.fasta_file == None :
        sys.exit("!!!Error. Please provide use -f fasta_file_name or -h for help")
        
    if options.fasta_file.split('.')[-1] != "fasta" :
        sys.exit("!!!Error. Your file name should have the .fasta extension.")
        
    if options.update == True :
        print "Property data will be updated. This can take some time for a large alignment."
    
    return options.fasta_file, options.update, options.property, options.bool

def read_command_line_file(usage=None):
    """
    Read and check command line options. Only a fasta alignment file must be provided.
    """
    # Get Polyphony properties
    properties = Properties()
    # Define commnad line parser options
    parser = OptionParser(usage=usage)    
    parser.add_option("-f", "--file", dest="fasta_file", help="name of a fasta file created with create_fasta_file.py", metavar="FILE")
    parser.add_option("-u", "--update", dest="update", help="use this option if you want to recalculate property data", default=False, action="store_true")
    
    (options, args) = parser.parse_args()        
    
    if options.fasta_file == None :
        sys.exit("!!!Error. Please provide use -f fasta_file_name or -h for help")
        
    if options.fasta_file.split('.')[-1] != "fasta" :
        sys.exit("!!!Error. Your file name should have the .fasta extension.")
            
    if options.update == True :
        print "Property data will be updated. This can take some time for a large alignment."
    
    return options.fasta_file, options.update

#def read_command_line_file_and_string(usage=None):
#    """
#    Read and check command line options. A fasta alignment file and a string must be provided.
#    """
#    # Get Polyphony properties
#    properties = Properties()
#    # Define commnad line parser options
#    parser = OptionParser(usage=usage)    
#    parser.add_option("-f", "--file", dest="fasta_file", help="name of a fasta file created with create_fasta_file.py", metavar="FILE")
#    parser.add_option("-s", "--string", dest="string", help="string", default=None)
#    parser.add_option("-u", "--update", dest="update", help="use this option if you want to recalculate property data", default=False, action="store_true")
#    
#    (options, args) = parser.parse_args()        
#    
#    if options.fasta_file == None :
#        sys.exit("!!!Error. Please provide use -f fasta_file_name or -h for help")
#        
#    if options.fasta_file.split('.')[-1] != "fasta" :
#        sys.exit("!!!Error. Your file name should have the .fasta extension.")
#            
#    if options.update == True :
#        print "Property data will be updated. This can take some time for a large alignment."
#    
#    return options.fasta_file, options.string, options.update

class SymNDArray(numpy.ndarray):
    """
    For numpy 2D array with only lower trangle populated (non-zero), where i>j, a[i,j] returns a[j,i]
    """
    def __getitem__(self, (i, j)):
        if i < j :
            numpy.ndarray.__getitem__(self, (i, j))
        else :
            numpy.ndarray.__getitem__(self, (j, i))            
 
def reduce(array, method="gmean"):
    """
    If multidimensional masked array, reduce 2d array to 1d or 3d to 2d. Default is the geometric mean.
    """
    if len(array.shape) > 1:
        if method == "gmean" :
            new_array = numpy.ma.array(stats.gmean(array, axis=len(array.shape)-1)) # new data is geomean of last dimension
        elif method == "sum" :
            new_array = numpy.ma.sum(array, axis=len(array.shape)-1)
        elif method == "sum_abs" :
            new_array = numpy.ma.sum(numpy.absolute(array), axis=len(array.shape)-1)
        elif method == "max_abs" :
            new_array = numpy.ma.max(numpy.absolute(array), axis=len(array.shape)-1)
        elif method == "max_abs_signed" : # max absolute value, negative if sum of values are less than 0
            new_array = numpy.ma.max(numpy.absolute(array), axis=len(array.shape)-1)
            sum = numpy.ma.sum(array, axis=len(array.shape)-1)
            new_array *= numpy.sign(sum)
        else :
            raise NotImplementedError 
       
        if type(array) == numpy.ma.core.MaskedArray :
            if len(array.shape) == 2 :
                new_array.mask = array.mask[:,0] # new mask is mask of first value of last dimension
            elif len(array.shape) == 3 :
                new_array.mask = array.mask[:,:,0] # new mask is mask of first value of last dimension
            else :
                raise TypeError("A maximum of 3 dimensions please")
           
        return new_array
    else :
        return array
    
def get_sliding_window_index(window_length, length) :
    """
    Return an index that can be used for calculating sliding window properties by slicing a 1d array.
    """
    # Setup sliding window indexing    
    half_window = window_length/2
    start=half_window
    end=length-half_window
    index=range(start,end)
    window_index = [range(i-half_window,i+half_window+1) for i in index]
    return window_index

# This table is taken from the RAF release notes, and includes the
# undocumented mapping "UNK" -> "X. Extracted from Bio.SCOP.Raf when is disappeared from later versions.

to_one_letter_code= {
    'ALA':'A', 'VAL':'V', 'PHE':'F', 'PRO':'P', 'MET':'M',
    'ILE':'I', 'LEU':'L', 'ASP':'D', 'GLU':'E', 'LYS':'K',
    'ARG':'R', 'SER':'S', 'THR':'T', 'TYR':'Y', 'HIS':'H',
    'CYS':'C', 'ASN':'N', 'GLN':'Q', 'TRP':'W', 'GLY':'G',
    '2AS':'D', '3AH':'H', '5HP':'E', 'ACL':'R', 'AIB':'A',
    'ALM':'A', 'ALO':'T', 'ALY':'K', 'ARM':'R', 'ASA':'D',
    'ASB':'D', 'ASK':'D', 'ASL':'D', 'ASQ':'D', 'AYA':'A',
    'BCS':'C', 'BHD':'D', 'BMT':'T', 'BNN':'A', 'BUC':'C',
    'BUG':'L', 'C5C':'C', 'C6C':'C', 'CCS':'C', 'CEA':'C',
    'CHG':'A', 'CLE':'L', 'CME':'C', 'CSD':'A', 'CSO':'C',
    'CSP':'C', 'CSS':'C', 'CSW':'C', 'CXM':'M', 'CY1':'C',
    'CY3':'C', 'CYG':'C', 'CYM':'C', 'CYQ':'C', 'DAH':'F',
    'DAL':'A', 'DAR':'R', 'DAS':'D', 'DCY':'C', 'DGL':'E',
    'DGN':'Q', 'DHA':'A', 'DHI':'H', 'DIL':'I', 'DIV':'V',
    'DLE':'L', 'DLY':'K', 'DNP':'A', 'DPN':'F', 'DPR':'P',
    'DSN':'S', 'DSP':'D', 'DTH':'T', 'DTR':'W', 'DTY':'Y',
    'DVA':'V', 'EFC':'C', 'FLA':'A', 'FME':'M', 'GGL':'E',
    'GLZ':'G', 'GMA':'E', 'GSC':'G', 'HAC':'A', 'HAR':'R',
    'HIC':'H', 'HIP':'H', 'HMR':'R', 'HPQ':'F', 'HTR':'W',
    'HYP':'P', 'IIL':'I', 'IYR':'Y', 'KCX':'K', 'LLP':'K',
    'LLY':'K', 'LTR':'W', 'LYM':'K', 'LYZ':'K', 'MAA':'A',
    'MEN':'N', 'MHS':'H', 'MIS':'S', 'MLE':'L', 'MPQ':'G',
    'MSA':'G', 'MSE':'M', 'MVA':'V', 'NEM':'H', 'NEP':'H',
    'NLE':'L', 'NLN':'L', 'NLP':'L', 'NMC':'G', 'OAS':'S',
    'OCS':'C', 'OMT':'M', 'PAQ':'Y', 'PCA':'E', 'PEC':'C',
    'PHI':'F', 'PHL':'F', 'PR3':'C', 'PRR':'A', 'PTR':'Y',
    'SAC':'S', 'SAR':'G', 'SCH':'C', 'SCS':'C', 'SCY':'C',
    'SEL':'S', 'SEP':'S', 'SET':'S', 'SHC':'C', 'SHR':'K',
    'SOC':'C', 'STY':'Y', 'SVA':'S', 'TIH':'A', 'TPL':'W',
    'TPO':'T', 'TPQ':'A', 'TRG':'K', 'TRO':'W', 'TYB':'Y',
    'TYQ':'Y', 'TYS':'Y', 'TYY':'Y', 'AGM':'R', 'GL3':'G',
    'SMC':'C', 'ASX':'B', 'CGU':'E', 'CSX':'C', 'GLX':'Z',
    'PYX':'C',
    'UNK':'X'
    }

