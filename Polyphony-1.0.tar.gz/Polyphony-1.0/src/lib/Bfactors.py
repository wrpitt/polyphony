"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Property_Arrays import Structure_Property_Array, Structural_Alignment_Property_Array
from Polyphony.Utils import to_one_letter_code
import numpy

class Bfactor_Array(Structure_Property_Array) :
    
    """
    Class to store (or read) the temperature factor (b-factors) of the C-alpha atoms of a protein chain.
    """
    
    data_type = float       # data is Calpha b-factor
    data_dim = 1            # 1 dimensional data i.e. 1 value per residue
    dim_names = ["bfactor"]
    data_directory = "bfactors"     # directory where calculated results are stored
    padding = 0             # number of residues to mask out either side of gaps and at termini

    def __init__(self, alignment, alignment_index, update = False) :
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)
            
    def _calculate(self) :
        """
        Extract b-factors from a pdb file and store results in an array
        """
        
        # Get Bio:PDB residue objects
        residues = self.alignment.get_residues(self.pdb_chain_code)
        bfactor_list = []
        for res in residues:
            try:
                bfactor_list.append(res["CA"].get_bfactor())
            except KeyError:
                # This shouldn't happen because only residues with CA atoms should be included as input
                bfactor_list.append(-99.0)

        array = numpy.ma.array(bfactor_list)
        array.mask = array == -99.0

        return array

class Bfactor_Alignment_Array(Structural_Alignment_Property_Array) :
    
    """
    Class for calculating (or reading) the c-alpha b-factors of all chains in an alignment using the Bfactor_Array class.
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> bfactor_array = Bfactor_Alignment_Array(aligned, update=False)

    """

    data_directory = "bfactor_arrays"   # directory where calculated results are stored
    
    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, Bfactor_Array, update=update)
    
    #def calculate_distance_matrix(self, all_mask=False) :
    #    if not type(all_mask) == bool :
    #        all_mask = self._expand_array(all_mask)
    #    return self.calculate_Pearson_distance_matrix(all_mask)

    def calculate_distance_matrix(self) :
        """
        Return distance matrix based upon the Pearson distance metric.
        """
        return self.calculate_Pearson_distance_matrix()

    def normalise(self) :
        """
        Normalise data for each protein by substracting it's mean and dividing by its standard deviation. Outliers are removed prior to calculating the mean and sd, following Smith et al, Protein Science, 2003, 12:1060-1072
        """
    
        # Remove outliers
        newmask = numpy.zeros(self.size*self.length,bool)
        newmask.shape = self.size,self.length
        for i in range(self.size) :
            median = numpy.ma.median(self.data[i])
            mad = numpy.ma.median(numpy.absolute(self.data[i]-median))
            mvalues = 0.6745 * (self.data[i] - median)/mad
            outliers = mvalues.data > 3.5
            newmask[i] = self.data.mask[i] | outliers
        data2 = numpy.ma.masked_array(self.data.data,newmask)

        # Calculate means and sds
        means = numpy.ma.average(data2, axis = 1)
        sds = numpy.ma.std(data2, axis = 1)
        
        # Normalise
        self.data = numpy.ma.transpose((numpy.ma.transpose(self.data) - means) / sds)
                
    def write_jalview_feature_file(self, filename) :
        """
        Create Jalview feature file for highlighting high backbone bfactors within a sequence alignment viewer.
        """
                
        self.make_jalview_feature_file(filename, "Disorder", "Bfactor", "FF9999", "FF0000", 1.5, 2.5, standardise=False)
