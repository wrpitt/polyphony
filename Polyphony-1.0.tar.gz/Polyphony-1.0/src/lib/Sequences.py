"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from Polyphony.Utils import Calculate_Write_Read, print_timing, ids_from_id

class Sequence_Array(Structure_Property_Array, Residue_Array_Base) :
    """
    Normal property array to be constructed from a line in a sequence alignment file
    """

    def __init__(self, alignment, alignment_index, update=False) :
        self.chain = alignment.alignment[alignment_index].id
        self.config = alignment.config
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)      

class Residue_Alignment_Array(Structural_Alignment_Property_Array) :
    """
    Class for calculating (or reading) sequences and gaps for each protein chain in a given alignment. Does this by creating a Residue_Array for each chain. 
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> res_array = Residue_Alignment_Array(aligned, update=False)

    """

    data_directory = "residue_arrays"   # directory where calculated results are stored
    data_file_extension = ".npy"        # extension of data files
    
    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, Residue_Array, update)    

    def calculate_distance_matrix(self, all_mask=False) :
        """
        Sequence dissimilarity in terms of percentage sequence difference 
        """
        similarity_mat = self.get_percent_sequence_identity_matrix(all_mask)
        disimilarity_mat = 100.0 - similarity_mat
        return disimilarity_mat
            
    def get_percent_sequence_identity(self, iseq, jseq, all_mask=False) :
        """
        Calculate sequence identity percentage between ith and jth sequence. Percentage is 100.0 * sum identical residues / num positions without gaps in either sequence.  
        """
        seq_identity = self.data[iseq,:,0] == self.data[jseq,:,0]
        seq_identity.mask |= all_mask
        num_unmasked = self.length - numpy.sum(seq_identity.mask)
        if num_unmasked > 0 :
            return 100.0 * numpy.sum(seq_identity) / num_unmasked
        else:
            return 0.0
        
    #@print_timing
    def get_percent_sequence_identity_matrix(self, all_mask=False) :
        """
        return a 2d numpy array of sequence identity precentages
        """
        print "Calculating percent identity matrix for alignment of size", self.size, "x", self.length

        pc_mat = numpy.identity(self.size) # matrix with 1.0 on diagonal
        
        # Iterator to all sequence combinations
        pairs = itertools.combinations(self.data,2)
        
        # Function to calculate pairwise mean sequence identity (gaps are masked)
        percent_id = lambda x: numpy.mean(numpy.equal(x[0],x[1]))

        # Calculate all pairwise identities
        pcs = itertools.imap(percent_id, pairs)
        
        # Matrix row,col indices for upper trangle
        indices = itertools.combinations(range(self.size),2)

        # Fill in upper triangle
        for i,j in itertools.izip(indices,pcs) :
            pc_mat[i] = j

        # Copy to lower triangle
        pc_mat += numpy.triu(pc_mat,1).T
        
        # Convert to percentage
        pc_mat *= 100.0
                
        return pc_mat
   
    def cluster_by_sequence_identity(self, cut_off = 90) :
        """
        return list of lists of ids where all chains within a sublist have sequence identity percentages above the cut_off
        """
        identity_mat = self.get_percent_sequence_identity_matrix()

        clusters = []
        for i in range(0, self.length-1) :
            for j in range(i+1, self.length) :
                if identity_mat[i,j] > cut_off :
                    # pair are close enough so create new combined cluster
                    
                    # Find existing cluster membership for pair
                    c0 = c1 = set()
                    for k in range(len(clusters)) :
                        if i in clusters[k] :
                            c0.add(k)
                        if j in clusters[k] :
                            c1.add(k)
                    
                    # Update list of clusters 
                    new_cluster = set((i,j))
                    c0c1 = set.union(c0,c1)
                    for k in c0c1 :
                        new_cluster.add(clusters[k]) # add existing cluster to new cluster
                        clusters.remove(clusters[k]) # remove existing cluster
                    clusters.append(new_cluster)
                
        # convert from list of sets to list of lists
        clusters = [list(i) for i in clusters]
        
        
        ## Find linear order by descending percentage sequence identity 
        #sorted = numpy.argsort(identity_mat.flatten())
        #sorted = sorted[::-1]
        #
        ## Create list of unique pairs of sequence indices where %id > cutoff 
        #pairs = [[i/self.size,numpy.mod(i,self.size)] for i in sorted]
        #pairs_above_cutoff = [i for i in pairs if identity_mat[i[0],i[1]] > cut_off and i[0] < i[1]]
        #
        ## Cluster all sequence ids together by single linkage
        #clusters = []
        #for pair in pairs_above_cutoff :
        #    #c0 = c1 = -1
        #    c0 = c1 = set()
        #    for i in range(len(clusters)) :
        #        if pair[0] in clusters[i] and pair[1] in clusters[i] :
        #            # both already in cluster
        #            c0.add(i)
        #            c1.add(i)
        #        if pair[0] in clusters[i] :
        #            # first structure is already in a cluster
        #            c0.add(i)
        #        elif pair[1] in clusters[i] :
        #            # second structure is already in a cluster
        #            c1.add(i)
        #    if c0 == c1 == set() :
        #        # Neither of pair is already in a cluster so create new cluster to contain them
        #        clusters.append(set(pair))
        #    else :
        #        # Remove original clusters that either of pair belonged to and create one combined new one
        #        new_cluster = set(pair)
        #        c0c1 = set.union(c0,c1)
        #        for i in c0c1 :
        #            new_cluster.add(clusters[i])
        #            clusters.remove(clusters[i])
        #        clusters.append(new_cluster)
        #        
        ## convert from list of sets to list of lists
        #clusters = [list(i) for i in clusters]
        #
        ## remove duplicate clusters (not sure how this can happen !)
        ##clusters = dict((x[0], x) for x in clusters).values()
            
        return clusters
    
    def calculate_variability(self, sliding_window=1) :
        """
        Variability is the number of different residue types divided by number of non-gapped positions as a percentage, optionally averaged over sliding window. Variability
        is this number standardised. 
        """
        # Count number of residue types per alignment position
        counts = numpy.zeros(self.length)
        for i in range(self.length) :
            counts[i] = numpy.sum(numpy.bincount(self.data[:,i,0].compressed())>0)
        
        # variability is number of different residues divided by number of non-gapped position as a percentage
        num_non_gaps = self.size - numpy.sum(self.data.mask[:,:,0], axis = 0)
        var = (100.0 * counts)/ num_non_gaps

        # Calculate sliding window average
        if sliding_window > 1 :
            self.variability = numpy.zeros(self.length)
            window_index = self.get_sliding_window_index(sliding_window)
            self.variability[sliding_window/2:self.length-sliding_window/2] = numpy.average(var[window_index],axis=1)
        else :
            self.variability = var

        ## Normalise
        #min = numpy.min(self.variability)
        #rang = numpy.max(self.variability) - min
        #self.variability = 100.0 * (self.variability-min)/rang
        
        # Normalise
        avg = numpy.ma.median(self.variability)
        sd = numpy.ma.std(self.variability)
        variability = numpy.ma.array((self.variability-avg)/sd)
        variability.mask = num_non_gaps < self.size/2 # mask columns with >50% gaps 

        return variability
    
    def variable_positions(self, cutoff=2.0) :
        """
        Returns array of bools, of length self.length. True values indicate variable alignment positions.
        Variability is defined as having a percentage num different residues per total residues (self.size for ungapped alignment positions)
        """
        var = self.calculate_variability()
        return var > cutoff

