"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Initial import CONFIG
from Polyphony.Utils import ids_from_id, to_one_letter_code
import os, stat, re, numpy

# Check NCONT is installed
ncont_exe = CONFIG.get('executables','ncont')
if os.access(ncont_exe,os.F_OK) == False :
    raise ImportError("NCONT excutable not found.")
        
from Polyphony.Property_Arrays import Structure_Property_Array, Structural_Alignment_Property_Array
from Polyphony.Jalview import JalviewFeatureFileCreator

class Contact_Array(Structure_Property_Array) :
    
    """
    Class to run and extract the output from the CCP4 NCONT program. The number of intramolecule contacts within 5A for a protein chain in a crystal lattice are recorded per residue. Water molecules and non-protein atoms are ignored. Requires that you have NCONT installed. The CCP4 suit is not open source but is free for non-profit activities. It can be obtained from http://www.ccp4.ac.uk/
    """
    
    data_type = int     # data is a count of the number of contacts
    data_dim = 1             # 1 dimensional data i.e. 1 value per residue
    dim_names = ["crystal contacts"]
    data_directory = "contacts"   # directory where calculated results are stored
    padding = 0             # number of residues to mask out either side of gaps and at termini

    def __init__(self, alignment, alignment_index, update = False) :
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)
            
    def _calculate(self) :
        """
        Run NCONT interatomic contacts calculation and store results in an array
        """
        # Create script to run NCONT and create output in desired directory
        ncont_script_filename = CONFIG.get('directories','tmp')+"ncont_"+self.pdb_chain_code+".csh"
        output_filename = CONFIG.get('directories','data')+"/"+self.data_directory+"/"+self.pdb_chain_code+".ncont"
        self._create_ncont_script(output_filename, ncont_script_filename)
        # Run script
        os.system("csh "+ncont_script_filename)
        # Extract data from results file
        return self._parse_file(output_filename)

    def _create_ncont_script(self, out_filename,script_filename) :
        """
        Create a shell script to run NCONT on a single pdb file
        """
        pdb_code, model_no, chain_letter = ids_from_id(self.pdb_chain_code)

        script_file = open(script_filename,"w")
        script_file.write("#!/bin/csh -f\n")
        script_file.write("source "+CONFIG.get('executables','ncont_env')+"\n")
        script_file.write(CONFIG.get('executables','ncont')+" XYZIN "+CONFIG.get('directories','data')+"pdbs/"+pdb_code+".pdb > "+out_filename+" <<eof\n")
        script_file.write("source "+chain_letter+"\n")
        script_file.write("target *\n")
        script_file.write("cell 1\n")
        script_file.write("maxdist 5\n")
        script_file.write("eof\n")
        script_file.close()
        # make script read, write and execute by owner 
        os.chmod(script_filename,stat.S_IRWXU)
 
    def _parse_file(self, filename):
        """
        parse NCONT output. Adapted from function in ContactsNCONT.py which was written by Gerhard Reitmayr and Dalia Daujotyte in 2009
        """
        
        # Get list of residue numbers in protein chain
        residues = self.alignment.get_residues(self.pdb_chain_code)
        residue_numbers = [res.id[1] for res in residues]

        
        file = open(filename,"r")
        data = numpy.ma.zeros(self.length)
        data.mask = False
        
        # /1/B/ 282(PHE). / CE1[ C]:  /1/E/ 706(GLN). / O  [ O]:   3.32
        conParser = re.compile("\s*/(\d+)/([A-Z]*)/\s*([-0-9]+)\(([A-Z0-9][A-Z0-9][A-Z0-9])\).*?/\s*([A-Z0-9]*).*?:")
        cellParser = re.compile("\s([-+XYZ123/]*,[-+XYZ123/]*,[-+XYZ123/]*)$")
        waterParser = re.compile("HOH")
        mode = 0
        for line in file:
            if mode == 0:
                # Start of output data
                if line.strip().startswith("SOURCE ATOMS"):
                    mode = 1
            elif mode == 1:
                # Skip blank line
                mode = 2
            elif mode == 2:
                # Read data
                matches = conParser.findall(line)
                symmetry = cellParser.findall(line)
                waters = waterParser.findall(line)

                # Check for contact involving water
                if len(waters) > 0 :
                    water = True
                else :
                    water = False  
                if len(matches) == 2:
                    # First line of contacts for given atom in source chain
                    
                    # Check residue is to be included
                    res_num = int(matches[0][2])

                    # the original pdb file is used for ncont calculations so hetatms are included. 
                    if water :
                        ignore = True                                   # the sequence in the alignment file are ignored.
                    else:
                        ignore = False
                        
                    # unrecognised residue? (way to ignore ligands and other hetatms)
                    res_name0 = matches[0][3]
                    if res_name0 in to_one_letter_code.keys() :
                        known_res = True
                    else :
                        known_res = False
                    if not known_res : 
                        ignore = True
                        
                    # ignore hydrogens
                    element = matches[0][4][0]
                    if element == 'H' :
                        hydrogen = True
                    else :
                        hydrogen = False
                    if hydrogen : 
                        ignore = True                    

                    # Check for intramolecular contact (same chain and not symmetry copy)
                    source_chain = matches[0][1]
                    target_chain = matches[1][1]
                    if  source_chain == target_chain and (len(symmetry) == 0 or symmetry[0] == "X,Y,Z") :
                        intramolecular = True
                    else :
                        intramolecular = False

                    # unrecognised residue? (way to ignore ligands and other hetatms)
                    res_name1 = matches[1][3]
                    if res_name1 in to_one_letter_code.keys() :
                        known_res = True
                    else :
                        known_res = False

                    # ignore hydrogens
                    element = matches[1][4][0]
                    if element == 'H' :
                        hydrogen = True
                    else :
                        hydrogen = False
                        
                    if not intramolecular and not ignore and known_res and not hydrogen:
                        try :
                            res_idx = residue_numbers.index(res_num)
                        except ValueError :
                            # Residue not in Polyphony - ignore
                            continue
                        data[res_idx] += 1
                elif len(matches) == 1:
                    # Subsequent contacts for given source atom
                                        
                    # Check for intramolecular contact (same chain and not symmetry copy)
                    target_chain = matches[0][1]
                    try:
                        if  source_chain == target_chain and (len(symmetry) == 0 or symmetry[0] == "X,Y,Z") :
                            intramolecular = True
                        else :
                            intramolecular = False
                    except UnboundLocalError :
                        print "Problem reading NCONT output" # source_chain not defined
                        continue
                        
                    # unrecognised residue? (way to ignore ligands and other hetatms)
                    res_name = matches[0][3]
                    if res_name in to_one_letter_code.keys() :
                        known_res = True
                    else :
                        known_res = False
                        
                    # ignore hydrogens
                    element = matches[0][4][0]
                    if element == 'H' :
                        hydrogen = True
                    else :
                        hydrogen = False

                    if not intramolecular and not water and not ignore and known_res and not hydrogen:
                        try :
                            res_idx = residue_numbers.index(res_num)
                        except ValueError :
                            # Residue not in Polyphony - ignore
                            continue
                        data[res_idx] += 1
                elif len(matches) == 0:
                    # End of output
                    file.close()
                    return data
        pdb_code = self.pdb_chain_code.split('_')[0]
        print "Problem reading NCONT output file for "+pdb_code
        return data
    
class Contact_Alignment_Array(Structural_Alignment_Property_Array) :
    
    """
    Class for calculating (or reading) the number of intermolecular contacts for all residues in an alignment. Does this by creating a Contact_Array object for each chain in an alignment.
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> contact_array = Contact_Alignment_Array(aligned, update=False)

    """

    data_directory = "contact_arrays"   # directory where calculated results are stored

    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, Contact_Array, update)
        
    def write_jalview_feature_file(self, filename) :
        """
        Create Jalview feature file for highlighting when and how many contacts are made with a sequence alignment viewer.
        """
        self.make_jalview_feature_file(filename, "Contact", "NCONT", "FFCCFF", "FF0000", 20, 80)
            
    #def calculate_distance_matrix(self, all_mask=False) :
    #    if not type(all_mask) == bool :
    #        all_mask = self._expand_array(all_mask)
    #    #return self.calculate_manhatten_distance_matrix(all_mask)
    #    return self.calculate_tanimoto_distance_matrix(all_mask)

    def calculate_distance_matrix(self) :
        """
        Return a protein chain distance matrix using the Tanimoto metric.
        """
        return self.calculate_tanimoto_distance_matrix()