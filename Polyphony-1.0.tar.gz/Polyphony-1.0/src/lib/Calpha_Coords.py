"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Property_Arrays import Structure_Property_Array, Structural_Alignment_Property_Array
from Polyphony.Utils import get_sliding_window_index
from Bio.SVDSuperimposer import SVDSuperimposer
import numpy

class Calpha_Coords(Structure_Property_Array) :

    """
    Store the x,y,z coordinates of Calpha atoms
    """
    
    data_type = float        # data curvature and torsions (kappas and taus)
    data_dim = 3             # 2 dimensional data i.e. kappa,tau per residue
    dim_names = ["x","y","z"]
    data_directory = "calpha_xyz"   # directory where calculated results are stored
    padding = 0             # number of residues to mask out either side of gaps and at termini
    
    def __init__(self, alignment, alignment_index, update = False) :
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)
        
    def _calculate(self) :
        """
        Create Biopython.PDB object for chain and use its functions to extract the coordinates of the Calpha atoms. Mask missing values.
        """
        # Get Biopython.PDB residues for chain        
        residues = self.alignment.get_residues(self.pdb_chain_code)            
        coord_array = numpy.ma.zeros(len(residues)*3)
        coord_array.shape = len(residues),3
        coord_array.mask = False

        # Get all the c-alpha coordinates
        for i in range(len(residues)):
            res = residues[i]
            try:
                coord_array[i] = res["CA"].get_coord()
            except KeyError:
                print "CA missing",res,self.pdb_chain_code      
                coord_array.mask[i] = True
        return coord_array
        
class Calpha_Coords_Array(Structural_Alignment_Property_Array) :
    
    """
    Class for reading Calpha coordinates, either from a pregenerated numpy array or directly from PDB files.
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> coord_array = Calpha_Coords_Array(aligned, update=False)

    """

    data_directory = "calpha_xyz_arrays"   # directory where calculated results are stored

    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, Calpha_Coords, update)
        
    def fit_to_reference(self, reference_id=None, sliding_window=None) :
        """
        Return coordinate array after fitting to a reference structure. By default this is the representative structure. If a sliding_window is specified, then a local fit is performed for each residue, otherwise all residues are fitted at once.
        """
        if reference_id == None :
            reference_id = self.alignment.get_representative_structure()
        
        ref_idx = self.alignment.index_from_id(reference_id)
        ref_coords = self.data[ref_idx]
        supsvd = SVDSuperimposer()

        new_coords = self.data.copy()
        if sliding_window == None :
            for i in range(self.size) :
                if i == ref_idx :
                    continue
                # Superimpose onto reference coordinates
                moving_coords = self.data[i]
                
                # Select only those residues unmasked in both structures
                common_unmask = numpy.logical_not(moving_coords.mask | ref_coords.mask)
                common_ref = ref_coords.data[common_unmask]
                common_moving = moving_coords.data[common_unmask]
                common_ref.shape = len(common_ref)/3, 3
                common_moving.shape = len(common_moving)/3, 3
                
                # Get transformation
                supsvd.set(common_ref,common_moving)
                supsvd.run()
                rot,tran=supsvd.get_rotran()
                
                # Apply transformation
                new_coords[i] = numpy.dot(moving_coords, rot) + tran
        else :
            window_index = get_sliding_window_index(sliding_window, self.length)
            for i in range(self.size) :
                if i == ref_idx :
                    continue
                resi = sliding_window/2 
                for j in window_index :
                    # Superimpose onto reference coordinates
                    ref_window_coords = ref_coords[j]
                    moving_window_coords = self.data[i,j]
                    
                    # Select only those residues unmasked in both structures
                    common_unmask = numpy.logical_not(ref_window_coords.mask | moving_window_coords.mask)
                    common_ref = ref_window_coords.data[common_unmask]
                    common_moving = moving_window_coords.data[common_unmask]
                    
                    # Perform fit only if the whole window is unmasked in both structures. Otherwise mask moving coords
                    if len(common_ref) < sliding_window * 3 :
                        new_coords.mask[i, resi] = True
                        resi += 1
                        continue
                    
                    # Perform least squares superposition
                    common_ref.shape = len(common_ref)/3, 3
                    common_moving.shape = len(common_moving)/3, 3
                    supsvd.set(common_ref,common_moving)
                    supsvd.run()
                    rot,tran=supsvd.get_rotran()
                    
                    # Transform single calpha coordinates using resulting transformation
                    new_coords[i, resi] = numpy.dot(new_coords[i, resi], rot) + tran
                    resi += 1
            
            # Mask ends because they don't have a full window of residues for fitting
            new_coords.mask[:,:sliding_window/2] = True
            new_coords.mask[:,-sliding_window/2:] = True

        return new_coords
        
    def rmsf(self, reference_id=None, sliding_window=5) :
        """
        Calculate root mean squared fluctuation after fitting to reference structure, optionally using a local fit over a given sliding window (default 5 residues).
        """

        print "Calculating C-alpha RMSF"
        if reference_id == None :
            reference_id = self.alignment.get_representative_structure()

        fitted_coords = self.fit_to_reference(reference_id=reference_id, sliding_window=sliding_window)
        ref_idx = self.alignment.index_from_id(reference_id)
        diff = fitted_coords - fitted_coords[ref_idx]
        rmsfs = numpy.ma.average(numpy.ma.sqrt(numpy.ma.sum(diff*diff,axis=2)),axis=0)
        
        return rmsfs

    def rmsd(self, reference_id=None, sliding_window=None) :
        """
        Calculate root mean squared deviation after fitting to reference structure, optionally using a local fit over a given sliding window.
        """
        print "Calculating C-alpha RMSD"
        if reference_id == None :
            reference_id = self.alignment.get_representative_structure()

        fitted_coords = self.fit_to_reference(reference_id=reference_id, sliding_window=sliding_window)
        ref_idx = self.alignment.index_from_id(reference_id)
        diff = fitted_coords - fitted_coords[ref_idx]
        rmsds = numpy.ma.average(numpy.ma.sqrt(numpy.ma.sum(diff*diff,axis=2)),axis=1)
        return rmsds
    
    def calculate_distance_matrix(self) :
        """
        Calculate distance matrix using Euclidiean distance metric after fitting the the representative structure.        
        """
        data_copy = self.data.copy() # preserve orginal coords
        self.data = self.fit_to_reference() # fit all to representative structure
        mat = self.calculate_Euclidean_distance_matrix() # Calculate distance after fitting
        self.data = data_copy # restore orginal coordinates
        return mat
        


 