"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Property_Arrays import Structure_Property_Array, Structural_Alignment_Property_Array
from Polyphony.Jalview import JalviewFeatureFileCreator
from Polyphony.Initial import CONFIG
from Polyphony.Utils import ids_from_id, reduce

from sqlalchemy import create_engine
import numpy

class Piccolo_Array(Structure_Property_Array) :
    
    """
    Class to calculate and store the residue-based interaction fingerprint for a protein chain. Only protein-protein interactions that are stored in the Piccolo database are recorded. See http://www-cryst.bioc.cam.ac.uk/~richard/piccolo/piccolo.php for more details. The fingerprint is made-up of a count of the following interaction types : [covalent, vdw, vdw clash, hbonds, water mediated hbonds, hydrophobic, ionic, disulfide, aromatic-sulfur].
    """
    
    data_type = int                 # data is number of contacts
    data_dim = 9                    # 9 dimensional data i.e. 9 contact types per residue
    dim_names = ["covalent", "vdw", "vdw clash", "hbonds", "water mediated hbonds", "hydrophobic", "ionic", "disulfide", "aromatic-sulfur"]
    data_labels = "CvVHWBIDS"       # Covalent, VDW, VDW clash, Hbonds, Water mediated Hbonds, Hydrophobic, Ionic, Disulfide, Aromatic-sulfur
    data_directory = "piccolo"      # directory where calculated results are stored
    padding = 0                     # number of residues to mask out either side of gaps and at termini

    def __init__(self, alignment, alignment_index, update = False) :
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)

    def _calculate(self) :
        """
        Query the Piccolo database and return sum of each type of contact per residue
        """
        USER    = CONFIG.get('database','user')
        PASSWD  = CONFIG.get('database','passwd')
        HOST    = CONFIG.get('database','host')
        URL = 'mysql://%s:%s@%s:3306/%s' % (USER,PASSWD,HOST,"PICCOLO")
        ENGINE = create_engine(URL, echo=False).connect()


        query = "select resid,sum_cov,sum_vdw,sum_vdwclash,sum_hb,sum_wmhb,sum_hydrophobe,sum_ionic,sum_disulph,sum_aromsulph from PICCOLO.quat_residues r join PICCOLO.quat_gen as g on (r.pdb = g.pdb and r.chain = g.quat_chain_id and r.biomol_id = g.biomol_id) where g.pdb = '%s' and g.pdb_chain_id = '%s' and r.sum_contact > 0 group by resid order by resid"
        pdb_code, model_no, chain_letter = ids_from_id(self.pdb_chain_code)

        # Get list of residue numbers in protein chain
        residues = self.alignment.get_residues(self.pdb_chain_code)
        residue_numbers = [res.id[1] for res in residues]

        # Get contacts as a list on sum of contact types
        result_arr = ENGINE.execute(query % (pdb_code, chain_letter)).fetchall()

        # Put results in an array
        piccolo_array = numpy.ma.zeros(self.length*self.data_dim,self.data_type)
        piccolo_array.shape = self.length,self.data_dim
        piccolo_array.mask = piccolo_array != 0
        
        for res in result_arr :
            res_num = res[0]
            try :
                res_idx = residue_numbers.index(res_num)
            except ValueError :
                # Residue in Piccolo but not in Polyphony - ignore
                continue
            piccolo_array[res_idx] = [self.data_type(res[i]) for i in range(1,len(res))]

        return piccolo_array

class Piccolo_Alignment_Array(Structural_Alignment_Property_Array) :
    
    """
    Class for calculating (or reading) the residue-based interaction fingerprint for each protein chain in a given alignment. Does this by creating a Piccolo_Array for each chain.
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> piccolo_array = Piccolo_Alignment_Array(aligned, update=False)

    """


    data_directory = "piccolo_arrays"       # directory where calculated results are stored
    
    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, Piccolo_Array, update)

    def reduce(self) :
        """
        Reduce multidimensional data to a single number per residue. The default method is to take to the geometric mean. This can be changed by creating a subclass method.
        """
        return reduce(self.data, method="sum")
        
    def write_jalview_feature_file(self,filename) :
        """
        Write a Jalview feature file which can be used to highlight protein-protein interactions in the Jalview sequence alignment viewer.
        """
        self.make_jalview_feature_file(filename, "Contact", "PICCOLO", "00FFFF", "008888", 10, 50)


    def calculate_distance_matrix(self, all_mask=False) :
        """
        Return an all-against-all protein structure distance matrix. Distances are based-upon the tanimoto metric on interaction fingerprints
        """
        if not type(all_mask) == bool :
            all_mask = self._expand_array(all_mask)
        return self.calculate_tanimoto_distance_matrix(all_mask)
        #return self.calculate_manhatten_distance_matrix(all_mask)

class Piccolo_Contact_Array(Structure_Property_Array) :
    
    """
    Class to generate and store the number of residue-residue contacts within 5 Angstroms in the Piccolo database for a protein chain. 
    """
    
    data_type = int                 # data is number of contacts
    data_dim = 1                    # number of residues within a certain distance
    dim_names = ["contacts"]
    data_directory = "piccolo_contacts"      # directory where calculated results are stored
    padding = 0                     # number of residues to mask out either side of gaps and at termini

    #def __init__(self, alignment, pdb_chain_code,length, alignment_index, update = False) :
    #    Structure_Property_Array.__init__(self, alignment, pdb_chain_code,length, alignment_index, update)
    def __init__(self, alignment, alignment_index, update = False) :
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)
        
    def _calculate(self) :
        """
        Query the Piccolo database and return sum of each type of contact per residue
        """

        # Get list of residue numbers in protein chain
        residues = self.alignment.get_residues(self.pdb_chain_code)
        residue_numbers = [res.id[1] for res in residues]

        query = "SELECT p1_resid, COUNT(a.contact_id) AS num_contacts FROM PICCOLO.quat_atom_pairs a JOIN PICCOLO.quat_gen AS g ON (a.pdb = g.pdb AND a.p1_chain = g.quat_chain_id AND a.biomol_id = g.biomol_id) WHERE g.pdb = '%s' AND g.pdb_chain_id = '%s' AND a.distance < '%s' GROUP BY a.p1_resid ORDER BY a.p1_resid"
        pdb_code, model_no, chain_letter = ids_from_id(self.pdb_chain_code)
        
        # Get contacts as a list on sum of contact types
        cutoff = "5.0" # Distance cutoff. Chosen to be the same as used by the NCONT contact calculation.
        result_arr = ENGINE.execute(query % (pdb_code, chain_letter, cutoff)).fetchall()

        ## Put results in a dictionary
        #picc_dict = {}
        #for res in result_arr :
        #    res_num = res[0]
        #    if res_num > 0 :
        #        picc_dict[res_num] = int(res[1])
                
        # Insert into alignment-based array
        piccolo_contact_array = numpy.ma.zeros(self.length,self.data_type)
        piccolo_contact_array.mask = False
        
        for res in result_arr :
            res_num = res[0]
            try :
                res_idx = residue_numbers.index(res_num)
            except ValueError :
                # Residue in Piccolo but not in Polyphony - ignore
                continue
            piccolo_contact_array[res_idx] = self.data_type(res[1]) 

        #pdb_resi = 0
        #for ali_resi in range(self.length):
        #    if not self.seq[ali_resi] == "-" :
        #        if picc_dict.has_key(pdb_resi) :
        #            piccolo_contact_array[ali_resi] = picc_dict[pdb_resi]
        #        pdb_resi += 1
        return piccolo_contact_array
    

class Piccolo_Contact_Alignment_Array(Structural_Alignment_Property_Array) :
    
    """
    Class for calculating (or reading) the residue-residue interprotein contact counts for each protein chain in a given alignment. Does this by creating a Piccolo_Contact_Array for each chain.
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    """

    data_directory = "piccolo_contact_arrays"       # directory where calculated results are stored
    
    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, Piccolo_Contact_Array, update)

    def write_jalview_feature_file(self,filename) :
        """
        Write a Jalview feature file which can be used to highlight protein-protein interactions in the Jalview sequence alignment viewer.
        """
        self.make_jalview_feature_file(filename, "Contact", "PICCOLO_CONTACT", "00CCFF", "0000FF", 10, 50)
        #
        #jalfile = JalviewFeatureFileCreator()
        #jalfile.add_colour("PICCOLO_CONTACT","00CCFF","0000FF",10,50)
        #ids = self.get_ids()
        #res2pos, ires2pos, pos2res, pos2ires = self.alignment._create_residue_indices()
        #
        #for i in range(self.size) :
        #    id = ids[i]
        #    for j in range(self.length) :
        #        num_contacts = self.data[i,j]
        #        try :
        #            num_contacts = int(num_contacts)
        #        except :
        #            continue
        #        if num_contacts != 0 :
        #            jalfile.add_feature("Contact", id, pos2ires[i,j]+1, pos2ires[i,j]+1, "PICCOLO_CONTACT", num_contacts)
        #jalfile.write_file(filename)

    def calculate_distance_matrix(self, all_mask=False) :
        """
        Return an all-against-all protein structure distance matrix. Distances are based-upon the tanimoto metric on residue contacts
        """
        if not type(all_mask) == bool :
            all_mask = self._expand_array(all_mask)
        return self.calculate_tanimoto_distance_matrix(all_mask)
        #return self.calculate_manhatten_distance_matrix(all_mask)


