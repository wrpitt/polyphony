"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

#from Polyphony.Initial import CONFIG
from Polyphony.Utils import print_timing, Calculate_Write_Read, reduce, get_sliding_window_index
from Polyphony.Jalview import JalviewFeatureFileCreator
from Polyphony.Comparison_Matrices import Structure_Matrix, Residue_Matrix
from Polyphony.Trees import Tree
from Polyphony.Plotting import plot_alignment_properties
#import numpy, scipy.stats.stats as stats
from scipy.spatial.distance import cdist
import os, numpy, itertools
from scipy import stats

class Structure_Property_Array(Calculate_Write_Read) :
    """
    Class to contain residue-based properties (1D array) for a given pdb chain from within a structural alignment. Objects of this class should not created explicitly but only objects of its subclasses. An example of a subclass is Kappa_Tau_Array which describes the backbone conformation of a protein chain.
    """
    def __init__(self, alignment, alignment_index, update = False) :
        self.alignment = alignment 
        self.alignment_index = alignment_index # the number of the sequence in self.alignment
        self.pdb_chain_code = self.alignment.ids()[self.alignment_index]
        #self.seq = alignment.alignment.get_seq_by_num(alignment_index).data
        self.seq = alignment.alignment[alignment_index].seq
        self.length = len(self.seq) - self.seq.count("-")
        self.data = Calculate_Write_Read.__init__(self, self.pdb_chain_code, update) # the property data array, a 1d numpy masked array.
        # check that sequence and data are the same length
        if self.data.shape[0] != self.length :
            print "Precomputed data and sequence don't match. Recalculating."
            self.data = Calculate_Write_Read.__init__(self, self.pdb_chain_code, update=True) # the property data array, a 1d numpy masked array.
            assert self.data.shape[0] == self.length
        self._extend_mask()

    def __repr__(self) :
        return str(self.data)
        
    def _extend_mask(self) :
        """
        Function to extend mask either side of already masked positions
        """        
        if self.padding == 0 :
            # nothing to do
            return
    
        masked = self.data.mask.copy()
        
        # mask out "self.padding" residues either side of each gap
        for ires in range(self.padding,self.length-self.padding) :
            if masked[ires].any() :
                self.data.mask[ires-self.padding:ires+self.padding+1] = True
                
        # mask out first (n-terminal) "self.padding" residues
        for ires in range(self.length) :
            if not(masked[ires].all()) :
                self.data.mask[ires:ires+self.padding] = True
                break
            else :
                self.data.mask[ires] = True
                
        # mask out last (c-terminal) "self.padding" residues
        for ires in range(self.length-1,-1,-1) :
            if not(masked[ires].all()) :
                self.data.mask[ires-self.padding+1:ires+1] = True
                break
            else :
                self.data.mask[ires] = True
              
class Structural_Alignment_Property_Array(Calculate_Write_Read) :
    """
    Class to contain matrix (2D array) of residue-based properties for a whole structural alignment. Again this should not be accessed directly but only via a subclass, for example Kappa_Tau_Alignment_Array. This class provides functions and parameters common to all property arrays.
    """
    
    def __init__(self, structural_alignment, Structure_Property_Array_Class, update = False) :
        self.id =  structural_alignment.id
        self.update = update
        self.length = structural_alignment.length()
        self.size = structural_alignment.size()
        self.alignment = structural_alignment
        self.data_dim = Structure_Property_Array_Class.data_dim
        self.dim_names = Structure_Property_Array_Class.dim_names
        self.data_type = Structure_Property_Array_Class.data_type        
        self.One_d_data_class = Structure_Property_Array_Class
        self.data = Calculate_Write_Read.__init__(self, self.id, update)
        
        # check that alignment and data have the same dimensions
        if self.data.shape[0] != self.size or self.data.shape[1] != self.length :
            print "Precomputed data and alignment don't match. Recalculating."
            self.data = Calculate_Write_Read.__init__(self, self.id, update=True)
            assert self.data.shape[0] == self.size and self.data.shape[1] == self.length

        self._mask_gaps()
        self.normalise()

    def __repr__(self) :
        max_width = 30
        max_height = 1000
        tail_width = 3
        width = min(self.length, max_width)
        height = min(self.size, max_height)
        output = ""
        for i in range(height) :
            output += self.alignment.ids()[i] + " ["
            for j in range(width) :
                output += '%4s' % str(self.data[i,j]) + ", "
            if self.length > width :
                output += " ... "
                for j in range(self.length-tail_width,self.length) :
                    output += '%4s' % str(self.data[i,j]) + ", "
            output = output[:-2]+"]\n"
        return output

    def __sub__(self, other) :
        if not isinstance(other, Structural_Alignment_Property_Array) :
            raise NotImplemented
        if not self.data.shape == other.data.shape :
            raise NotImplemented
        new = Derived_Alignment_Property_Array(self)
        new.data = self.data - other.data
        return new
    
    def __len__(self) :
        """
        return number of structures/sequences in the alignment
        """
        return self.size

    def _mask_gaps(self) :
        """
        Mask any gaps in the alignment.
        """
        # Mask alignment gaps
        gaps = self.alignment.find_gaps()
        if self.data_dim == 1 :
            self.data.mask += gaps
        else :
            # mask each per residue parameter
            for i in range(self.data_dim) :
                self.data.mask[:,:,i] += gaps

    def _calculate(self) :
        """
        Take single sequence/structure chain property arrays and put them into a single multiple sequence
        alignment array
        """
        # Create masked array to hold data
        data = numpy.ma.zeros(self.size*self.length*self.data_dim,self.data_type)
        if self.data_dim > 1 :
            data.shape = self.size,self.length,self.data_dim
        else :
            data.shape = self.size,self.length
        data.mask = True # mask all positions by default

        res2pos, ires2pos, pos2res, pos2ires = self.alignment._create_residue_indices(self.update) 
        struct_idx = 0
        for id in self.alignment.ids() :
            # indices for position of each residue in alignment, after taking gaps into account
            i2p = ires2pos[struct_idx].compressed()
            # data for whole protein chain
            struct_array = self.One_d_data_class(self.alignment, struct_idx, update=self.update)
            # insert into alignment data array
            data.data[struct_idx,i2p] = struct_array.data.data
            data.mask[struct_idx,i2p] = struct_array.data.mask
            struct_idx += 1
        print
        return data
               
    def _expand_array(self, array) :
        """
        take arry of length self.length and expand to length self.length * self.data_dim by duplication
        """
        shape = list(array.shape)
        a = array.flatten()
        b = array.flatten()
        for i in range(self.data_dim-1) :
            b = numpy.column_stack((b,a))
        shape.append(self.data_dim)
        b.shape = shape
        return b
    
    #def _expand_array(self, array) :
    #    """
    #    take arry of length self.length and expand to length self.length * self.data_dim by duplication
    #    """
    #    a = array.copy()
    #    b = array.copy()
    #    for i in range(self.data_dim-1) :
    #        b = numpy.column_stack((b,a))
    #    b = b.flatten()
    #    return b

    def _mask_gappy_columns(self, masked_array, missing_value_cut_off) :
        """
        Mask complete alignment positions if the number of masked rows exceeds the specified percentage.
        """
        if missing_value_cut_off < 0 or missing_value_cut_off > 100 :
            raise RuntimeError("missing_value_cut_off must be between 1 and 100.")

        num_masked = numpy.sum(masked_array.mask, axis=0)
        pc_masked = 100.0 * num_masked/len(masked_array)
        too_gappy = pc_masked > missing_value_cut_off
        masked_array.mask += too_gappy
        #print "Columns masked (ignored)", numpy.where(too_gappy)[0]

    def subset(self, group) :
        """
        Return property array for a subset of structures/sequences from the alignment. group  must be a list of integers, each < self.size and >= 0
        """
        group = numpy.array(list(set(group)),int) # ensure no duplicates and numeric type
        group = group[group>=0] # ensure all greater => 0
        group = group[group<self.size] # ensure all less than self.size
        new_alignment = self.alignment.subset(group)
        new_alignment.id = "temp"
        new = self.__class__(new_alignment, self.update)
        new.data = self.data[group]
        new.size = len(group)
        new.alignment = new_alignment
        print "\nSubset of size ", new.size, " created"
        print "\nContains : ", new.alignment.ids()
        return new
    
    def slice(self, alignment_positions, dimensions=[]) :
        """
        Return a property array for a given numpy selection of alignment positions and for multidimensional properties for the selected dimensions.
        
        Input parameters
        ----------------
        
        alignment_positions: list of type int
            a list of alignment positions to be selected.
            
        dimensions: list of type int
            a list of parameter dimensions. Default is an empty list which will lead to all dimensions being selected
        
        """
        new_alignment = self.alignment.slice(alignment_positions)
        new_alignment.id = "temp"
        new = Derived_Alignment_Property_Array(self)
        if self.data_dim > 1 :
            new.data = self.data[:,alignment_positions,:]
        else :
            new.data = self.data[:,alignment_positions]
        #new.data = self.data[:,alignment_positions,:]
        if self.data_dim > 1 and len(dimensions) > 0 :
            new.data = new.data[:,:,dimensions]
        new.length = new.data.shape[1]
        if len(new.data.shape) > 2 :
            new.data_dim = new.data.shape[2]
        else :
            new.data_dim = 1
        new.alignment = new_alignment
        return new
        
    def group_by_pdb(self) :
        """
        Return list of lists containing different chains from the same pdb
        """
        return self.alignment.group_by_pdb()
        
    def plot(self, show = True, labels_consensus=True, centre=False, colour_groups=None, spectrum=False) :
        """
        Plot line plot of properties as a function of sequence. One line per structure. If show=True an interactive pylab view is shown. If labels_consensus=True then x-axis
        is labelled with the concensus sequence, otherwise the sequence of the representative structure is used.
        """
        # Find consensus sequence
        xlabels = ""
        #for i in range(self.length) :
        #    if (i-1)%10 == 0 :
        #        xlabels += str(i/10)
        #    else :
        #        xlabels += " "
            
        if labels_consensus :
            xlabels = self.alignment.get_consensus_sequence()
        #else :
        #    id = self.alignment.get_representative_structure()
        #    print "\nRepresentative structures is",id 
        #    xlabels = self.alignment.get_sequence_from_id(id)
        if centre == True:
            plot_alignment_properties(self.centred(), self.__class__.__name__, xlabels, self.dim_names, legend=self.alignment.ids(), colour_groups=colour_groups, spectrum=spectrum)
        elif type(centre) == list :
            plot_alignment_properties(self.centred(groups = centre), self.__class__.__name__, xlabels, self.dim_names, legend=self.alignment.ids(), colour_groups=colour_groups, spectrum=spectrum)
        else:
            plot_alignment_properties(self.data, self.__class__.__name__, xlabels, self.dim_names, legend=self.alignment.ids(), colour_groups=colour_groups, spectrum=spectrum)

    def normalise(self) :
        """
        Default normalisation - do nothing
        """
        pass
        
    def get_ids(self) :
        """
        Return a list of the chain ids in the alignment
        """
        return self.alignment.ids()
          
    @print_timing
    def calculate_weighted_Pearson_distance_matrix(self, weights, all_mask=False) :
        """
        Calculate Pearson distance matrix for 2D array of data with missing values. Distance between each pair of structures is calculated using mutually non-missing values. Distances are normalised by dividing by the number of these values (n). For properties with multiple dimensions, the dimensions are flattened and each dimension is assumed to be pre-normalised to be on the same scale.
        """
        if self.data_dim > 1 :
            print "\nCalculating weighted Pearson distance matrix of size ", self.size, " x ", self.length, " x ", self.data_dim
        else :
            print "\nCalculating weighted Pearson distance matrix of size ", self.size, " x ", self.length

        distmat = numpy.zeros(self.size*self.size)
        distmat.shape = self.size, self.size
        weights = weights.flatten()
        for iseq in range(0, self.size-1 ) :
            i_mask = self.data.mask[iseq].flatten()
            for jseq in range(iseq+1,self.size) :
                j_mask = self.data.mask[jseq].flatten()
                ij_mask = i_mask | j_mask | all_mask
                i_arr = numpy.ma.masked_array(numpy.absolute(self.data.data[iseq].flatten()),ij_mask)
                j_arr = numpy.ma.masked_array(numpy.absolute(self.data.data[jseq].flatten()),ij_mask)
                if len(weights) == 0 :
                    # Calculated unweighted Pearson correlation
                    xm = i_arr - numpy.ma.average(i_arr)
                    ym = j_arr - numpy.ma.average(j_arr)
                    r_num = numpy.ma.add.reduce(xm*ym)
                    r_den = numpy.sqrt(numpy.ma.add.reduce(xm*xm)*numpy.ma.add.reduce(ym*ym))
                else :
                    # Calculated weighted Pearson correlation
                    ij_weights = weights.copy()
                    numpy.putmask(ij_weights, ij_mask, 0.0) # Set weight to zero where values are missing
                    sum_weights = numpy.sum(ij_weights)
                    if sum_weights == 0 :
                        r_num = 0.0
                        r_den = 1.0
                    else :
                        xm = i_arr - numpy.ma.average(i_arr, weights=ij_weights)
                        ym = j_arr - numpy.ma.average(j_arr, weights=ij_weights)
                        cov_xy = numpy.ma.add.reduce(ij_weights*xm*ym)/sum_weights 
                        cov_xx = numpy.ma.add.reduce(ij_weights*xm*xm)/sum_weights 
                        cov_yy = numpy.ma.add.reduce(ij_weights*ym*ym)/sum_weights 
                        r_num = cov_xy
                        r_den = cov_xx*cov_yy
                r = r_num / r_den
                n = numpy.invert(ij_mask).sum()/self.data_dim # number of non-masked residues
                dist = 100.0 * (1 - r)/(2.0 * max(n,1)) # (1 -r)/2 converts from a correlation coeffient to a distance between 0 and 1.
                distmat[iseq,jseq] = dist
                distmat[jseq,iseq] = dist
        return distmat

    @print_timing
    def calculate_Pearson_distance_matrix(self, missing_value_cut_off=None) :
        """
        Calculate Pearson distance matrix for 2D array of data with missing values. Distance between each pair of structures is calculated using mutually non-missing values. For properties with multiple dimensions, the dimensions are flattened and each dimension is assumed to be pre-normalised to be on the same scale.

        Input Parameters
        ----------------

        missing_value_cut_off: integer
            Alignment positions when many residues are disordered are coloured gray. This parameter controls what percentage of structure have missing residues before a whole alignment position is ignored. Allowed range (0-100), unused by default
        """
        print "\nCalculating Pearson distance matrix of size ", self.size, " x ", self.length * self.data_dim
        data = self.data.copy()
        
        # Optionally mask whole gappy columns
        if missing_value_cut_off != None :
            self._mask_gappy_columns(data, missing_value_cut_off)
        
        # If multidimensional data, flatten to 2D array
        data.shape = self.size, self.length*self.data_dim
            
        # Calculate (Pearson) correlation coefficient matrix. This function ignores masked values. 
        corr = numpy.ma.corrcoef(data)

        # Convert to distance
        dist = (1 - corr)/2.0
        
        return dist

    @print_timing
    def calculate_Spearman_distance_matrix(self) :
        """
        Calculate Spearman distance matrix for 2D array of data with missing values. Distance between each pair of structures is calculated using mutually non-missing values. For properties with multiple dimensions, the dimensions are flattened.
        """
        print "\nCalculating Spearman distance matrix of size ", self.size, " x ", self.length * self.data_dim
        data = self.data.copy()
        
        # If multidimensional data, flatten to 2D array
        data.shape = self.size, self.length*self.data_dim
        
        # Convert data to ranks (not needed in more recent versions of scipy use stats.spearmanr instead)
        ranks = numpy.ma.array(data.argsort(axis=1))
        ranks.mask = data.mask 
            
        # Calculate (Spearman rank) correlation coefficient matrix. This function ignores masks.
        corr = numpy.ma.corrcoef(ranks)

        # Convert to distance
        dist = (1 - corr)/2.0
        
        return dist

    @print_timing
    def calculate_manhatten_distance_matrix(self, all_mask=False) :
        """
        Calculate distance matrix using the manhatten/city block metric
        """
        if self.data_dim > 1 :
            print "\nCalculating manhatten distance matrix of size ", self.size, " x ", self.length, " x ", self.data_dim
        else :
            print "\nCalculating manhatten distance matrix of size ", self.size, " x ", self.length
        
        distmat = numpy.zeros(self.size*self.size)
        distmat.shape = self.size, self.size
        for iseq in range(0, self.size-1 ) :
            i_mask = self.data.mask[iseq].flatten()
            for jseq in range(iseq+1,self.size) :
                j_mask = self.data.mask[jseq].flatten()
                ij_mask = i_mask | j_mask | all_mask
                diffs = numpy.absolute(self.data.data[iseq].flatten() - self.data.data[jseq].flatten())
                numpy.putmask(diffs,ij_mask,0.0)
                #n = numpy.invert(ij_mask).sum()/self.data_dim # number of non-masked residues
                n = numpy.invert(ij_mask).sum() # number of non-masked values
                dist = 100.0 * numpy.ma.add.reduce(diffs)/max(n,1)
                distmat[iseq,jseq] = dist
                distmat[jseq,iseq] = dist
        return distmat

    def calculate_tanimoto_distance_matrix(self, all_mask=False) :
        """
        Calculate Tanimoto distance matrix.
        """
        if self.data_dim > 1 :
            print "\nCalculating Tanimoto distance matrix of size ", self.size, " x ", self.length, " x ", self.data_dim
        else :
            print "\nCalculating Tanimoto distance matrix of size ", self.size, " x ", self.length

        distmat = numpy.zeros(self.size*self.size)
        distmat.shape = self.size, self.size
        for iseq in range(0, self.size-1 ) :
            i_mask = self.data.mask[iseq].flatten()
            i_bits = self.data[iseq].flatten() > 0
            for jseq in range(iseq+1,self.size) :
                j_mask = self.data.mask[jseq].flatten()
                ij_mask = i_mask | j_mask | all_mask
                j_bits = self.data[jseq].flatten() > 0
                i_bits.mask = ij_mask
                j_bits.mask = ij_mask
                n_common_bits = numpy.ma.sum(i_bits & j_bits)
                n_sum_bits = numpy.ma.sum(i_bits) + numpy.ma.sum(j_bits)
                if n_sum_bits == 0 : # no features in either
                    sim = 1.0
                elif n_common_bits == 0 : # no common features
                    sim = 0.0
                else :
                    sim =  float(n_common_bits) /  (n_sum_bits - n_common_bits)
                dist = 1.0 - sim
                distmat[iseq,jseq] = dist
                distmat[jseq,iseq] = dist
        numpy.putmask(distmat, numpy.invert(numpy.isfinite(distmat)), 1.0)
        return distmat

    def unmasked_tanimoto_distance_matrix(self) :
        """
        Calculate Tanimoto distance matrix.
        """
        distmat = numpy.zeros(self.size*self.size)
        distmat.shape = self.size, self.size
        for iseq in range(0, self.size-1 ) :
            i_bits = self.data[iseq].flatten() > 0
            for jseq in range(iseq+1,self.size) :
                j_bits = self.data[jseq].flatten() > 0
                n_common_bits = numpy.sum(i_bits & j_bits)
                sim =  float(n_common_bits) /  (numpy.sum(i_bits) + numpy.sum(j_bits) - n_common_bits)
                distmat[iseq,jseq] = dist
                distmat[jseq,iseq] = dist
        return distmat
    
    def put_mask(self, dim, values = []) :
        """
        Apply a mask to a single dimension within a multidimensional property array. If value is specified then only residues that have this value at this dimension are masked. These masks are added to any pre-existing masks
        
        Parameters
        ----------
        
        dim : int
            the dimension to mask. Must be greater than zero and less than than self.data_dim
            
        value : list of int (default = [])
            mask residue only when specified dimension has one of specified values in the list.

        Returns
        -------
        
        a numpy array of dtype bool with same dimensions as self.data
        
        Examples
        --------
        
        >>> # to mask phi for psi dihedral angle comparison only
        >>> aligned = Structural_Alignment()
        >>> aligned.add_alignment("my_alignment.fasta")
        >>> phipsi_array = Phi_Psi_Alignment_Array(aligned, update=False)
        >>> phipsi_array.put_mask(0)
        
        """
        mask = self.data.mask.flatten()
        if len(values) == 0 :
            for i in range(len(mask)) :
                mask[i] = (i-dim)%self.data_dim == 0
        else :
            data = self.data.data.flatten()
            for i in range(len(mask)) :
                mask[i] = ((i-dim)%self.data_dim == 0) & (data[i] in values)
            
        if self.data_dim > 1 :
            mask.shape = self.size, self.length, self.data_dim
        else:
            mask.shape = self.size, self.length
        self.data.mask += mask
    
    @print_timing
    def calculate_Euclidean_distance_matrix(self, all_mask=False) :
        """
        Calculate distance matrix using the Euclidean distance
        """
        distmat = numpy.identity(self.size)
        for iseq in range(0, self.size-1 ) :
            i_mask = self.data.mask[iseq].flatten()
            for jseq in range(iseq+1,self.size) :
                j_mask = self.data.mask[jseq].flatten()
                ij_mask = i_mask | j_mask | all_mask
                diffs = numpy.square(self.data.data[iseq].flatten()-self.data.data[jseq].flatten())
                numpy.putmask(diffs,ij_mask,0.0)
                n = numpy.invert(ij_mask).sum()/self.data_dim # number of non-masked residues
                dist = 100.0 * numpy.sqrt(numpy.ma.add.reduce(diffs))/max(n,1)
                distmat[iseq,jseq] = dist
                distmat[jseq,iseq] = dist
        return distmat        
        
    def calculate_group_variance(self, groups, separate_components=False) :
        """
        Variances are the within group average difference from the overall average for each alignment position. Random fluctuations are averaged out and
        intergroup differences accentuated.
        Input: groups as list of lists of sequence alignment row numbers (range = 0 to self.size-1). Not all rows numbers need be included.
        Output: numpy array with length self.length   (default value = 0.0) 
        """
    
        # calculate alignment position average, ignoring masked values and only include proteins are in one of the supplied groups
        all_group_members = list(set([i for sublist in groups for i in sublist])) # flattened groups. Set ensures row indices are not included multiple times.
        property_average = numpy.ma.average(self.data[all_group_members],axis=0)
    
        # set mask positions to column average
        values = self.data.copy().astype(float)
        numpy.putmask(values.data, values.mask, property_average)
        values.mask = False # set all masks False otherwise cumulative sum is adversely effected
    
        # Create array of correct shape to hold the results
        variance = numpy.ma.zeros(len(groups)*self.length*self.data_dim)
        variance.mask = False        
        if self.data_dim > 1 :
            variance.shape = len(groups),self.length,self.data_dim
        else :
            variance.shape = len(groups),self.length
    
        # Calculate sum difference from the average from each group        
        igroup = 0
        for group in groups :
            for idx in group :
                variance[igroup] += (values[idx] - property_average)
            variance[igroup] /= len(group)
            igroup += 1
            
        if not separate_components :
            # Sum absolute contribution from each dimension
            if self.data_dim > 1 :
                variance = numpy.ma.sum(numpy.ma.absolute(variance), axis=2)
            # Average group variance
            variance = numpy.ma.sum(variance, axis=0)/(len(groups)*self.data_dim)
        return variance
    
    def ANOVA(self, groups) :
        """
        The one-way ANOVA tests the null hypothesis that two or more groups have the same population mean.
        """
        # calculate alignment position median, ignoring masked values and only include proteins are in one of the supplied groups
        all_group_members = list(set([i for sublist in groups for i in sublist])) # flattened groups. Set ensures row indices are not included multiple times.
        property_median = numpy.ma.median(self.data[all_group_members],axis=0)
    
        ## set mask positions to column median
        values = self.data.copy().astype(float)
        #numpy.putmask(values.data, values.mask, property_median)
    
        #p_values = numpy.zeros(self.length*self.data_dim)
        p_values = numpy.ma.zeros(self.length*self.data_dim)
        p_values.mask = False
        if self.data_dim > 1 :
            p_values.shape = self.length,self.data_dim
            for ires in range(self.length) :
                for iprop in range(self.data_dim) :
                    #groups_data = [values.data[group,ires,iprop] for group in groups if len(values.data[group,ires,iprop]) > 1]
                    groups_data = [values[group,ires,iprop] for group in groups if len(values[group,ires,iprop]) > 1]
                    try :
                        #p_values[ires, iprop] = stats.f_oneway(*groups_data)[1]
                        p_values[ires, iprop] = stats.mstats.kruskalwallis(*groups_data)[1]
                        #p_values[ires, iprop] = stats.mstats.f_oneway(*groups_data)[1]
                    #except ValueError, message :
                    except :
                        p_values.mask[ires, iprop] = True
                        #if str(message) != "All numbers are identical in f_oneway" :
                        #    print message
        else :
            for ires in range(self.length) :
                #groups_data = [values.data[group,ires] for group in groups]
                groups_data = [values[group,ires] for group in groups]
                try :
                    #p_values[ires] = stats.f_oneway(*groups_data)[1]
                    p_values[ires] = stats.mstats.kruskalwallis(*groups_data)[1]
                    #p_values[ires] = stats.mstats.f_oneway(*groups_data)[1]
                except ValueError, message :
                    if str(message) != "All numbers are identical in f_oneway" :
                        print message
        
        return p_values
    
    def Kolmogorov_Smirnov(self, groups) :
        """
        Test for a significant difference between two groups at each alignment position. Returns a array of p-values of shape (self.length, self.data_dim) or (self.length) for single dimension properties. If p <= 0.05 then there is a singnificant difference between the two groups.
        """
        # Check only 2 groups
        if len(groups) !=2 :
            raise RuntimeError("This function only works for two groups. You have specified "+str(len(groups)))

        p_values = numpy.ma.zeros(self.length*self.data_dim)
        p_values.mask = False
        if self.data_dim > 1 : # multidimensional property
            p_values.shape = self.length,self.data_dim
            for ires in range(self.length) :
                for iprop in range(self.data_dim) :
                    group0 = self.data[groups[0],ires,iprop]
                    group1 = self.data[groups[1],ires,iprop]
                    try :
                        p_values[ires, iprop] = stats.mstats.ks_2samp(group0, group1)[1]
                    except ValueError :
                        p_values.mask[ires, iprop] = True
        else : # single dimension property
            for ires in range(self.length) :
                group0 = self.data[groups[0],ires]
                group1 = self.data[groups[1],ires]
                try :
                    p_values[ires] = stats.mstats.ks_2samp(group0, group1)[1]
                except ValueError :
                    p_values.mask[ires] = True
                    
        # Check all values are not masked
        if numpy.sum(p_values.mask) == len(p_values) :
            raise RuntimeError("Something went wrong! All p-values are masked")
            
        return p_values
        
    def outlier(self, index, group) :
        """
        For each residue position, calculate the number of standard deviations from the mean and a group of structures (group) of a structure (index). This function should be used to see how an outlying protein (e.g. from cluster analysis) differs from the bunch.
        
        Input Parameters
        ----------------

        index: integer
            index of outlying structure in alignment file (starting at zero)
            
        group: list of int
            list of indices of structures to use for the calculation of the mean and standard deviation.
        """
        
        avg = numpy.ma.average(self.data[group], axis=0)
        std = numpy.ma.std(self.data[group], axis=0)
        dev = (self.data[index] - avg)/std
        
        if self.data_dim > 1 :
            dev = numpy.sum(numpy.ma.absolute(dev), axis=1)
            #dev = numpy.ma.sqrt(numpy.sum(numpy.square(dev), axis=1))
        return dev
    
    def trace(self, groups) :
        """
        Calculate something analogous to an evolutionary trace for a given property. Trace is the summed difference between intragroup average and overall average for each property value
        for each alignment position. Values for multidimenional properties are reduced to a single number per alignment position by taking the geometric mean. EXPERIMENTAL
        """
        # calculate alignment position average, ignoring masked values and only include proteins are in one of the supplied groups
        all_group_members = list(set([i for sublist in groups for i in sublist])) # flattened groups. Set ensures row indices are not included multiple times.
        #overall_average = numpy.ma.average(self.data[all_group_members],axis=0)
        overall_range = numpy.ma.max(self.data[all_group_members],axis=0) - numpy.ma.min(self.data[all_group_members],axis=0)
        

        # Create array hold results
        max_group_range = numpy.ma.zeros(self.length*self.data_dim)
        if self.data_dim > 1 :
            max_group_range.shape = self.length,self.data_dim
        max_group_range.mask = overall_range.mask
        
        # For calculate cumulative sum of overall average minus group average
        for group in groups :
            #group_average = numpy.ma.average(self.data[group],axis=0)
            #group_sd = numpy.ma.std(self.data[group],axis=0)
            group_range = numpy.ma.max(self.data[group],axis=0) - numpy.ma.min(self.data[group],axis=0)
            numpy.putmask(group_range.data, group_range.mask, 0.0)
            max_group_range = numpy.ma.maximum(max_group_range, group_range.data)
            #trace += overall_average - group_average
        trace_array = overall_range - max_group_range
            
        # Reduce to one value per alignment position
        trace_array = reduce(trace_array)
        overall_range = reduce(overall_range)
        max_group_range = reduce(max_group_range)
        
        combined = numpy.ma.vstack((trace_array, overall_range, max_group_range))

        return combined
                
    def centre(self, groups=None) :
        """
        Centre on average. If groups are defined then, centre on group average. If groups defined, data for structures
        not in a group is masked. Centre self.data ! Changes data irrevocably. 
        """
        self.data = self.centred(groups)

    def centred(self, groups=None) :
        """
        Centre on average. If groups are defined then, centre on group average. If groups defined, data for structures
        not in a group is masked. Return copy of data centred, original data is unchanged.
        """
        data_copy = self.data.copy()
        if groups == None :
            data_copy -= numpy.ma.average(self.data,axis=0)
        else :
            # Shift by group average.
            if type(groups[0]) == list :
                for group in groups :
                    data_copy[group] -= numpy.ma.average(self.data[group],axis=0)
            else :
                data_copy[groups] -= numpy.ma.average(self.data[groups],axis=0)
            # Mask any rows not in a group
            all_group_members = list(set([i for sublist in groups for i in sublist])) # flattened groups
            not_in_a_group = [i for i in range(self.size) if not i in all_group_members]
            data_copy.mask[not_in_a_group] = True

        return data_copy
                     
    def reduce(self, method="gmean") :
        """
        Reduce multidimensional data to a single number per residue. The default method is to take to the geometric mean. This can be changed by creating a subclass method.
        """
        return reduce(self.data, method)
    
    def select_dimension(self, dimension) :
        """
        For multidimensional property classes return the data as a 2d array containing only the selected dimension.
        """
        if self.data_dim == 1 :
            return self.data
        else :
            if dimension > self.data_dim - 1 or dimension < 0:
                raise RuntimeError("Selected dimension is not available this property.")
            else :
                selection = self.data[:,:,dimension]
                return selection
    
    def select_dimension_for_single_chain(self, dimension, idx) :
        """
        Select a single property dimension for a single chain. Results in 1d array of length self.length()
        """
        twod = self.select_dimension(dimension)
        return twod[idx]
        
    #def select_column(self, alignment_position, dimension=0)
    
    def get_complete_matrix(self, max_pc_chains_to_ignore=10, dimensions=[]) :
        """
        Return largest unmasked complex matrix. Multiple dimensions flattened into 1. Uses a quick and dirty method of removing chains in an attempt to maximise the size of the matrix.
        max_pc_chains_to_ignore : the maximum percentage of chains allowed to be removed in order to increase the number of residue positions included in the matrix
        returns : array and indices of remaining chains and alignment positions
        """
        
        # Copy data array, slicing if required
        bma = self.data.copy()
        if len(dimensions) > 0 :
            # mask dimensions not selected
            unwanted_dimensions = [i for i in range(self.data_dim) if i not in dimensions]
            bma.mask[:,:,unwanted_dimensions] = True
        num_dim = self.data_dim
            
        # Put values into 2D array 
        bma.shape = self.size, self.length*num_dim
        print "Creating complete data matrix."
        print "initial shape: ", bma.shape
        
        # Initialise 
        remaining_chain_indices = numpy.array(range(self.size))
        remaining_columns = numpy.array(range(self.length*num_dim))
        num_chains_cutoff = max_pc_chains_to_ignore * self.size/100.0 # cutoff as number of chains
        num_removed = 0 
        
        # Remove all chains that have completely masked arrays (e.g. bfactors for md snapshots)
        notallmasked = bma.mask.sum(axis=1) != bma.shape[1] # chains not completely masked
        bma = bma[notallmasked,:]
        indices_to_remove = remaining_chain_indices[notallmasked==False]
        if len(indices_to_remove) != 0 :
            print "All vallues masked. Removing ", self.alignment.ids_for_groups(indices_to_remove), " from calculation."
        remaining_chain_indices = remaining_chain_indices[notallmasked]
        
        # Remove chains that introduce gaps that remove whole columns
        #
        num_gaps = bma.mask.sum(axis=0) # number of gaps in each column
        num_gaps_order = numpy.argsort(num_gaps) # column order with increasing number of gaps

        for i in range(bma.shape[1]) :
            # process columns in order of increasing number of gaps
            current_column = num_gaps_order[i]
            chain_idx = numpy.array(range(bma.shape[0])) # indices of remaining chains
            # find where there are gaps in current column
            gaps = bma.mask[:,current_column]
            num_gaps = numpy.sum(gaps)            
            # if no gaps in current column continue to next
            if num_gaps == 0 :
                continue
            # check if too many chains will be removed
            if num_gaps + num_removed > num_chains_cutoff : 
                break
            # removed chains with gaps in current column
            gapped_chain_idx = chain_idx[gaps] 
            temp = numpy.delete(bma, gapped_chain_idx, axis=0)
            temp.mask = numpy.delete(bma.mask, gapped_chain_idx, axis=0)
            bma = temp
            print "Removing ", self.alignment.ids_for_groups(gapped_chain_idx), " from calculation."
            remaining_chain_indices = numpy.delete(remaining_chain_indices, gapped_chain_idx)
            num_removed += num_gaps
        
        # Remove any columns with missing (masked) variables
        array = bma[:,bma.mask.sum(axis=0)==0].data
        remaining_columns = remaining_columns[bma.mask.sum(axis=0)==0]
        print "final shape: ", array.shape

        return array, remaining_chain_indices, remaining_columns

    @print_timing
    def calculate_residue_correlation_matrix(self) :
        """
        Calculate residue correlation matrix. Set values for masked residues to alignment position average.
        Returns numpy array of dimensions [size, length*data_dim]. 
        """
        
        # Create 2D array and transpose.
        new_arr = self.data.copy()
        new_arr.shape = self.size,self.length*self.data_dim
        new_arr = numpy.ma.transpose(new_arr)
        
        # Set masked values to mean so that they don't effect the result
        means = numpy.mean(new_arr, axis=1) # one value per length*data_dim
#        for i in xrange(self.length) :
        for i in xrange(self.length*self.data_dim) :
            numpy.putmask(new_arr.data[i],new_arr.mask[i],means.data[i])
        
        # Calculate covariance matrix
        corr_mat = numpy.corrcoef(new_arr.data)
        numpy.putmask(corr_mat, numpy.isnan(corr_mat), 0.0) 

        return corr_mat

    def calculate_residue_correlation(self, ydata) :
        """
        Calculate residue correlation to a given array of data. Ignore alignment positions which contain masked
        residue. ydata must 1D array of length equal to the number of structures in the alignment (self.size). Returns a 1D array of length self.length * self.data_dim i.e. a coorelation coefficient for each property value of each alignment position. 
        """
        if len(ydata) != self.size :
            raise RuntimeError("ydata must 1D array of length equal to the number of structures in the alignment. Current values are: "+str(self.size())+" and "+str(len(ydata))) 
            
        # Create 2D array of property data
        new_arr = self.data.copy()
        new_arr.shape = self.size,self.length*self.data_dim
        
        # Add ydata as last column
        ydata = numpy.array(ydata)
        ydata.shape = len(ydata),1
        new_arr = numpy.ma.hstack((new_arr, ydata))
        
        # Transpose        
        new_arr = numpy.ma.transpose(new_arr)
        
        # Set masked values to mean so that they don't effect the result
        means = numpy.mean(new_arr, axis=1)
        
        for i in xrange(self.length) :
            numpy.putmask(new_arr.data[i],new_arr.mask[i],means.data[i])
        
        # Calculate covariance matrix
        corr_mat = numpy.corrcoef(new_arr.data)
        numpy.putmask(corr_mat, numpy.isnan(corr_mat), 0.0) 

        # Return only coorelation coefficiants to ydata (should be 1 per residue position * self.data_dim)
        return corr_mat[-1][:-1]
   
    def average_per_residue(self, sliding_window=1, normalise=False) :
        """
        Calculate average property value for each alignment position. If sliding_window > 1 then these averaged are themselves averaged over sliding_window/2 residue positions either side of the residue position.
        """
        if self.data_dim > 1:
            avg = numpy.ma.average([self.data[:,i].flatten() for i in range(self.length)],axis=1)
        else :
            avg = numpy.ma.average(self.data,axis=0)

        if sliding_window > 1 :
            savg = numpy.ma.zeros(self.length)
            savg.mask = False
            window_index = get_sliding_window_index(sliding_window, self.length)
            savg[sliding_window/2:self.length-sliding_window/2] = numpy.ma.average(avg[window_index],axis=1)
            avg = savg
            
        if normalise :
            avg_avg = numpy.ma.average(avg)
            sd_avg = numpy.ma.std(avg)
            avg = (avg-avg_avg)/sd_avg

        return avg
    
    def average_1d_per_residue(self, dim=0) :
        """
        Return the average per alignment position for a single dimension of a multidimensional property type.
        dim=0 : the index of the dimension to be used. Must be < self.data_dim
        """
        if dim >= self.data_dim :
            print "\ndim must be less than", self.data_dim
            raise IndexError
        if self.data_dim == 1 : 
            return numpy.ma.average(self.data, axis=0)
        else :
            return numpy.ma.average(self.data[:,:,dim], axis=0)
        
    def count_per_alignment_position(self, group = None) :
        """
        Count non-zero and non-masked residues per alignment position. If group is defined only those structure in the group are included in the count.
        """
        if group == None :
            group = range(self.size) # all structures
        if self.data_dim > 1:
            boolean_data = numpy.ma.sum(self.data[group],axis=2) > 0
        else :
            boolean_data = self.data[group] > 0
        count = numpy.ma.sum(boolean_data,axis=0)
        return count
        
    def calculate_variability(self, groups=None, missing_value_cut_off=50, metric='euclidean', normalise=False) :
        """
        Calculate the average absolute deviation from the median for each alignment position. For multidimensional data the deviation is measured using the given metric. Choices of
        metric can be found in the documentation for scipy.spatial.distance.cdist.
        
        Input Parameters
        ----------------
        groups: list of list of integers
            If the alignment contains structures from different proteins then you might want to consider only the variation within each protein (conformational change), instead of the overall variability (conformational + structural change). To do this create a list of lists of structure indices e.g. [[1,2,3],[4,5,6,7]]
            
        missing_value_cut_off: integer
            Alignment positions when many residues are disordered are coloured gray. This parameter controls what percentage of structure have missing residues before the gray is used. Allowed values are in the range 0 - 100
            
        metric : keywords
            Distance metric used. Choices of metric can be found in the documentation for scipy.spatial.distance.cdist.
            
        normalise : bool
            if True than values are standardised by average and standard deviation
            
        """
        
        if groups != None :
            # Centre data on group average
            data = self.centred(groups)
            
            # Mask positions where number masked within group is above percentage cutoff
            size = 0
            for group in groups :
                group_size = len(group)
                size += group_size
                self._mask_gappy_columns(data[group], missing_value_cut_off)
                #num_masked = numpy.sum(self.data.mask[group], axis=0)
                #pc_masked = 100.0 * num_masked/group_size
                #data.mask[group] += pc_masked > missing_value_cut_off
            if size < 3 :
                raise RuntimeError("You need at least 3 structures to calculate variability.")
            data = self.data
        else :
            
            if self.size < 3 :
                raise RuntimeError("You need at least 3 structures to calculate variability.")
            data = self.data.copy()
            
            # Mask positions where number already masked is above percentage cutoff
            self._mask_gappy_columns(data, missing_value_cut_off)
            #num_masked = numpy.sum(data.mask, axis=0)
            #pc_masked = 100.0 * num_masked/self.size
            #data.mask += pc_masked > missing_value_cut_off # masks whole columns

        # Calculate median value for each dimension, for each alignment position
        median = numpy.ma.median(data,axis=0)

        # Calculate mean absolute difference from median
        if self.data_dim > 1:
            median.shape = self.length, self.data_dim
            # For multidimensional data, use Euclidean distance.
            dists = numpy.ma.zeros(self.size*self.length)
            dists.shape = self.size, self.length
            dists.mask = False
            for ipos in range(self.length) :
                med = median[ipos]
                med.shape = 1,self.data_dim
                if med.mask.any() == True :
                    dists.mask[:,ipos] = True
                    continue
                pos_dists = numpy.ma.array(cdist(data[:,ipos], med, metric=metric))
                pos_dists.shape = self.size
                dists.data[:,ipos] = pos_dists
            dists.mask += data.mask[:,:,0]
            average_absolute_deviation = numpy.ma.average(dists, axis=0)
        else:
            average_absolute_deviation = numpy.ma.average(numpy.ma.absolute(data - median), axis=0)
        
        # Normalise
        if normalise :
            avg = numpy.ma.average(average_absolute_deviation)
            sd = numpy.ma.std(average_absolute_deviation)
            average_absolute_deviation = (average_absolute_deviation-avg)/sd

        # Set data value to maximum where position is masked
        maxvar = numpy.ma.max(average_absolute_deviation)
        average_absolute_deviation.data[average_absolute_deviation.mask] = maxvar
        return average_absolute_deviation           
            
    def find_conserved_segments(self, threshold=0.3):
        """
        Find continuous segments of conserved (in property space) alignment positions
        """
        residue_variability = self.calculate_variability(missing_value_cut_off=0)
        core_segment_id = 0
        new_segment = True
        self.segments = []
        max_var_array = []
        for i in range(self.length) :
            if residue_variability[i] < threshold :
                if new_segment :
                    segment_start = i
                    max_var = residue_variability[i]
                    new_segment = False
                else :
                    max_varclust = max(max_var, residue_variability[i])
            else :
                if not new_segment :
                    segment_end = i-1
                    if segment_start != segment_end :
                        segment = (segment_start,segment_end)
                        self.segments.append(segment)
                        max_var_array.append(max_var)
                    new_segment = True
                    
        # Finish off last segment
        if not new_segment :
            segment_end = self.length
            segment = (segment_start,segment_end)
            self.segments.append(segment)
            max_var_array.append(max_var)
        
        return self.segments
    
    def calculate_structure_dissimilarity_matrix(self, update=False) :
        """
        Return a Structure_Matrix object (see :doc:`comparison_matrices`) which contains a structure dissimmarity matrix.
        """
        return Structure_Matrix(self,update)

    def calculate_alignment_position_dissimilarity_matrix(self, update=False) :
        """
        Return a Residue_Matrix object (see :doc:`comparison_matrices`) which contains an alignment position dissimmarity matrix.
        """
        return Residue_Matrix(self,update)
        
    def calculate_structure_similarity_tree(self, method = 'a', update=False) :
        """
        Return a Tree object (see :doc:`trees`) containing a heirarchical clustering of structures based upon this property
        """
        mat = self.calculate_structure_dissimilarity_matrix(update)
        labels = self.alignment.get_labels()
        return Tree(mat.get_distance_matrix(),labels,method)
        
    def calculate_alignment_position_similarity_tree(self, method = 'a', update=False) :
        """
        Return a Tree object (see :doc:`trees`) containing a heirarchical clustering of residue alignment positions based upon this property
        """
        mat = self.calculate_alignment_position_dissimilarity_matrix(update)
        compressed_mat,ids = mat.get_compressed_distance_matrix()
        labels = [self.alignment.label_from_id(id) for id in ids]
        return Tree(compressed_mat,labels,method)
    
    def make_jalview_feature_file(self, filename, class_name, feature_name, s_col, e_col, s_wt, e_wt, standardise=True) :
        """
        To create new JalviewFeatureFileCreator object. This will contain residue feature for a given type of feature. You need to specify the type and name of this feature, the colour range to use and the property limits associated with this range.
    
        Parameters
        ----------
        
        filename : string
            name of file to produce. I use the .ano suffix
        class_name : string
            label for feature type
        feature_name : string
            label for feature
        s_col : string
            starting colour in range in RGB hexadecimal e.g. "FFDDBB"
        e_col : string
            end colour in range in RGB hexadecimal e.g. "CC3300"
        s_wt : number
            starting weight in range, weights less than or equal to this number are coloured s_col
        e_wt : number
            starting weight in range, weights greater than or equal to this number are coloured e_col
    
       
        Examples
        --------
        
        """
        
        jalfile = JalviewFeatureFileCreator(class_name, feature_name, s_col, e_col, s_wt, e_wt)

        #print self.data[0]
        if self.data_dim > 1 :
            data = self.reduce()
        else :
            data = self.data
        #print data[0]
            
        if self.data_type == int :
            jalfile.add_features(self.alignment, data)
        elif self.data_type == float :
            jalfile.add_features_from_2d_descriptor(self.alignment, data, standardise=standardise)

        jalfile.write_file(filename)
        
class Derived_Alignment_Property_Array(Structural_Alignment_Property_Array) :

    """
    Class for the creation of temporary Structural_Alignment_Property_Array derived from for example subtracting one from another. EXPERIMENTAL
    """
    def __init__(self, structural_alignment_property_array_object) :
        self.data_directory = "temp"
        self.id = "derived"
        self.length = structural_alignment_property_array_object.length
        self.size = structural_alignment_property_array_object.size
        self.alignment = structural_alignment_property_array_object.alignment
        self.data_dim = structural_alignment_property_array_object.data_dim
        self.data_type = structural_alignment_property_array_object.data_type        
        self.data = structural_alignment_property_array_object.data.copy()
        self.dim_names = structural_alignment_property_array_object.dim_names
        
    def write_jalview_feature_file(self, filename) :
        jalfile = JalviewFeatureFileCreator()
        jalfile.write_feature_file("derived.ano", self.alignment, self.data, "Contact", "DERIVED", "FFDDBB", "CC3300", 10, 50)

    def calculate_distance_matrix(self) :
        return self.calculate_manhatten_distance_matrix()
            

