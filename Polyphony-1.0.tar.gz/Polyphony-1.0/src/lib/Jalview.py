"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Utils import reduce
import numpy

class JalviewFeatureFileCreator :
    """
    A collection of functions for writing correctly formatted Jalview feature files.
    See http://www.jalview.org/help.html for more details on these files.

    To create new JalviewFeatureFileCreator object. This will contain residue feature for a given type of feature. You need to specify the type and name of this feature, the colour range to use and the property limits associated with this range.
    
    Parameters
    ----------
    
    class_name : string
        label for feature type
    feature_name : string
        label for feature
    s_col : string
        starting colour in range in RGB hexadecimal e.g. "FFDDBB"
    e_col : string
        end colour in range in RGB hexadecimal e.g. "CC3300"
    s_wt : number
        starting weight in range, weights less than or equal to this number are coloured s_col
    e_wt : number
        starting weight in range, weights greater than or equal to this number are coloured e_col

   
    Examples
    --------
    
    >>> 
    >>> jalfile = JalviewFeatureFileCreator("Contact", "DERIVED", "FFDDBB", "CC3300", 10, 50)
    >>> jalfile.add_features(self.alignment, self.data)
    >>> jalfile.write_file("derived.ano")
        

    """
    
    def __init__(self, class_name, feature_name, s_col, e_col, s_wt, e_wt) :
        """
        Create new JalviewFeatureFileCreator object. See class level documentation for usage.
        """
        self.featureColours = {}
        self.featureMinMax = {}
        self.lines = []
        self.add_feature_type(feature_name, s_col, e_col, s_wt, e_wt)
        self.class_name = class_name
        self.feature_name = feature_name
      
    def add_feature_type(self, featureType, mincolour, maxcolour, min, max) :
        """
        Define the colour of a given feature type. 
        """
        self.featureColours[featureType] = (mincolour,maxcolour)
        self.featureMinMax[featureType] = (min,max)
        
    def add_feature(self, chain_code, residueStart, residueEnd, value, type=None) :
        """
        Add a single line residue (or range of residues) feature annotation
        """
        if type == None :
            self.lines.append(self.class_name+"\t"+chain_code+"\t-1\t"+str(residueStart)+"\t"+str(residueEnd)+"\t"+self.feature_name+"\t"+str(value)+"\n")
        else :
            self.lines.append(self.class_name+"\t"+chain_code+"\t-1\t"+str(residueStart)+"\t"+str(residueEnd)+"\t"+type+"\t"+str(value)+"\n")
        
    def write_file(self, filename) :
        """
        Write a jalview feature file. I usually use the .ano suffix.
        """
        feature_file = open(filename, "w")
        for i in self.featureColours.keys() :
            feature_file.write(i+"\t"+str(self.featureColours[i][0])+"|"+str(self.featureColours[i][1])+"|"+str(self.featureMinMax[i][0])+"|"+str(self.featureMinMax[i][1])+"\n")
        for line in self.lines :
            feature_file.write(line)
        
        print "\nFile",filename,"created."

        feature_file.close()
        
    def start_jalview_feature_group(self,number) :
        """
        Starts a jalview feature group
        """
        self.lines.append("startgroup\tg"+str(number)+"\n")

    def end_jalview_feature_group(self,number) :
        """
        Ends a jalview feature group
        """
        self.lines.append("endgroup\tg"+str(number)+"\n")

    def add_features_from_1d_descriptor(self, alignment, descriptor, cutoff=1.0) :
        """
        Add features for all sequences in the provided alignment based upon a 1D array of real numbers.
        
        Parameters
        ----------
        descriptor : 1d numpy masked array
            the values to be used to generate the feature annotations. Must be the same length as provided alignment
            
        alignment : Polyphony.Structural_Alignment instance
            the alignment to which the descriptor applies. Features will be duplicated for each sequence.
            
        cutoff : float
            only residues with descriptor values, cutoff standard deviations above the mean are annotated.
        """
        
        # Check descriptor is 1d masked array of same length as alignment
        if type(descriptor) != numpy.ma.core.MaskedArray :
            raise TypeError("The descriptor parameter must be a numpy masked array e.g. a = numpy.ma.array(range(10)). This type was provided: "+str(type(descriptor)))

        if len(descriptor.shape) != 1 or descriptor.shape[0] != alignment.length() :
            raise ValueError("The descriptor parameter must be a 1d array of same length as the alignment object parameter. Shape and alignment length: "+str(descriptor.shape)+" "+str(alignment.length()))
        
        # Standardise
        descriptor = (descriptor - numpy.mean(descriptor))/numpy.std(descriptor)
        
        # Keep those which are greater than cutoff standard deviations above the mean
        descriptor.mask += descriptor < cutoff
        numpy.putmask(descriptor.data, descriptor.mask, 0.0)
        
        # Duplicate hits array, one for each sequence in the alignment
        hits = numpy.row_stack([descriptor for i in range(alignment.size())])

        # Write Jalview feature file
        self.add_features(alignment, hits)
    
    def add_features_from_2d_descriptor(self, alignment, descriptor, cutoff=1.0, standardise=True) :
        """
        Add features for all sequences in the provided alignment based upon a 2D array of real numbers.
        
        Parameters
        ----------
        descriptor : 2d numpy masked array
            the values to be used to generate the feature annotations. Must be the same length as provided alignment
            
        alignment : Polyphony.Structural_Alignment instance
            the alignment to which the descriptor applies. Features will be duplicated for each sequence.
            
        cutoff : float
            only residues with descriptor values, cutoff standard deviations above the mean are annotated.
        """
        
        # Check descriptor is 1d masked array of same length as alignment
        if type(descriptor) != numpy.ma.core.MaskedArray :
            raise TypeError("The descriptor parameter must be a numpy masked array e.g. a = numpy.ma.array(range(10)). This type was provided: "+str(type(descriptor)))

        if len(descriptor.shape) != 2 or descriptor.shape[1] != alignment.length() or descriptor.shape[0] != alignment.size() :
            raise ValueError("The descriptor parameter must be a 1d array of same length as the alignment object parameter. Shape and alignment length: "+str(descriptor.shape)+" "+str(alignment.size())+","+str(alignment.length()))
        
        # Standardise
        #print descriptor[0]
        if standardise :
            descriptor = (descriptor - numpy.mean(descriptor, axis=0))/numpy.std(descriptor, axis=0)
        #print descriptor[0]
        
        # Keep those which are greater than cutoff standard deviations above the mean
        descriptor.mask += abs(descriptor) < cutoff
        numpy.putmask(descriptor.data, descriptor.mask, 0.0)
        #print descriptor[0]
        
        # Write Jalview feature file
        self.add_features(alignment, descriptor)
    
    def add_features(self, alignment, values, type=None) :
        """
        Add features for a given alignment. The values determine the colour weighting of feature and must be an array of same shape as the alignment. Values will be converted to integers.
        
        Parameters
        ----------
        
        alignment : Structural_Alignment instance
            the alignment to which these features pertains

        values : array of numbers of shape = alignment.size, alignment.length
            the values of the feature to be labelled. Masked and zero weighted residues are ignored
        
        """
        res2pos, ires2pos, pos2res, pos2ires = alignment._create_residue_indices()
        ids = alignment.ids()
        for i in range(alignment.size()) :
            for j in range(alignment.length()) :
                weight = values[i,j]
                try :
                    weight = int(weight)
                    res_num = int(pos2ires[i,j]+1)
                except :
                    continue
                if weight != 0 :
                    self.add_feature(ids[i], res_num, res_num, weight, type)
        
