"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Property_Arrays import Structure_Property_Array, Structural_Alignment_Property_Array
from Polyphony.Jalview import JalviewFeatureFileCreator
import numpy
from Bio.PDB.Vector import calc_dihedral

class Phi_Psi_Array(Structure_Property_Array) :
    
    """
    Class to calculate and store backbone phi, psi dihedral angles for a protein chain. 
    """
    
    data_type = float        # data curvature and torsions (kappas and taus)
    data_dim = 2             # 2 dimensional data i.e. kappa,tau per residue
    dim_names = ["phi","psi"]
    data_directory = "phi_psi"   # directory where calculated results are stored
    padding = 0             # number of residues to mask out either side of gaps and at termini
    
    def __init__(self, alignment, alignment_index, update = False) :
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)
        
    def _calculate(self) :
        """
        Calculate phi/psi angles for all residues, where required atoms are available
        """
        blank = (999.9,999.9)
        residues = self.alignment.get_residues(self.pdb_chain_code)
        num_res = len(residues)

        phi_psi_list = []

        for i in range(num_res):
            curr_res = residues[i]
            phi,psi = blank
            if i != 0 :
                try:
                    prev_res = residues[i-1]
                    phi = self._calc_phi(prev_res, curr_res)
                except KeyError, message:
                    print "Missing backbone atoms in residue %s, %d." % (self.pdb_chain_code,curr_res.get_id()[1])
            if i != num_res-1 :
                try:
                    next_res = residues[i+1]
                    psi = self._calc_psi(curr_res, next_res)
                except KeyError, message:
                    print "Missing backbone atoms in residue %s, %d." % (self.pdb_chain_code,curr_res.get_id()[1])
            phi_psi_list.append([phi,psi])
        #phi,psi = blank    
        #phi_psi_list.append([phi,psi])

        array = numpy.ma.array(phi_psi_list)
        array.mask = array == 999.9

        return array
    
    def _calc_phi(self, prev_res, curr_res):
        """
        Calculate phi in degrees
        """
        try :
            CP = prev_res["C"].get_vector()
            N  = curr_res["N"].get_vector()
            CA = curr_res["CA"].get_vector()
            C  = curr_res["C"].get_vector()
            phi = calc_dihedral(CP, N, CA, C)
            phi *= 180.0/3.1415926535
            return phi
        except :
            raise KeyError

    def _calc_psi(self, curr_res, next_res):
        """
        Calculate psi in degrees
        """
        try :
            N  = curr_res["N"].get_vector()
            CA = curr_res["CA"].get_vector()
            C  = curr_res["C"].get_vector()
            NN = next_res["N"].get_vector()
            psi = calc_dihedral(N, CA, C, NN)
            psi *= 180.0/3.1415926535
            return psi
        except :
            raise KeyError
        
class Phi_Psi_Alignment_Array(Structural_Alignment_Property_Array) :
    
    """
    Class for calculating (or reading) phi, psi dihedral angles for the backbones for each protein chain in a given alignment. Does this by creating a Phi_Psi_Array for each chain. 
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> phipsi_array = Phi_Psi_Alignment_Array(aligned, update=False)

    """

    data_directory = "phipsi_arrays"   # directory where calculated results are stored
    
    rama_colours = {}
    rama_colours[0] = 'gray'
    rama_colours[1] = 'blue' # B
    rama_colours[2] = 'green' # P
    rama_colours[3] = 'magenta' # G
    rama_colours[4] = 'cyan' # D
    rama_colours[5] = 'red' # A
    rama_colours[6] = 'orange' # L

    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, Phi_Psi_Array, update)
 
    def calculate_variability(self, missing_value_pc_cutoff=50) :
        """
        Calculate variation per alignment position. Uses method from Hyberts et al., 1992. Protein science : a publication of the Protein Society 1 (6), 736-751. Thanks to Tim Stevens
        for help with implementation. Done by converting each dihedral angle to a unit vector (sin(theta), cos(theta)) and take an average (vectors with the same direction give sum with
        magnitude 1, those with opposite direction have magnitude 0).
        """
        # Sum up sin and cosine of phi and psi separately   
        v0 = numpy.ma.sum(numpy.sin(numpy.radians(self.data)),axis=0)
        v1 = numpy.ma.sum(numpy.cos(numpy.radians(self.data)),axis=0)
        n = self.size - numpy.sum(self.data.mask,axis=0)
        order = numpy.ma.sqrt(v0**2+v1**2)/n

        # Add phi order to psi order take reciprocal to get variation
        variation = 2.0-numpy.sum(order,axis=1)
        
        # Find percentage gaps
        num_gaps = numpy.sum(self.data.mask, axis=0)
        too_many_phi_gaps = 100.0 * num_gaps[:,0] / self.size > missing_value_pc_cutoff 
        too_many_psi_gaps = 100.0 * num_gaps[:,1] / self.size > missing_value_pc_cutoff
        
        # Mask positions with too many gaps
        variation.mask = variation.mask | too_many_psi_gaps | too_many_phi_gaps
        return variation
                
    def calculate_distance_matrix(self, all_mask=False) :
        """
        Calculate distance according to method used in North, B., Lehmann, A., Dunbrack, R. L., Feb. 2011. A new clustering of antibody CDR loop conformations. Journal of Molecular Biology 406 (2), 228-256.
        """
        distmat = numpy.identity(self.size)
        for iseq in range(0, self.size-1 ) :
            i_mask = self.data.mask[iseq].flatten()
            for jseq in range(iseq+1,self.size) :
                j_mask = self.data.mask[jseq].flatten()
                ij_mask = i_mask | j_mask | all_mask
                i_arr = numpy.ma.masked_array(numpy.absolute(self.data.data[iseq].flatten()),ij_mask)
                j_arr = numpy.ma.masked_array(numpy.absolute(self.data.data[jseq].flatten()),ij_mask)
                
                dist = numpy.ma.add.reduce(2*(1 - numpy.cos(numpy.radians(i_arr) - numpy.radians(j_arr))))

                distmat[iseq,jseq] = dist
                distmat[jseq,iseq] = dist
        return distmat
    
    def ramachandran_regions(self, idx=None) :
        """
        Classify each residue by phi/psi combination as defined in North, B.;  Lehmann, A.;  Dunbrack, R. L. Journal of Molecular Biology 2011, 406, 228-256
        """
        if idx==None :
            phis = self.data[:,:,0]
            psis = self.data[:,:,1]
        else :
            phis = self.data[idx,:,0]
            psis = self.data[idx,:,1]

        phi_lt_m100 = numpy.less(phis,-100)
        m100_gt_phi_lt_0 = numpy.less(phis,0) & numpy.greater(phis,-100)
        m0_gt_phi_lt_150 = numpy.greater(phis,0) & numpy.less(phis,150)
        phi_gt_150 = numpy.greater(phis,150)
        phi_gt_0 = numpy.greater(phis,0)

        psi_lt_m100 = numpy.less(psis,-100)
        psi_lt_m50 = numpy.less(psis,-50)
        m100_gt_psi_lt_50 = numpy.less(psis,50) & numpy.greater(psis,-100)
        m50_gt_psi_lt_100 = numpy.less(psis,100) & numpy.greater(psis,-50)
        psi_gt_50 = numpy.greater(psis,50)
        psi_gt_100 = numpy.greater(psis,100)
        
        if idx == None :
            ramachandran_region = numpy.ma.zeros(self.size*self.length,int)
            ramachandran_region.shape = self.size, self.length
        else :
            ramachandran_region = numpy.ma.zeros(self.length,int)            
        
        # A(alpha-helix region), B (beta-sheet region), P (for polyproline II), L (left-handed helix region), D (delta), and G (gamma).
        ramachandran_region[phi_lt_m100 & psi_lt_m100] = 1 # B
        ramachandran_region[m100_gt_phi_lt_0 & psi_lt_m100] = 2 # P
        ramachandran_region[m0_gt_phi_lt_150 & psi_lt_m50] = 3 # G
        ramachandran_region[phi_gt_150 & psi_lt_m50] = 1 # B
        ramachandran_region[phi_lt_m100 & m100_gt_psi_lt_50] = 4 # D
        ramachandran_region[m100_gt_phi_lt_0 & m100_gt_psi_lt_50] = 5 # A
        ramachandran_region[phi_gt_0 & m50_gt_psi_lt_100] = 6 # L
        ramachandran_region[phi_lt_m100 & psi_gt_50] = 1 # B
        ramachandran_region[m100_gt_phi_lt_0 & psi_gt_50] = 2 # P
        ramachandran_region[m0_gt_phi_lt_150 & psi_gt_100] = 3 # G
        ramachandran_region[phi_gt_150 & psi_gt_100] = 1 # B

        # Mask alignment positions where phi or psi was not calculated
        ramachandran_region.mask = phis.mask | psis.mask
        
        return ramachandran_region
        
    def ramachandran_colours(self, idx=None) :
        """
        Produce list of colours for use in matplotlib based upon ramachandran region
        """
        ramachandran_regions = self.ramachandran_regions(idx).data.flatten().tolist()
        colours = [self.rama_colours[i] for i in ramachandran_regions]
        return colours
            
                
    def write_jalview_feature_file(self, filename) :
        """
        Create Jalview feature file for colouring alignment by Ramachandran region.
        """
                
        colours = []
        colours.append("CCCCCC") # grey
        colours.append("00FFFF") # blue
        colours.append("00FF00") # green
        colours.append("FF33FF") # magenta
        colours.append("33FFCC") # cyan
        colours.append("FF0000") # red
        colours.append("FF9933") # orange
        
        names = []
        names.append('0')
        names.append('B')
        names.append('P')
        names.append('G')
        names.append('D')
        names.append('A')
        names.append('L')
        
        # Add one feature type for each region of the Ramachandran plot
        jalfile = JalviewFeatureFileCreator("PhiPsi", "0", colours[0], colours[0], 0, 1)
        for i in range(1,7) :
            jalfile.add_feature_type(names[i], colours[i], colours[i], 0, 1)
        
        # Add one feature for each continuous stretch of residues in the same region
        #
        
        # One region code per residue in the alignment
        values = self.ramachandran_regions()
        
        # Convert from alignment positions to residue index
        res2pos, ires2pos, pos2res, pos2ires = self.alignment._create_residue_indices()
        
        # Structure ids
        ids = self.alignment.ids()
        
        # For each structure
        for i in range(self.alignment.size()) :
            
            # Add one index because alignment positions start at 1
            resids = pos2ires[i]+1
            
            # Find first alignment position with a residue with phi and psi calculated
            idx = 0 
            while resids.mask[idx] or values.mask[i, idx]:
                idx += 1
            start_res = resids[idx]
            last_res = resids[idx]
            last_val = values[i, idx]
            
            # Loop over rest of alignment positions with residues with phi and psi calculated
            for j in range(idx+1, self.alignment.length()) :
                if not resids.mask[j] and not values.mask[i, j]:
                    curr_res = resids[j]
                    curr_val = values[i,j]

                    # If region has changed of gap has occurred then write last stretch as a Jalview feature
                    if curr_res != last_res + 1 or curr_val != last_val :
                        jalfile.add_feature(ids[i], start_res, last_res, 1.0, names[last_val])
                        start_res = curr_res
                    last_res = curr_res
                    last_val = curr_val
                        
            # Write last stretch
            jalfile.add_feature(ids[i], start_res, last_res, 1.0, names[last_val])
        jalfile.write_file(filename)


