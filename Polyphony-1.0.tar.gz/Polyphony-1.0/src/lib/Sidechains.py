"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from Polyphony.Property_Arrays import Structure_Property_Array, Structural_Alignment_Property_Array
from Polyphony.Utils import to_one_letter_code
from Bio.SVDSuperimposer import SVDSuperimposer
from Bio.PDB import calc_dihedral
import numpy, math

class SideChain_Array(Structure_Property_Array) :
    
    """
    Class to calculate (or read) the conformation of each side-chain in a protein chain. Conformation is modelled very simply as the relative position of a sentinel atom near the terminus of each side-chain. Atom types that can be assigned unambiguously in X-ray crystallography are chosen by preference to avoid artifactual differences between structures. In the cases of valine, threonine and histidine where such unambiguous atom types don't exist, the atom type T is chosen (between two ambiguous choices) such that C-CA-CB-T pseudo dihedral angle is positive. 
    """
    
    data_type = float       # data is Calpha b-factor
    data_dim = 3            # 1 dimensional data i.e. 1 value per residue
    dim_names = ["x","y","z"]
    data_directory = "sidechains"     # directory where calculated results are stored
    data_file_extension = ".npy"    # extension of data files
    padding = 0             # number of residues to mask out either side of gaps and at termini
    
    # Terminal atoms (chosen to be unabiguous where possible). # Number of bonds to CB
    sc_terminus = {}
    cs_terminus = {}
    # Residues with ambiguous atoms
    sc_terminus["VAL"] = "CG1" # 1
    cs_terminus["VAL"] = "CG2" # 1
    sc_terminus["THR"] = "OG1" # 1
    cs_terminus["THR"] = "CG2" # 1
    sc_terminus["HIS"] = "NE2" # 3
    cs_terminus["HIS"] = "CE1" # 3
    # Unambiguous atoms
    sc_terminus["ILE"] = "CD1" # 2
    sc_terminus["LEU"] = "CG"  # 1
    sc_terminus["PHE"] = "CZ"  # 4
    sc_terminus["PRO"] = "CG"  # 1
    sc_terminus["MET"] = "CE"  # 3
    sc_terminus["TRP"] = "CH2" # 5
    sc_terminus["CYS"] = "SG"  # 1
    sc_terminus["SER"] = "OG"  # 1
    sc_terminus["ASN"] = "CG"  # 1
    sc_terminus["GLN"] = "CD"  # 2
    sc_terminus["TYR"] = "OH"  # 4
    sc_terminus["ASP"] = "CG"  # 1
    sc_terminus["GLU"] = "CD"  # 2
    sc_terminus["LYS"] = "NZ"  # 4
    sc_terminus["ARG"] = "CZ"  # 4
    sc_terminus["GLY"] = "CA"  # 0
    sc_terminus["ALA"] = "CB"  # 0

    def __init__(self, alignment, alignment_index, update = False) :
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)

    def _calculate_pseudo_dihedral(self, curr_res, terminal_atomtype) :
        """
        Return the C-CA-CB-T pseudo dihedral angle in degrees.
        """
        c = curr_res['C'].get_vector()
        ca = curr_res['CA'].get_vector()
        cb = curr_res['CB'].get_vector()
        t = curr_res[terminal_atomtype].get_vector()
        angle = math.degrees(calc_dihedral(c,ca,cb,t))
        return angle
    
    def _calculate(self) :
        """
        Return masked array containing the relative cartesian coordinates of each side-chain in a protein chain.
        """
        
        # Prepare to find coordinates of side-chain terminal atoms, relative to their backbone
        supsvd=SVDSuperimposer()
                
        # Reference set of backbone coords N,CA,C,CB        
        reference_coords = numpy.array([[-1.22,-0.53,0.61],[0,0,0],[-0.14,0.28,-1.5],[0.48,1.27,0.72]])
        moving_coords = reference_coords.copy()
        blank = [-99.0,-99.0,-99.0]
            
        # Get Bio:PDB residue objects
        residues = self.alignment.get_residues(self.pdb_chain_code)            
        sc_pos_list = []
        for curr_res in residues:
            # Compute side-chain terminal position relative to its backbone
            curr_restype = curr_res.get_resname()
            if not (curr_restype == "GLY" or curr_restype == "ALA" ) :
                # Get backbone and terminal atom coordinates
                try:
                    moving_coords[0] = curr_res["N"].get_coord()
                    moving_coords[1] = curr_res["CA"].get_coord()
                    moving_coords[2] = curr_res["C"].get_coord()
                    moving_coords[3] = curr_res["CB"].get_coord()
                    terminal_coords = curr_res[self.sc_terminus[curr_restype]].get_coord()
                    # Alternative choice for ambiguously assigned atom types
                    if curr_restype == "VAL" or curr_restype == "THR" or curr_restype == "HIS" :
                        terminal_coords2 = curr_res[self.cs_terminus[curr_restype]].get_coord()
                except KeyError, message:
                    print "Missing atoms in residue %s, %d." % (self.pdb_chain_code, curr_res.id[1])
                    sc_pos_list.append(blank)
                    continue
                
                # Superimpose onto reference coordinates
                supsvd.set(reference_coords,moving_coords)
                supsvd.run()
                rot,tran=supsvd.get_rotran()
    
                # Transform coordinates of terminal side chain atom by resulting transformation                    
                side_chain_pos = terminal_coords * numpy.matrix(rot)  + tran
                if curr_restype == "VAL" or curr_restype == "THR" or curr_restype == "HIS" :
                    alt_side_chain_pos = terminal_coords2 * numpy.matrix(rot)  + tran
                    angle = self._calculate_pseudo_dihedral(curr_res, self.sc_terminus[curr_restype])
                    if angle < 0 :
                        side_chain_pos = alt_side_chain_pos

                # Store resulting coordinates (first convert from numpy matrix to list)
                sc_pos_list.append(side_chain_pos.tolist()[0])
            else :
                sc_pos_list.append(blank)
                
                #
        sc_array = numpy.ma.zeros(len(residues)*3)
        sc_array.shape = len(residues),3
        sc_array.mask = False

        for i in range(len(residues)) :
            if sc_pos_list[i] != blank :
                sc_array[i] = sc_pos_list[i]
            else :
                sc_array.mask[i] = True

        return sc_array

class SideChain_Alignment_Array(Structural_Alignment_Property_Array) :
    
    """
    Class for calculating (or reading) side-chain conformations for each protein chain in a given alignment. Does this by creating a SideChain_Array for each chain. 
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> sidechain_array = SideChain_Alignment_Array(aligned, update=False)

    """

    data_directory = "sidechain_arrays"   # directory where calculated results are stored
    data_file_extension = ".npy"           # extension of data files
    sc_terminus = SideChain_Array.sc_terminus
    cs_terminus = SideChain_Array.cs_terminus

    
    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, SideChain_Array, update)    

    def calculate_distance_matrix(self) :
        """
        Calculate distance matrix using Euclidean distance.
        """
        #if not type(all_mask) == bool :
        #    all_mask = self._expand_array(all_mask)
        #return self.calculate_Euclidean_distance_matrix(all_mask)
        return self.calculate_Euclidean_distance_matrix()
        
    def rmsf(self, reference_id=None) :
        """
        Calculate root mean squared fluctuation about the representative structure..
        """
        print "Calculating side-chain RMSF"
        if reference_id == None :
            reference_id = self.alignment.get_representative_structure()

        ref_idx = self.alignment.index_from_id(reference_id)
        diff = self.data - self.data[ref_idx]
        rmsfs = numpy.ma.average(numpy.ma.sqrt(numpy.ma.sum(diff*diff,axis=2)),axis=0)
        return rmsfs
    
    def rmsd(self, reference_id=None) :
        """
        Calculate root mean squared deviation from the representative structure.
        """
        print "Calculating side-chain RMSD"
        if reference_id == None :
            reference_id = self.alignment.get_representative_structure()

        ref_idx = self.alignment.index_from_id(reference_id)
        diff = self.data - self.data[ref_idx]
        rmsds = numpy.ma.average(numpy.ma.sqrt(numpy.ma.sum(diff*diff,axis=2)),axis=1)
        return rmsds

    def get_spherical_coords(self) :
        """
        Convert from Cartesian to spherical coordinates (from stackoverflow)
        """
        xyz = self.data
        ptsnew = numpy.ma.zeros(xyz.shape)
        ptsnew.mask = xyz.mask
        xy = xyz[:,0]**2 + xyz[:,1]**2
        ptsnew[:,0] = numpy.ma.sqrt(xy + xyz[:,2]**2)
        ptsnew[:,1] = numpy.ma.arctan2(numpy.sqrt(xy), xyz[:,2]) # for elevation angle defined from Z-axis down
        #ptsnew[:,4] = np.arctan2(xyz[:,2], np.sqrt(xy)) # for elevation angle defined from XY-plane up
        ptsnew[:,2] = numpy.ma.arctan2(xyz[:,1], xyz[:,0])
        return ptsnew
    
    def get_theta(self) :
        """
        Convert from Cartesian to spherical coordinates (from stackoverflow) theta (elevation)
        """
        xyz = self.data
        xy = xyz[:,:,0]**2 + xyz[:,:,1]**2
        theta_array = numpy.ma.arctan2(numpy.sqrt(xy), xyz[:,:,2]) # for elevation angle defined from Z-axis down
        return theta_array
          
    def reduce(self) :
        """
        Return reduced version of data in a 2d array, use spherical coordinates theta (elevation)
        """
        return self.get_theta()

    def write_jalview_feature_file(self, filename) :
        """
        Create Jalview feature file for highlighting extremes of backbone conformation sequence alignment viewer.
        """
                
        self.make_jalview_feature_file(filename, "Conformation", "Sidechain", "00FF00", "008800", 1.5, 2.5)

 