"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Property_Arrays import Structure_Property_Array, Structural_Alignment_Property_Array
from Polyphony.Utils import reduce, to_one_letter_code
import os, stat, re, numpy, math
import scipy.interpolate as interpolate
import scipy.linalg as linalg


class Kappa_Tau_Array(Structure_Property_Array) :
    """
    Class for calculating (or reading) curvature and torsion (or kappa and tau) values for the backbone of a given protein. Normally only used by Kappa_Tau_Alignment_Array objects to process all protein chains in an alignment in one go. They are calculated by fitting a spline to the calpha atoms. Termini and chain breaks can result in unstable splines so curvature torsion values are either not calculated or masked for the two residues at each terminus or either side of chain break.
    """
    
    data_type = float        # data curvature and torsions (kappas and taus)
    data_dim = 2             # 2 dimensional data i.e. kappa,tau per residue
    dim_names = ["curvature","torsion"]
    data_directory = "kappa_taus"   # directory where calculated results are stored
    padding = 2             # number of residues to mask out either side of gaps and at termini
    
    def __init__(self, alignment, alignment_index, update = False) :
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)
        
    def _calculate(self) :
        """
        Fit spline to calpha atoms and calculate curvature (kappa) and torsion (tau) of the spline at each calpha position. Guts written by Rinaldo Montalvao
        """
        # Compute the curvature and torsion
        
        kappa_tau_list = []
        residues = self.alignment.get_residues(self.pdb_chain_code)            

        # Get sequence from alignment

        indx = []
        x = [] # c-alpha coordinates
        y = []
        z = []
        res_num = []
        missing_ca = []
        
        # Get all the c-alpha coordinates
        for i in range(len(residues)):
            res = residues[i]
            try:
                ca_coord = res["CA"].get_coord()
                x.append(ca_coord[0])
                y.append(ca_coord[1])
                z.append(ca_coord[2])
                indx.append(i)
                res_num.append(res.id[1])
                missing_ca.append(False)
            except KeyError:
                print "CA missing",res,self.pdb_chain_code      
                missing_ca.append(True)
        
        # Fit spline to calphas

        # Spline interpolation of the C-alpha curve
        tckx = interpolate.splrep(indx,x,k=3,s=0.0)
        tcky = interpolate.splrep(indx,y,k=3,s=0.0)
        tckz = interpolate.splrep(indx,z,k=3,s=0.0)
        
        # Value of the curve at the indx points
        xd0 = interpolate.splev(indx,tckx,der=0)
        yd0 = interpolate.splev(indx,tcky,der=0)
        zd0 = interpolate.splev(indx,tckz,der=0)
        
        # First derivative of the curve at the indx points
        xd1 = interpolate.splev(indx,tckx,der=1)
        yd1 = interpolate.splev(indx,tcky,der=1)
        zd1 = interpolate.splev(indx,tckz,der=1)
        
        # Second derivative of the curve at the indx points
        xd2 = interpolate.splev(indx,tckx,der=2)
        yd2 = interpolate.splev(indx,tcky,der=2)
        zd2 = interpolate.splev(indx,tckz,der=2)

        # Third derivative of the curve at the indx points
        xd3 = interpolate.splev(indx,tckx,der=3)
        yd3 = interpolate.splev(indx,tcky,der=3)
        zd3 = interpolate.splev(indx,tckz,der=3)
                        
        
        # Compute kappa and tau at calpha positions along sline and put in a list
        #

        # values for termini cannot be determined
        blank = [-99,-99]
        kt_list = []
        kt_list.append(blank)
        for i in range(1,len(indx)-1):

            # Compute the curvature 
            v1 = numpy.array([xd1[i],yd1[i],zd1[i]])
            v2 = numpy.array([xd2[i],yd2[i],zd2[i]])
            v1_x_v2 = numpy.array([v1[1]*v2[2]-v1[2]*v2[1], v1[2]*v2[0]-v1[0]*v2[2], v1[0]*v2[1]-v1[1]*v2[0]])
            r1 = numpy.dot(v1_x_v2,v1_x_v2)
            r2 = numpy.dot(v1,v1)
            unsigned_kappa = numpy.sqrt(r1)/(numpy.sqrt(r2)**3)

            # Compute the torsion
            M  = numpy.array([[xd1[i], xd2[i], xd3[i]],
                              [yd1[i], yd2[i], yd3[i]],
                              [zd1[i], zd2[i], zd3[i]]])
            det = linalg.det(M)
            tau  = det/r1
            kt_list.append([unsigned_kappa, tau])
        kt_list.append(blank)
        
        # Create masked array of kappa, tau values, one pair of values per residue with missing values masked.
        #
        kt_array = numpy.ma.zeros(len(residues)*2)
        kt_array.shape = len(residues),2
        kt_array.mask = False
        
        # Get chain breaks (non sequential residue numbers) and erase kt values either side of break
        #
        residue_array = self.alignment._get_unaligned_residues(self.pdb_chain_code)
        breaks = residue_array.find_discontinuous_residues()
        for ires in breaks :
            kt_list[ires] = blank
            kt_list[ires-1] = blank
        
        list_idx = 0
        for i in range(len(residues)):
            if not missing_ca[i] :
                if kt_list[list_idx] != blank :
                    kt_array[i] = kt_list[list_idx]
                else :
                    kt_array.mask[i] = True
                list_idx += 1
            else :
                kt_array.mask[i] = True

        return kt_array
        
class Kappa_Tau_Alignment_Array(Structural_Alignment_Property_Array) :
    
    """
    Class for calculating (or reading) curvature and torsion values for the backbones for each protein chain in a given alignment. Does this by creating a Kappa_Tau_Array for each chain. Values are normalised by dividing by the alignment wide standard deviations and capped at +/- 3.0. This is to ensure that the two descriptors are on the same scale and outlier values that might have unduely effected distance calculations using the Pearson metric are suppressed.
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> kt_array = Kappa_Tau_Alignment_Array(aligned, update=False)

    """

    data_directory = "kt_arrays"   # directory where calculated results are stored

    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, Kappa_Tau_Array, update)
    
    def calculate_distance_matrix(self, missing_value_cut_off=10, weights=[]) :
        """
        Calculate distance matrix using Pearson distance metric. If weights are specified then a weighted distance is calculated. This is much much slower.        

        Parameters
        ----------
    
        missing_value_cutoff : int
            percentage of rows which are masked (gaps) before a column is ignored. Range 0 - 100
    
        weights : 1d numpy array
            real value weights, one per residue position in alignment

        """
        #if not type(all_mask) == bool :
        #    all_mask = self._expand_array(all_mask)
        if len(weights) == 0 :
            #return self.calculate_Spearman_distance_matrix()calculate_Pearson_distance_matrix
            return self.calculate_Pearson_distance_matrix()
        else :
            return self.calculate_weighted_Pearson_distance_matrix(weights)
        
    def normalise(self) :
        """
        Normalise curvature and torsion by dividing by their standard deviations. Curvatures are capped at +3 standard devs from mean. Torsions are capped at +3.0 and -3.0 sds from mean. 
        """
        
        # Calculate average and standard deviation curvature for all residues in all proteins,
        # ignoring masked regions (gaps etc.) 
        kappa_mean = numpy.ma.average(self.data[:,:,0])
        kappa_standard_dev = numpy.ma.std(self.data[:,:,0])

        # Normalise by dividing by sd and capping any values above 3 sd's above mean
        self.data[:,:,0] /= kappa_standard_dev
        kappa_cutoff = kappa_mean/kappa_standard_dev + 3.0
        numpy.putmask(self.data[:,:,0],self.data[:,:,0] > kappa_cutoff, kappa_cutoff)

        # Same for torsion with the difference that torsion have +ve and -ve values
        tau_mean = numpy.ma.average(self.data[:,:,1])
        tau_standard_dev = numpy.ma.std(self.data[:,:,1])
        upper_tau_cutoff = tau_mean/tau_standard_dev + 3.0
        lower_tau_cutoff = tau_mean/tau_standard_dev - 3.0
        self.data[:,:,1] /= tau_standard_dev
        numpy.putmask(self.data[:,:,1], self.data[:,:,1] > upper_tau_cutoff, upper_tau_cutoff)
        numpy.putmask(self.data[:,:,1], self.data[:,:,1] < lower_tau_cutoff, lower_tau_cutoff)

    def reduce(self) :
        """
        Return reduced version of data in a 2d array, with max absolute kappa, tau per residue. Bit of a cludge.
        """
        return reduce(self.data, method="max_abs")

    def write_jalview_feature_file(self, filename) :
        """
        Create Jalview feature file for highlighting extremes of backbone conformation sequence alignment viewer.
        """
                
        self.make_jalview_feature_file(filename, "Conformation", "KappaTau", "00FF00", "008800", 1.5, 2.5)

 