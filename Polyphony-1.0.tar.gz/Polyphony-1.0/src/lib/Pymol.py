"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Initial import CONFIG
from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Comparison_Matrices import Residue_Matrix, Structure_Matrix
from Polyphony.Backbone import Kappa_Tau_Alignment_Array
from Polyphony.Residues import Residue_Alignment_Array
from Polyphony.Trees import Tree
from Polyphony.Utils import Properties, ids_from_id, reduce

import colorsys, xmlrpclib, numpy, os, math
from collections import defaultdict

class PyMOLViewer(object):
    '''
    Class for controlling a pymol session using python commands. Uses xmlrpclib. To use pymol must be started with the -R option and (preferably) a ipython session started in another command window. 
    '''
    backbone = "(name N or name CA or name C or name O)" # pymol backbone selection 
    sidechain = "not (name N or name C or name O or name CA)" # sidechains only
    calpha = "name CA" # Calphas only
    #allatoms = "name *" # All atoms
    
    def __init__(self,host='localhost',port=9123):
        self.srv = xmlrpclib.Server('http://%s:%s' % (host,port))
        
    def load(self, filename, objName) :
        """
        load a molecule file and give the object the given name.
        """
        self.srv.loadFile(filename, objName)
        
    def save(self, filename, objName) :
        """
        save a molecule to a pdb file
        """
        self.srv.save(filename, objName)

    def delete(self, objName) :
        """ delete a pymol object """
        self.srv.do("delete %s" % objName)
        
    def select(self, selection, name) :
        """ make a selection and give it a name"""
        self.srv.do("select %s, %s, 0" % (name,selection))
        
    def cylinder(self,xyz0,xyz1,radius,colour,name) :
        """
        create a cylinder from xyz0 to xyz1, with given radius, colour and name.
        
        Examples
        --------

        >>>
        >>> xyz0 = [132.0, 89.8, 22.0]
        >>> xyz1 = [124.9, 101.3, 4.5]
        >>> self._pymol.cylinder(xyz0,xyz1,0.3,[1,0,0],"cyl1") # red cylinder

        """
        self.srv.cylinder(xyz0,xyz1,radius,colour,name)
        
    def distance(self, atom1, atom2, name) :
        """
        Show distance between two atoms
        """
        self.srv.do("distance %s, %s, %s" % (name, atom1, atom2))
    
    def angle(self, atom1, atom2, atom3, name) :
        """
        Show angle between three atoms
        """
        self.srv.do("angle %s, %s, %s, %s" % (name, atom1, atom2, atom3))
    
    def dihedral(self, atom1, atom2, atom3, atom4, name) :
        """
        Show dihedral angle between 4 atoms
        """
        self.srv.do("dihedral %s, %s, %s, %s, %s" % (name, atom1, atom2, atom3, atom4))
    
    def hide_labels(self, name) :
        """
        Hide labels with given name
        """
        self.srv.do("hide labels, %s" % (name))
        
    def colour(self, name, colour) :
        """
        Colour a selection
        """
        self.srv.do("color %s, %s" % (colour, name))        
        
    def showSphere(self, selection, scale) :
        """ Show a sphere on the selected atoms with given scale. """
        self.srv.do("show spheres, (%s)" % (selection))
        self.srv.do("set sphere_scale, %s, (%s)" % (str(scale),selection))

    def get_coords(self, objName, resNum, atomName) :
        """ Return the coordinates of a given atom. """
        return self.srv.getAtomCoords("(%s and resi %s and name %s)"%(objName,str(resNum),atomName))
        
    def num_selected_atoms(self, selection) :
        """ Return a count of the number of atoms in a given selection"""
        try :
            return self.srv.countAtoms(selection)
        except :
            return 0
    
    def set_bfactor(self, selection, value) :
        """ Set the b-factor of the atoms in the given selection to the given value."""
        self.srv.do("alter %s, b = %s" % (selection,str(value)))

    def set_all_bfactors(self, objName, atomSelection, value=0.0) :
        """same as set_bfactor!"""
        self.srv.do("alter %s and %s, b = %s" % (objName,atomSelection,str(value)))

    def atomNameList_to_selection(self,list) :
        """ Convert a list of atom names to a selection """
        select = "("
        for i in list :
            select += "name "+i+" or "
        select = select[:-4]+")"
        return select
            
    def create_residue_selection(self, resnum_list, name) :
        """
        turn a list of residue numbers into a pymol residue selection.
        """
        
        # Convert contiguous residue numbers to ranges
        num_res = len(resnum_list)
        if num_res < 2 :
            selection = "(resi "+str(resnum_list[0])+" )"
        selection = "("
        last_res = resnum_list[0]
        new_range = True
        for resi in range(1,num_res) :
            curr_res = resnum_list[resi]
            if curr_res == last_res + 1 :
                if new_range :
                    selection += "resi " + str(last_res) + "-"
                    new_range = False
            else :
                if new_range :
                    selection += "resi " + str(last_res) + " or "
                else :
                    selection += str(last_res) + " or "
                    new_range = True
            last_res = curr_res
        if new_range == False :
            selection += str(last_res)
        else :
            selection += "resi "+str(last_res)
        selection+= ")"
        
        # If selection is too large, build up in blocks
        #if len(selection) > 500 :
        #    selection_array = selection.split(" or resi ")
        #    selection_array[0] = selection_array[0][6:] # strip of initial "(resi "
        #    selection_array[-1] = selection_array[-1][:-2] # strip of final ")"
        #    
        #    self.create_selection(name, "none")
        #    for block in range(int(math.ceil(len(selection_array)/50.0))) :
        #        sub_selection = name + " or (resi "+" or resi ".join(selection_array[block*50:min(block*50+50,len(selection_array))])+")"
        #        self.create_selection(name, sub_selection)
        #else :
        #    self.create_selection(name, selection)
        if len(selection) > 500 :
            print "selection"
            print selection
            selection_array = selection.split(" or resi ")
            print "selection array"
            print selection_array
            selection_array[0] = selection_array[0][6:] # strip of initial "(resi "
            selection_array[-1] = selection_array[-1][:-1] # strip of final ")"
            print "selection array"
            print selection_array            
            self.create_selection(name, "none")
            for block in range(int(math.ceil(len(selection_array)/50.0))) :
                sub_selection = name + " or (resi "+" or resi ".join(selection_array[block*50:min(block*50+50,len(selection_array))])+")"
                print "sub_selection"
                print sub_selection
                self.create_selection(name, sub_selection)
        else :
            self.create_selection(name, selection)
        
    def hide_everything(self, objName) :
        """ Hide everything in given object """
        self.srv.do("hide everything, %s" % (objName))
        
    def show_ribbon(self, objName) :
        """ Show ribbon for given object """
        self.srv.do("show ribbon, %s" % (objName))

    def hide_ribbon(self, selection) :
        """ Hide ribbon for given selection """        
        self.srv.do("hide ribbon, %s" % (selection))
        
    def show_sticks(self, selection) :
        """ Show sticks for given selection """
        self.srv.do("show sticks, %s" % selection)

    def show_surface(self, objName) :
        """ Show surface for given obbject """
        self.srv.do("show surface, %s" % (objName))
        
    def show_cartoon(self, objName, type = None) :
        """ Show cartoon of given type e.g. "putty" or "auto" (default). """
        if type != None :
            self.srv.do("cartoon %s" % (type))
        self.srv.do("show cartoon, %s" % (objName))

    def show_lines(self, objSel) :
        """ Show lines for given selection """
        self.srv.do("show lines, %s" % (objSel))
        
    def colour_by_bfactor(self, objName, spectrum="rainbow", min=None, max=None) :
        """ Colour object by b-factors, using given spectrum. """
        if min == None :
            self.srv.do("spectrum b, %s, %s" % (spectrum, objName))
        else :
            self.srv.do("spectrum b, %s, %s, %s, %s" % (spectrum, objName, min, max))
        
    def colour_atoms(self, selection, colour) :
        """ Colour atom selection a given colour e.g. colour_atoms(selection, "gray50") """
        self.srv.do("color %s, %s" % (colour, selection))
        
    def zoom(self, selection) :
        """ Zoom in on selection. """
        self.srv.do("zoom %s" % selection)

    def reinitialize(self) :
        """ Reinitialize pymol session. """
        self.srv.do("reinitialize")
        
    def align(self, mobileSel, targetSel, cycles="2") :
        """ Align mobileSel to targetSel using the align command."""
        self.srv.do("align (%s), (%s), cycles=%s" % (mobileSel, targetSel, cycles))
        self.intra_fit(mobileSel)

    def super(self, mobileSel, targetSel) :
        """ Align mobileSel to targetSel using the super command."""
        self.srv.do("super (%s), (%s)" % (mobileSel, targetSel))
        self.intra_fit(mobileSel)
        
    def pair_fit(self, mobileSel, targetSel) :
        """ Align mobileSel to targetSel using the pair_fit command. In this case the selections must contain the same number of atoms."""
        self.srv.do("pair_fit (%s), (%s)" % (mobileSel, targetSel))
        self.intra_fit(mobileSel)

    def cealign(self, mobileSel, targetSel) :
        """
        Structure only alignment of mobileSel to targetSel using the cealign command. Needs cealign (http://www.pymolwiki.org/index.php/Cealign) plugin to be preinstalled.
        """
        self.srv.do("cealign (%s), (%s)" % (targetSel, mobileSel))
        self.intra_fit(mobileSel)
        
    def intra_fit(self, objSel) :
        """
        Intrafit a multiframe object to the first frame
        """
        self.srv.do("intra_fit %s" % objSel)
        
    def group(self, group, objSel) :
        """ Create or append object to a group """
        self.srv.do("group %s, %s" % (group, objSel))

    def label(self, selection, label) :
        """ Label selection with string label """
        self.srv.do("label %s, \"%s\"" % (selection, label))
    
    def create_selection(self, name, sel) :
        """ Create a named selection in pymol """
        self.srv.do("select %s, %s" % (name, sel))
        
    def make_gradient(self, name, nbins):
        """
        function for creating a blue to red gradient
        adapted from --- COLORAMA: Coloring Widget for PyMOL ---  Author  : Gregor Hagelueken
        """
        hsvcolorstart = colorsys.rgb_to_hsv(0.0, 0.0, 1.0) # blue
        hs=hsvcolorstart[0]
        ss=hsvcolorstart[1]
        vs=hsvcolorstart[2]
        hsvcolorend = colorsys.rgb_to_hsv(1.0, 0.01, 0.01) # red 
        he=hsvcolorend[0]
        se=hsvcolorend[1]
        ve=hsvcolorend[2]
    
        for j in range(nbins):
            hsv = (hs - (hs-he) * float(j) / (nbins-1), ss-(ss-se)*float(j)/(nbins-1), vs-(vs-ve)*float(j)/(nbins-1) )
            #convert to rgb and append to color list
            rgb = colorsys.hsv_to_rgb(hsv[0],hsv[1],hsv[2])
            self.srv.do("set_color %s, %s" % (name + str(j), str(rgb)))

    def duplicate_object(self, old_obj, new_obj) :
        """
        copy Pymol object
        """
        self.srv.do("copy %s, %s" % (new_obj, old_obj))
        
    def ungroup(self, obj) :
        """
        Ungroup object
        """
        self.srv.do("ungroup %s" % (obj))
        
    def rename(self, oldname, newname) :
        """
        rename object
        """
        self.srv.do("set_name %s, %s" % (oldname, newname))
        

class Pymol_Viz(object) :

    """
    Class to support the visualisation of Polyphony analysis results on 3D structures in pymol. Preferably properties have already been calculated for this alignment, making the session more interactive. Calculated properties will not be updated if precalculated values are available.

    Parameters
    ----------
    filename : string
        filename containing a fasta alignment. Preferably properties have already been calculated for this alignment thus making the session more interactive.

    label : string
        name of group to contain objects associated with this alignment analysis. The ungroup command can be used at a later stage to remove objects from this group.
        
    chain_id : string
        optional chain to use as the representative stucture. Format is pdbcode_chainletter e.g. "2IW8_A". If none is provided, one will be chosen automatically. 

    Examples
    --------
    
    >>>
    >>> from Polyphony.Pymol import Pymol_Viz
    >>> family_x = Pymol_Viz("my-alignment.fasta", "family_x")
    """
    
    def __init__(self, filename, label, chain_id = None) :
        self._name = filename.split("/")[-1].split(".")[0]
        print "Creating alignment"
        self._aligned = Structural_Alignment()
        self._aligned.add_alignment(filename)
        print "Creating indices"
        self.res2pos,self.ires2pos,self.pos2res,self.pos2ires = self._aligned._create_residue_indices()
        print "Getting representative structure"
        self._group = label
        if chain_id == None :
            self._representative = self._aligned.get_representative_structure()
        else :
            self._representative = chain_id
            
        self._pdb_id, self._model_no, self._chain_id = ids_from_id(self._representative, blank_chain_null=True)

        if self._chain_id == '' :
            self._selection = self._representative
        else :
            self._selection = self._representative+" and chain "+self._chain_id
        print "Creating pymol viewer"
        self._pymol = PyMOLViewer()
        try :
            self._load_representative_structure()
        except Exception, e:
            print
            print e
            raise RuntimeError("\n!!! You must start PyMol with pymol -R in a separate window first.")
        self._loaded_structures = set([self._representative])
        self.num_colour_bins = 50 # number of individual colours in gradient
        print "finished"
        
    def _get_selection(self, chain_id = None) :
        """
        Check the selected chain is present in pymol session. Default is the representative structure for this alignment
        """
        if chain_id == None :
            objSel = self._selection
            objIndx = self._aligned.index_from_id(self._representative)
            if self._pymol.num_selected_atoms(objSel) == 0 :
                self._load_representative_structure()
            if self._pymol.num_selected_atoms(objSel) == 0 :
                raise RuntimeError("!!! Problems loading representative structure")
        else :
            pdb_code, model_no, chain_letter = ids_from_id(chain_id, blank_chain_null=True)
            if chain_letter != '' :
                objSel = chain_id + " and chain " + chain_letter                
            objIndx = self._aligned.index_from_id(chain_id)
            if self._pymol.num_selected_atoms(objSel) == 0 :
                self.load_structures(id_list=[chain_id])
            if self._pymol.num_selected_atoms(objSel) == 0 :
                print "! Problems loading structure ",chain_id," . Selected chain_id should be form pdbcode_chainletter e.g. 1P38_A  or 1P38_1_A for multimodel pdb."
                return None, None
        return objSel, objIndx
        
    def _value_per_position(self, property, function, groups=None, **kwargs) :
        """
        Calculate a summary statistic, one per alignment position
            property = "bfactor"              : can try any property name of those defined in polyphony.cfg
            function = "average_per_residue"  : any function that can be calculated on "property" and that produces one number per residue.
            groups = None                     : use a defined subset of structures as a list of index numbers, or a list of lists to group structures into sets
        """

        # Get/calculate selected property
        properties = Properties()
        array = properties.get_array(property, self._aligned)
                
        # Optional subset of structures
        if groups != None and type(groups[0]) != list:
            array = array.subset(groups)

        # Calculate values
        
        # restrict functions to those belonging to array object (not sure this needed but unrestricted use of eval is said to be potentially dangerous)
        funcs = {}
        funcs["array"] = array
        call = "array."+function
        
        # evaluate function
        if type(groups) == list and type(groups[0]) == list :
            values = eval(call,{"__builtins__":None},funcs)(groups, **kwargs)
        else :
            values = eval(call,{"__builtins__":None},funcs)(**kwargs)
            
        return values
   
    def _colour_residues(self, values, set_bfactors=False, selection="backbone", bin_size=None, min_value=None, rmax=0, chain_id=None) :
        """
        Colour the backbone by the average property value per alignment position.
            rmax = 0                : if rmax is set to x, then the x largest values are coloured red.
            set_bfactors = False    : is set True then the bfactors of the selected pymol object are set to the calculated values and a putty cartoon is displayed as well as the colour coding
            selection = "backbone"  : part of each residue to colour = "backbone"|"sidechain"|"allatoms"
            chain_id = None         : optional specification of the pymol object to use must be same format as the alignment identifiers e.g. "1P38_A"
        """

        # Select pymol object to colour
        objSel, objIndx = self._get_selection(chain_id)
        if not objSel : return

        # Colour backbone with binned colours or set bfactors with binned values and colour by bfactor
        if selection == "backbone" :
            selection = objSel + " and " + PyMOLViewer.backbone
        elif selection == "sidechain" :
            selection = objSel + " and " + PyMOLViewer.sidechain
        elif selection == "allatoms" :
            selection = objSel 
        else :
            print "Invalid selection. Must = \"backbone\"|\"sidechain\"|\"allatoms\""
            raise ValueError
            
        if set_bfactors == False :
            self.__colour_with_bins(values, selection, objIndx, bin_size, min_value, rmax)
            #self._pymol.show_cartoon(objSel, type = "automatic")
        else :
            res_in_bins = self.__set_bfactors_with_bins(values, selection, objSel, objIndx, bin_size, min_value, rmax)
            # Recolour to colour masked residues and those not in the alignment grey
            self.__colour_with_bins(values, selection, objIndx, bin_size, min_value, rmax)
    
    def __calculate_min_and_bin_size(self, values) :
        """
        Calculate minimum and bin size for an array of values given a defined number of bins
        """
        min_value = numpy.ma.min(values)
        rang = numpy.ma.max(values) - min_value
        bin_size = rang/self.num_colour_bins
        return min_value, bin_size

    def __create_bins(self, values, bin_size=None, min_value=None, rmax=0) :
        """
        Create bins to cover given values (a numpy array). The rmax parameter can used to ignore rmax largest values.
        """

        # Start from zero
        if min_value == None :
            min_value = numpy.ma.min(values)
        values -= min_value
        
        # Scale so values can be represented as integers
        max_value = numpy.ma.max(values)
        values *= 100.0 / max_value 

        # Calculate bin size depending on range
        if bin_size == None :
            sorted = numpy.unique(values)
            if type(sorted) == numpy.ma.core.MaskedArray :
                sorted = sorted.compressed()
            if len(sorted) > 1 :
                rang = sorted[-1-rmax] - sorted[0]
                bin_size = rang/self.num_colour_bins
            elif len(sorted) == 1 :
                bin_size = sorted[0]
            else :
                return []

        # remove extreme values
        if rmax > 0 :
            numpy.putmask(values,values>=sorted[-rmax], sorted[-rmax-1]) # high values
        
        values_binned = numpy.ma.round(values/bin_size).astype(int)
        numpy.putmask(values_binned.data, values_binned<0.0,0.0)
        numpy.putmask(values_binned.data, values_binned>self.num_colour_bins,self.num_colour_bins)
        
        return values_binned, bin_size

    def __assign_res_to_bin(self, objIndx, bins) :
        """
        Group together all residues that have the same bin
        """
        
        # Assign each residue a colour bin
        res_in_bin = defaultdict(list)
        
        # set masked values to -1
        bins_with_minus1 = bins
        #if type(bins_with_minus1) == numpy.ndarray :
        #    bins_with_minus1.data[bins_with_minus1.mask] = -1
        bins_with_minus1.data[bins_with_minus1.mask] = -1
            
        for i in range(self._aligned.length()) :
            ires = self.get_residue_number(objIndx, i)
            if ires != None :
                res_in_bin[bins_with_minus1.data[i]].append(ires)
            else :
                print "alignment position ",i," has no recognised residue in selected structure."
        return res_in_bin
        
    def __colour_with_bins(self, values, selection, objIndx, bin_size=None, min_value=None, rmax=0) :
        """
        Colour residues using provided colour bin array.
        """
        
        # Create colour gradient to match
        resbins, bin_size = self.__create_bins(values, bin_size, min_value, rmax)
        if len(resbins) == 0 :
            return
        self._pymol.make_gradient("blue_red", self.num_colour_bins+1)
        
        # Group together all residues that has same binned values
        res_in_bins = self.__assign_res_to_bin(objIndx, resbins)

        # Colour pymol object one bin at a time (much quicker than one residue at a time)
        self._pymol.colour_atoms(selection, "gray50")
        for bin in res_in_bins :
            if bin != -1 :
                colour = "blue_red"+str(bin)
                self._pymol.create_residue_selection(res_in_bins[bin], "res_sel")
                self._pymol.colour_atoms(selection+" and res_sel", colour)

    def __set_bfactors_with_bins(self, values, selection, objSel, objIndx, bin_size=None, min_value=None, rmax=0) :
        """
        Set bfactor of selected atoms with provided values
        """
        
        # Bin values
        resbins, bin_size = self.__create_bins(values, bin_size, min_value, rmax)
        if len(resbins) == 0 :
            return
        # Group together all residues that have the same binned values
        res_in_bins = self.__assign_res_to_bin(objIndx, resbins)
                   
        # Set bfactors in pymol object, one bin at a time (much quicker than one residue at a time)
        self._pymol.set_bfactor(selection, 100.0) # default bfactor is maximum (red)
        for bin in res_in_bins :
            if bin != -1 : # masked values
                self._pymol.create_residue_selection(res_in_bins[bin], "res_sel")
                self._pymol.set_bfactor(selection+" and res_sel", bin * bin_size)

        self._pymol.colour_by_bfactor(selection)
        self._pymol.show_cartoon(selection, type = "putty")
        self._pymol.hide_ribbon(selection)

        return res_in_bins
                
    def _load_representative_structure(self) :
        """
        Load the representative structure
        """
        pdb_file = CONFIG.get('directories','data')+"pdbs/"+self._pdb_id+".pdb"
       
        # load overall representative structure
        self._pymol.delete(self._representative)            
        self._pymol.load(pdb_file,self._representative)
        self._pymol.zoom(self._selection)
        self._pymol.group(self._group,self._representative)
        self._pymol.select(self._selection,"representative")

    def reinitialize(self) :
        """ Reinitialize pymol session, deleting all objects."""
        self._pymol.reinitialize()
    
    def identify_cluster_reps(self, num_clusters, method="backbone") :
        """
        Cluster structures and return longest structure in each cluster. Number of clusters required must
        be specified. Clustering can be done by backbone conformation (method="backbone") or by precentage sequence identity (method="sequence") 
        """
        if method == "backbone" :
            array = Kappa_Tau_Alignment_Array(self._aligned)
        elif method == "sequence" :
            array = Residue_Alignment_Array(self._aligned)
        else :
            print "! method must by either backbone or sequence"
            return
        structmat = Structure_Matrix(array)
        tree = Tree(structmat.data, structmat.get_labels())
        clusters = tree.cut(num_clusters)
        ids = []
        for cluster_index_list in clusters :
            ids.append(self._aligned.get_representative_structure(indices=cluster_index_list))
        return ids
    
    def get_representative_structure(self, groups) :
        """
        Return the id of the representative structure from a list or list of lists of structure indices. 
        """
        if type(groups[0]) == list :
            groups = sum(groups,[])
        return self._aligned.get_representative_structure(indices=groups)
            
    def copy_object(self, new_object_name, chain_id=None) :
        """
        Create copy of an object to preserve its visualisation state. Representative object is copy by default.
        """
        # Select pymol object to use as a representative
        if chain_id == None :
            self._pymol.duplicate_object(self._representative, new_object_name)
        else :
            self._pymol.duplicate_object(chain_id, new_object_name)
            
    def ungroup_object(self, object_name) :
        """
        Ungroup object, for instance so that it can be viewed in grid mode.
        """
        self._pymol.ungroup(object_name)
        
    def rename_object(self, old_name, new_name) :
        """
        Rename a pymol object
        """
        self._pymol.rename(old_name, new_name)

    def get_conserved_segments(self, conservation_threshold=0.3, chain_id=None) :
        """
        Return list of alignment position segments in which backbone conformation is conserved. A segment is defined by two numbers, the alignment positions at the start and end of the segment.
        These can be used for superimposition. Lower the conservation_threshold to increase number of residue positions considered to be conserved down to a lower limit of 0.
        """
        if conservation_threshold < 0.0 :
            conservation_threshold = 0.0

        # Find largest conserved segment to do alignment
        kt_array = Kappa_Tau_Alignment_Array(self._aligned, update=False)
        segments = kt_array.find_conserved_segments(threshold=conservation_threshold)
        if len(segments) == 0 :
            print "No segments found at conservation_threshold=", str(conservation_threshold)
            print "Try a higher number"
            return
                
        # Select pymol object to use as a representative
        objSel, objIndx = self._get_selection(chain_id)
        if not objSel : return
            
        print "\nConserved alignment position ranges, alignment positions and residue numbers for ", objSel, " :"        
        for segment in segments :
            print segment[0],"-",segment[1],"(",segment[1]-segment[0],") ", self.pos2res[objIndx, segment[0]],"-",self.pos2res[objIndx, segment[1]]
        print
        
        # Select longest segment
        seg_length = [i[1] - i[0] for i in segments]
        max_length = max(seg_length)
        longest_seg = seg_length.index(max_length)
        
        start_res = self.get_residue_number(objIndx, segments[longest_seg][0])
        end_res = self.get_residue_number(objIndx, segments[longest_seg][1])
        reference_selection = objSel +" and resi "+str(start_res)+"-"+str(end_res)+" and name CA  and (alt A or alt \"\")"
        
        # Highlight template in pymol
        self._pymol.select(reference_selection,"longest_segment")

        return segments
      
    def align_structures(self, segment=None, id_list=None, chain_id=None) :
        """
        Align all loaded structures using given segment onto chain_id. If chain_id is not defined the reference structure is used. Segments are a pair of residue alignment positions.
        Segments for which the backbone conformation is conserved can be obtained using the get_conserved_segment function.
        segment : a pair of residue positions marking to start and end alignment positions to use for superimposition. If not defined the longest conserved backbone conformation segment is used.
        
        Parameters
        ----------
        
        segment : list of 2 ints
            alignment positions of first and last residues to use for alignment. Default is longest segment at default conservation threshold.
            
        id_list : list of str
            chain ids of structures to align e.g. ['1P38_A', '1A9U_A']. If none provided then all structures loaded with be aligned.

        chain_id : string
            optional chain to use as the representative stucture. Format is pdbcode_chainletter e.g. "2IW8_A". If none is provided, one will be chosen automatically. 
        """
        
        # Define the range of residue to be used for superimposition
        if segment == None :
            segments = self.get_conserved_segments()
            max_length = 0
            for segment in segments :
                length = segment[1] - segment[0]
                if length > max_length :
                    max_length = length
                    max_seg = segment
            segment = max_seg            
        else :
            core_res0 = segment[0]
            core_res1 = segment[1]

        # Select pymol object to use as a template
        objSel, objIndx = self._get_selection(chain_id)
        if not objSel : return

        # Start and end of residues to use for superimposition
        core_res0 = segment[0]
        core_res1 = segment[1]
        start_res = self.get_residue_number(objIndx, core_res0)
        end_res = self.get_residue_number(objIndx, core_res1)
        reference_selection = objSel +" and resi "+str(start_res)+"-"+str(end_res)+" and name CA  and (alt A or alt \"\")"
        
        # Highlight template in pymol
        self._pymol.select(reference_selection,"alignment_template")

        # reference protein could be a multiframe object e.g. NMR ensemble, so fit frames to first one
        self._pymol.intra_fit(reference_selection)
        
        # Superimpose all the loaded structures or those listed.
        if id_list == None :
            id_list = self._loaded_structures
            
        for id in id_list :
            
            # create selection for segment residue range
            objIndx = self._aligned.index_from_id(id)
            start_res = self.get_residue_number(objIndx, core_res0)
            end_res = self.get_residue_number(objIndx, core_res1)
            pdb_code, model_no, chain_letter = ids_from_id(id, blank_chain_null=True)
            if chain_letter == '' :
                moving_selection = id+" and resi "+str(start_res)+"-"+str(end_res)+" and name CA and (alt A or alt \"\")"
            else :
                moving_selection = id+" and chain "+chain_letter+" and resi "+str(start_res)+"-"+str(end_res)+" and name CA and (alt A or alt \"\")"
            
            # fit segment to reference structure
            self._pymol.pair_fit(moving_selection, reference_selection)

    def load_structures(self, id_list=None, segment=None, pymol_group=None) :
        """
        Load structures in the alignment file into pymol and align to the reference structure. If no list of ids are provided all structures will be loaded.
        segment : a pair of residue positions marking to start and end alignment positions to use for superimposition. If not defined the longest conserved backbone conformation segment is used.
        """

        # for all structures in the alignment
        if id_list == None :
            id_list = self._aligned.ids()
            
        for id in  id_list:
            if id == self._representative :
                continue
            pdb_code, model_no, chain_letter = ids_from_id(id, blank_chain_null=True)

            
            # load pdb file
            pdb_file = CONFIG.get('directories','data')+"pdbs/"+pdb_code+".pdb"
            self._pymol.delete(id)            
            self._pymol.load(pdb_file,id)
            self._loaded_structures.add(id)
            
            # add to pymol group
            if pymol_group == None :
                self._pymol.group(self._group,id)
            else :
                self._pymol.group(pymol_group,id)
        
        self.align_structures(segment=segment, id_list=id_list)
        self._pymol.zoom(self._selection)
        self._pymol.show_sticks("hetatm and not resn HOH")
        
    def load_cluster_representatives(self, number, property="backbone", segment=None, pymol_group=None) :
        """
        Load a given number of cluster representatives. The default property to use for clustering is backbone curvature and torsion. Other properties may not give meaningful results.
        """
        # Get/calculate selected property
        properties = Properties()
        array = properties.get_array(property, self._aligned)
        
        # Calculate structure difference matrix
        structmat = Structure_Matrix(array)
        
        # Calculate tree using hierarchical clustering
        ids = self._aligned.ids()
        tree = Tree(structmat.data, ids, scale=False)
        indices, ids = tree.cluster_representatives(number, array)
        
        # Load selected structures
        self.load_structures(id_list=ids, segment=segment, pymol_group=pymol_group)
        
    def load_non_redundant_structures(self, distance_cutoff=0.025, property="backbone", segment=None, pymol_group=None) :
        """
        Load only structures that are greater that distance_cutoff distance apart. The default property to use for clustering is backbone curvature and torsion. Other properties may not give meaningful results.
        """
        # Get/calculate selected property
        properties = Properties()
        array = properties.get_array(property, self._aligned)
        
        # Calculate structure difference matrix
        structmat = Structure_Matrix(array)
        
        # Calculate tree using hierarchical clustering
        ids = self._aligned.ids()
        tree = Tree(structmat.data, ids, scale=False)
        indices, ids = tree.non_redundant_set(distance_cutoff, array)
        
        # Load selected structures
        self.load_structures(id_list=ids, segment=segment, pymol_group=pymol_group)

    def delete_structures(self, id_list=None) :
        """
        Delete pymol objects in id_list. If no list is provided then all will be deleted.
        """
        if id_list == None :
            id_list = self._loaded_structures
        
        for id in id_list :
            try :
                self._loaded_structures.remove(id)                
                self._pymol.delete(id)
            except ValueError :
                print id+" not in list of loaded structures."

    def save_structures(self, directory, id_list=None) :
        """
        Save pdb files for given ids to a specified directory.
        """
        # If directory doesn't exit create it
        if not os.path.isdir(directory): 
           os.mkdir(directory)
           
        # If no ids specified use all loaded structures
        if id_list == None :
            id_list = self._loaded_structures
            
        # Save files
        for id in id_list :
            filename = directory+"/"+id+".pdb"
            self._pymol.save(filename, id)
        
    def get_residue_number(self, structure_index, alignment_array_index) :
        """
        Returns the residue number for a particular position in the alignment. Returns None
        if that position is an indel ("-")
        """
        if not self.pos2res.mask[structure_index,alignment_array_index] :
            return self.pos2res[structure_index,alignment_array_index]
        else :
            return None
    
    def label_snps(self) :
        """
        Label residues in the representative stucture for which a non-synonymous SNP is known. Requires Variations.py which requires access to the now out of date in-house REQUIEM database. 
        """
        from Polyphony.Variation import Variation_Alignment_Array
        snp_array = Variation_Alignment_Array(self._aligned)
        objSel = self._selection
        objIndx = self._aligned.index_from_id(self._representative)
        snp_counts = snp_array.data[objIndx]
        for i in range(self._aligned.length()) :
            if snp_counts[i] > 0 :
                ires = self.get_residue_number(objIndx, i)
                if ires != None :
                    selection = self._selection+" and resi "+str(ires)+" and name CA"
                    if snp_counts[i] == 1 :
                        label = "nsSNP"
                    else :
                        label = str(snp_counts[i])+" nsSNPs"
                    self._pymol.label(selection,label)        
        
    def most_diverse_ids(self, num_to_keep) :
        """
        Return list of num_to_keep most diverse structures in the alignment based upon a comparison of backbone conformations.
        """
        kt_array = Kappa_Tau_Alignment_Array(self._aligned)
        kt_structmat = Structure_Matrix(kt_array)
        kt_tree = Tree(kt_structmat.data, kt_structmat.get_labels())
        clusters = kt_tree.cut(num_to_keep)
        ids = []
        for cluster_index_list in clusters :
            ids.append(self._aligned.get_representative_structure(indices=cluster_index_list))
        return ids

    def show_correlated_backbones(self, maxpairs, separation=0) :
        """
        Draw a yellow dotted line connecting residue positions that show correlated backbone conformations.
        
        Parameters
        ----------
        
        maxpairs : int
            the maximum number or correlated residues to include
            
        separation : int
            ignore correlations between residues below separation apart
        """
        kt_array = Kappa_Tau_Alignment_Array(self._aligned)
        kt_resmat = Residue_Matrix(kt_array)
        kt_resmat.reduce_to_one_per_residue()
        respairs = kt_resmat.get_closest_pairs(maxpairs, separation)    
        objSel = self._selection
        objIndx = self._aligned.index_from_id(self._representative)
        name = self._representative+"_corr_bb"
        
        print "\nres1", "res2", "correlation"
        for i in respairs :
            aa0 = i[0][0] 
            aa1 = i[0][1]
            res0 = self.get_residue_number(objIndx, aa0)
            res1 = self.get_residue_number(objIndx, aa1)
            correlation = i[1]
            #xyz0 = self._pymol.get_coords(objSel,res0, "CA")
            #xyz1 = self._pymol.get_coords(objSel,res1, "CA")
            #radius = correlation * correlation / 200.0
            #self._pymol.cylinder(xyz0,xyz1,0.3,[1,0,0],name)
            atm1 = objSel+" and resi "+str(res0)+" and name CA"
            atm2 = objSel+" and resi "+str(res1)+" and name CA"
            self._pymol.distance(atm1, atm2, name)            
            print res0, res1, correlation
        self._pymol.hide_labels(name)
        self._pymol.group(self._group,name)
        self._pymol.zoom(objSel)
    
    def show_correlated_sidechains(self, maxpairs, separation=0) :
        """
        Draw a red dotted line connecting residue positions that show correlated side-chain conformations.
        
        Parameters
        ----------
        
        maxpairs : int
            the maximum number or correlated residues to include
            
        separation : int
            ignore correlations between residues below separation apart
        """
        from Polyphony.Sidechains import SideChain_Alignment_Array
        from Bio.PDB.Polypeptide import one_to_three

        sc_array = SideChain_Alignment_Array(self._aligned)
        sc_resmat = Residue_Matrix(sc_array)
        sc_resmat.reduce_to_one_per_residue()
        respairs = sc_resmat.get_closest_pairs(maxpairs, separation)
        objSel = self._selection
        objIndx = self._aligned.index_from_id(self._representative)
        name = self._representative+"_corr_sc"
        sequence = self._aligned.get_sequence(objIndx)
        self._pymol.hide_everything(objSel)
        self._pymol.show_ribbon(objSel)

        print "\nres1", "res2", "correlation"        
        for i in respairs :
            aa0 = i[0][0] 
            aa1 = i[0][1]
            
            res0 = self.get_residue_number(objIndx, aa0)
            res1 = self.get_residue_number(objIndx, aa1)
            
            # Side chains not present in selected structure
            if res0 == None or res1 == None :
                continue

            #res0 = self.pos2res[objIndx,aa0] 
            #res1 = self.pos2res[objIndx,aa1] 
    
            correlation = i[1]
            #xyz0 = self._pymol.get_coords(objSel,res0, "CA")
            #xyz1 = self._pymol.get_coords(objSel,res1, "CA")
            #radius = correlation * correlation / 20000.0
            #self._pymol.cylinder(xyz0,xyz1,radius,[1,1,0],name
            
            resname0 = one_to_three(sequence[aa0])
            resname1 = one_to_three(sequence[aa1])
            if resname0 == "GLY" or resname0 == "ALA" or resname1 == "GLY" or resname1 == "ALA" :
                print res0, resname0, res1, resname1, correlation
                print "Correlations involving Gly and Ala are ignored."
                continue
            atm1 = objSel+" and resi "+str(res0)+" and name "+sc_array.sc_terminus[resname0] 
            atm2 = objSel+" and resi "+str(res1)+" and name "+sc_array.sc_terminus[resname1]
            self._pymol.distance(atm1, atm2, name)
            self._pymol.show_sticks(objSel+" and resi "+str(res0)+" and ("+self._pymol.sidechain+" or "+self._pymol.calpha+")")
            self._pymol.show_sticks(objSel+" and resi "+str(res1)+" and ("+self._pymol.sidechain+" or "+self._pymol.calpha+")")
            print res0, res1, correlation
        self._pymol.hide_labels(name)
        self._pymol.colour(name, "red")
        self._pymol.hide_everything
        self._pymol.group(self._group,name)
        self._pymol.zoom(objSel)
        
    def colour_by_pockets(self, chain_id = None) :
        """
        Colour surface of residues that are found forming pockets by the Fpocket program. 
        """
        # Calculate percentages for main chain atoms and sidechain atoms separately
        from Polyphony.Fpocket import Pocket_Alignment_Array
        pocket_array = Pocket_Alignment_Array(self._aligned)
        mc_percent, sc_percent = pocket_array.percentage_in_pocket()
        
        # Colour backbone and sidechain atoms by percentage in contact with druggable pocket
        descriptor = mc_percent
        self._colour_residues(descriptor, set_bfactors=False, selection="backbone", chain_id=chain_id)
        descriptor = sc_percent
        self._colour_residues(descriptor, set_bfactors=False, selection="sidechain", chain_id=chain_id)
        
    def colour_by_most_druggable_structure(self, min_dscore = 0.9, max_pockets = 5, chain_id = None) :
        """
        For each residue, identify the structure in which it is part of the most druggable (highest dscore) pocket. Residue positions with a max dscores below min_dscore are masked.
        
        Requires
        --------
        
        Fpocket
        
        """
        # Get/calculate selected property
        properties = Properties()
        array = properties.get_array("pockets", self._aligned)
        
        # Find maximal druggable pocket for each residue position
        pocket_dictionary, pocket_idx_array = array.most_druggable_pockets(min_dscore, max_pockets)
        print pocket_dictionary
        print pocket_idx_array
        if pocket_idx_array.count() == 0 :
            print "No druggable pockets found. Try a lower value of min_dscore."
            return
        
        # Colour representative structure by pocket
        self._colour_residues(pocket_idx_array, set_bfactors=False, selection="allatoms", chain_id=chain_id)
        
        # Load each structure with the most drug-like pocket and show pocket surface
        ids = []
        for pock in pocket_dictionary :
            struct_id = pocket_dictionary[pock][0]
            fpocket_id = pocket_dictionary[pock][1]
            self.load_structures(id_list = [struct_id])
            ids.append(struct_id)
            atoms_dict = array.atoms_in_pocket(struct_id, fpocket_id)
            selection_name = self.selection_from_dict(struct_id, atoms_dict)
            self._pymol.show_surface(selection_name)
            
        return ids

    def selection_from_dict(self, chain_id, atoms_dict) :
        """
        Creates a pymol selection for all the atoms lining a fpocket pocket from its chain id and pocket id (starts at 1).
        """

        #for res in atoms_dict :
        #    selection += "resi "+res+" or "       
        #selection = selection[0:-4]+")"

        #large pymol selections cause it crash, so selection is built up iteratively residue by residue
        self._pymol.create_selection("pock_atoms", "none")
        pdb_code, model_no, chain_letter = ids_from_id(chain_id, blank_chain_null=True)
        for res in atoms_dict :
            res_selection = "pock_atoms or ("+chain_id+" and chain "+chain_letter+" and (resi "+res+" and ("
            for atm in atoms_dict[res] :
                res_selection += "name "+atm+" or "
            res_selection = res_selection[0:-4]+")))"
            self._pymol.create_selection("pock_atoms", res_selection)
            
        return "pock_atoms"

    def colour_by_druggable_pockets(self, min_dscore = 0.5, chain_id=None) :
        """
        Colour surface of residues that are found forming druggable pockets by the Fpocket program. 
        """
        # Calculate percentages for main chain atoms and sidechain atoms separately
        from Polyphony.Fpocket import Pocket_Alignment_Array
        pocket_array = Pocket_Alignment_Array(self._aligned)
        mc_percent, sc_percent = pocket_array.percentage_in_druggable_pocket(min_dscore)
        
        # Colour backbone and sidechain atoms by percentage in contact with druggable pocket
        descriptor = mc_percent
        self._colour_residues(descriptor, set_bfactors=False, selection="backbone", chain_id=chain_id)
        descriptor = sc_percent
        self._colour_residues(descriptor, set_bfactors=False, selection="sidechain", chain_id=chain_id)
       
    def colour_by_alignment_position(self, chain_id=None) :
        """
        Colour backbone by position in sequence alignment red to blue. If chain_id is defined then only that chain is coloured, otherwise all loaded chains are coloured.
        """
        
        # Select pymol object to colour
        descriptor = numpy.ma.array(range(self._aligned.length()))
        descriptor.mask = False
        if chain_id != None :
            self._colour_residues(descriptor, rmax=0, set_bfactors=False, selection="allatoms", chain_id=chain_id)
        else :
            for chain_id in self._loaded_structures :
                self._colour_residues(descriptor, rmax=0, set_bfactors=False, selection="allatoms", chain_id=chain_id)
        
    def colour_by_average_property(self, property, set_bfactors=False, groups=None, chain_id=None) :
        """
        Colour each residue by its average bfactor in the alignment.
        """
        descriptor = self._value_per_position(property, "average_per_residue", groups=groups)
        self.__zero_bfactors(chain_id)
        self._colour_residues(descriptor, set_bfactors=set_bfactors, chain_id=chain_id)
        
    def colour_by_property(self, property="bfactor", func_name="average_per_residue", selection="backbone", set_bfactors=False, groups=None, chain_id=None, **kwargs) :
        """
        Colour each residue by its average bfactor in the alignment.
        """
        descriptor = self._value_per_position(property, func_name, groups=groups, **kwargs)
        self.__zero_bfactors(chain_id)
        self._colour_residues(descriptor, set_bfactors=set_bfactors, selection=selection, chain_id=chain_id)
        
    def colour_single_structure_property(self, property="backbone", dimension=0, selection="backbone", set_bfactors=False, chain_id=None) :
        """
        Colour residues by the property values of a single structure. If property is multidimensional then the dimension can be chosen.
        """
        objSel, objIndx = self._get_selection(chain_id)
        if not objSel : return

        self.colour_by_property(property=property, func_name="select_dimension_for_single_chain", selection=selection, set_bfactors=set_bfactors, dimension = dimension, idx=objIndx)

    def __zero_bfactors(self, chain_id=None) :
        """
        Set all bfactors to zero in selected chain and colour all atoms gray
        """
        # Set all bfactors to zero in current object
        if chain_id == None :
            objSel = self._representative
        else :
            objSel = chain_id
        
        self._pymol.set_bfactor(objSel,0.001) # set bfactors for whole pymol object to zero
        self._pymol.colour_atoms(objSel, "gray50")

    def colour_by_average_bfactor(self, groups=None, chain_id=None) :
        """
        Colour by average C-alpha bfactor.
        """
        descriptor = self._value_per_position("bfactor", "average_per_residue", groups=groups)
        self.__zero_bfactors(chain_id)
        self._colour_residues(descriptor, set_bfactors=True, chain_id=chain_id)
        
    def colour_by_values(self, values, set_bfactors=True, chain_id=None) :
        """
        Colour residues by a user supplied array of values of length equal to the length of the alignment
        """
        if len(values) != self._aligned.length() :
            raise RuntimeError("values array but be the same length as the alignment ("+str(self._aligned.length())+")")
        if set_bfactors :
            self.__zero_bfactors(chain_id)
        self._colour_residues(values, set_bfactors=set_bfactors, chain_id=chain_id)

    def colour_by_conformational_pca(self, max_pc_chains_to_ignore=10, show_plot="grid", components=[0,1], chain_id=None) :
        """
        Perform pca analysis on backbone (curvature and torsion) and sidechain conformation variables and colour atoms by loadings. 
        """
        from Polyphony.Stats import do_PCA_on_property_array

        # Get backbone descriptors
        properties = Properties()
        array = properties.get_array("backbone", self._aligned)
                    
        # Calculate residue position loadings for given principle components
        scores, loadings = do_PCA_on_property_array(array, max_pc_chains_to_ignore, components, show_plot=show_plot)
        
        # Sum absolute k,t loadings to give one number per residue
        descriptor = numpy.sum(numpy.absolute(loadings), axis=1)
        
        #print descriptor
        
        # set bfactors accordingly
        self.__zero_bfactors(chain_id)
        self._colour_residues(descriptor, set_bfactors=True, selection="backbone", chain_id=chain_id)

        # move on to sidechains
        array = properties.get_array("sidechain", self._aligned)
                    
        # Calculate residue position loadings for given principle components
        scores, loadings = do_PCA_on_property_array(array, max_pc_chains_to_ignore, components, show_plot=show_plot)
        
        # Sum absolute x,y,z loadings to give one number per residue
        descriptor = numpy.sum(numpy.absolute(loadings), axis=1)
        
        # Colour sidechains accordingly
        self._colour_residues(descriptor, set_bfactors=False, selection="sidechain", chain_id=chain_id)

    def colour_by_calpha_pca(self, max_pc_chains_to_ignore=10, show_plot="grid", components=[0,1], chain_id=None) :
        """
        Perform pca analysis on backbone (c-alpha coordinates) conformation variables and colour atoms by loadings. Superimposed proteins only! 
        """
        from Polyphony.Stats import do_PCA_on_property_array

        # Get backbone descriptors
        properties = Properties()
        array = properties.get_array("calphas", self._aligned)
                    
        # Calculate residue position loadings for given principle components
        scores, loadings = do_PCA_on_property_array(array, max_pc_chains_to_ignore, components, show_plot=show_plot)
        
        # Sum absolute k,t loadings to give one number per residue
        descriptor = numpy.sum(numpy.absolute(loadings), axis=1)
        
        # set bfactors accordingly
        self.__zero_bfactors(chain_id)
        self._colour_residues(descriptor, set_bfactors=True, selection="backbone", chain_id=chain_id)
        
    def colour_by_pca(self, property, dimensions=[], max_pc_chains_to_ignore=10, show_plot="grid", components=[0,1], chain_id=None) :
        """
        Perform pca analysis on given property. Colour calpa atoms by loadings. 
        """
        from Polyphony.Stats import do_PCA_on_property_array

        # Get descriptors
        properties = Properties()
        array = properties.get_array(property, self._aligned)
                            
        # Calculate residue position loadings for given principle components
        scores, loadings = do_PCA_on_property_array(array, max_pc_chains_to_ignore, components, show_plot=show_plot, dimensions=dimensions, show_labels=False)

        #for i in range(len(loadings[:,0])) :            
        #    print i, loadings[i,0]
        
        # If property is multidimensional, then sum absolute loadings to give one number per residue
        if array.data_dim > 1 and (len(dimensions) == 0 or len(dimensions) > 1): # Need to summarise loading contributions from more than one decriptor, so take sum of abs values.
            descriptor = numpy.sum(numpy.absolute(loadings), axis=1)
        elif len(dimensions) == 1 : # single dimension chosen from many. Allow negative contributions.Sum 
            descriptor = loadings[:,[dimensions]].flatten()
        else : # Single dimension only
            descriptor = loadings[:,0]
            
        #print "Loadings: "
        #print descriptor
            
        # set bfactors accordingly
        self.__zero_bfactors(chain_id)
        self._colour_residues(numpy.absolute(descriptor), set_bfactors=True, selection="backbone", chain_id=chain_id)
        self._colour_residues(descriptor, set_bfactors=False, selection="backbone", chain_id=chain_id)
  
    def colour_by_correlation_to_an_array(self, ydata, property="backbone", chain_id=None) :
        """
        Correlate each residue's property values to a given array of numbers. ydata must 1D array of length equal to the number of structures in the alignment (self.size). Residues are coloured by the maximum absolute coorelation per residue. 
        """
        # Get property
        properties = Properties()
        array = properties.get_array(property, self._aligned)

        # Calculate 
        coeffs = array.calculate_residue_correlation(ydata)
        coeffs.shape = array.length, array.data_dim
        descriptor = reduce(coeffs, method="max_abs")
        
        # set bfactors accordingly
        if property == "backbone" :
            self.__zero_bfactors(chain_id)
            self._colour_residues(descriptor, set_bfactors=True, selection="backbone", chain_id=chain_id)
        elif property == "sidechain" :
            self._colour_residues(descriptor, set_bfactors=False, selection="sidechain", chain_id=chain_id)
        else  :
            self._colour_residues(descriptor, set_bfactors=False, selection="backbone", chain_id=chain_id)
                   
    def colour_by_variability(self, groups=None, missing_value_cut_off=50, normalise_colours=True, chain_id=None) :
        """
        Colour each residue by its conformational variability. Groups can be a list or a list of lists of structure index values. If a group or groups are defined then values are centred on the group average and as a result only intra group variability is displayed. If normalise_colours is set false the colour range is set based upon all structures in the alignment.
        
        Input Parameters
        ----------------
        
        groups : list of list of ints
            If the alignment contains structures from different proteins then you might want to consider only the variation within each protein (conformational change), instead of the overall variability (conformational + structural change). To do this create a list of lists of structure indices e.g. [[1,2,3],[4,5,6,7]]
            
        missing_value_cut_off: integer
            Alignment positions when many residues are disordered are coloured gray. This parameter controls what percentage of structure have missing residues before the gray is used. The higher the number the fewer residues will be coloured grey. Allowed range (0-100)
            
        normalise_colours : bool
            if True then colours always cover the full range of red to blue. If False the colours are related to the absolute levels of variability for a given set of structures. This facilitates the comparison between different sets of proteins
            
        chain_id : string
            the id of a molecule in Pymol. Uses representative structure as default.
        
        """

        #
        # Backbone
        #
        
        # If not using normalised colours, use those based upon overall variability    
        min_value, bin_size = None, None
        if normalise_colours == False :
            # Calculate overall min value and colour bin size for backbone
            descriptor = self._value_per_position("backbone", "calculate_variability", missing_value_cut_off=missing_value_cut_off, groups=None)
            min_value, bin_size = self.__calculate_min_and_bin_size(descriptor)

        # calculate variability for backbone
        descriptor = self._value_per_position("backbone", "calculate_variability", missing_value_cut_off=missing_value_cut_off, groups=groups)

        # set bfactors accordingly
        self.__zero_bfactors(chain_id)
        self._colour_residues(descriptor, set_bfactors=True, selection="backbone", bin_size=bin_size, min_value=min_value, chain_id=chain_id)

        #
        # Sidechains
        #

        # If not using normalised colours, use those based upon overall variability    
        min_value, bin_size = None, None
        if normalise_colours == False :
            # Calculate overall min value and colour bin size for sidechains
            descriptor = self._value_per_position("sidechain", "calculate_variability", missing_value_cut_off=missing_value_cut_off, groups=None)
            min_value, bin_size = self.__calculate_min_and_bin_size(descriptor)

        # calculate variability for sidechains
        descriptor = self._value_per_position("sidechain", "calculate_variability", missing_value_cut_off=missing_value_cut_off, groups=groups)
        # colour side-chain atoms accordingly
        self._colour_residues(descriptor, set_bfactors=False, selection="sidechain", bin_size=bin_size, min_value=min_value, chain_id=chain_id)
    
    def colour_by_seq_variability(self, groups=None, chain_id=None) :
        """
        Colour each residue by its sequence variability.
        """
        descriptor = self._value_per_position("sequence", "calculate_variability", groups=groups)
        self.__zero_bfactors(chain_id)
        self._colour_residues(descriptor, set_bfactors=True, selection="allatoms", chain_id=chain_id)
        
    def colour_by_conservation_score(self, alignment_filename, window_size=3, chain_id=None) :
        """
        Read in a sequence alignment file, calculate sequence conservation and colour a structure by these values. The sequence alignment file must include the sequence of the structure in PyMol and it must have the same id. The rest of the sequences need not have a corresponding structure. Sequence conservation is the information content as calculated using Biopython. 
        """
        objSel, objIndx = self._get_selection(chain_id)
        if not objSel :
            raise RuntimeError(chain_id+" not in current array.")
        chain_id = objSel.split(" ")[0]
        chain_letter = objSel.split(" ")[-1]
        
        # score_converation program and location
        score_conservation_executable = CONFIG.get('executables','score_conservation')
        score_conservation_location = "/".join(score_conservation_executable.split('/')[:-1])
        
        # current location and location of alignment file
        alignment_filename = os.path.abspath(alignment_filename)
        pwd = os.path.abspath('.')
        
        # Move to score_converation directory and run 
        os.chdir(score_conservation_location)
        result_file = CONFIG.get('directories','tmp')+"/conserve_score.txt"
        command = "score_conservation.py -a "+chain_id+" -w "+str(window_size)+" "+alignment_filename
        print command
        os.system(command+" | cut -f3 | tail +6 > "+result_file)
        
        # Extract conversation scores
        results = open(result_file)
        try :
            results_list = [float(line.strip()) for line in results]
        except ValueError :
            raise RuntimeError("score_conservation returned no results. Check selected chain id is in the alignment.")            
        results.close()

        # Move back to original directory
        os.chdir(pwd)
        
        if len(results_list) == 0 :
            raise RuntimeError("score_conservation returned no results. Check selected chain id is in the alignment.")
        
        # Put into masked array
        results_array = numpy.ma.array(results_list)
        results_array.mask = results_array == -1000

        # Map into residues in protein structure
        res_nums = self._aligned._get_unaligned_residues(chain_id=chain_id).data[:,1]
        
        if len(res_nums) != len(results_array) :
            raise RuntimeError("Chain sequence length different in alignment file and in structure.")
        
        # Set b-factors to conservation scores
        self._pymol.set_bfactor(objSel, numpy.ma.min(results_array)) # initialise all to min score
        for i in range(len(res_nums)) :
            if not results_array.mask[i] :
                self._pymol.set_bfactor(objSel+" and resi "+str(res_nums[i]), results_array[i])
                
        # Colour by bfactor
        self._pymol.colour_by_bfactor(objSel)
        
        # Colour masked residues (>30% gaps) gray
        self._pymol.create_residue_selection(res_nums[results_array.mask], "gapped")
        self._pymol.colour_atoms("gapped", "gray50")
        
        ## Colour other atoms in object grey
        #others = "("+chain_id+" and not chain "+chain_letter+") or organic"
        #print others
        #self._pymol.colour_atoms(others, "gray50")
        
    def colour_by_Ramachandran_region(self, chain_id=None) :
        """
        For a single structure, colour each residue by phi/psi combination as defined in North, B.;  Lehmann, A.;  Dunbrack, R. L. Journal of Molecular Biology 2011, 406, 228-256
        red - alpha-helix, blue - beta-sheet, green - polyproline II, orange - left-handed helix, cyan - delta, magenta - gamma. 
        """
        # Select pymol object to colour
        objSel, objIndx = self._get_selection(chain_id)
        if not objSel : return
        
        # Calculate ramachandran regions
        properties = Properties()
        phipsi_array = properties.get_array("phipsi", self._aligned)
        regions = phipsi_array.ramachandran_regions(objIndx)
        
        # Put all residues from each region (colour) into bins
        res_in_bins = self.__assign_res_to_bin(objIndx, regions)
        
        # Colour pymol object one bin at a time (much quicker than one residue at a time)
        selection = objSel + " and " + PyMOLViewer.backbone
        self._pymol.colour_atoms(selection, "gray50")
        for region in res_in_bins :
            if region != -1 :
                colour = phipsi_array.rama_colours[region]
                self._pymol.create_residue_selection(res_in_bins[bin], "res_sel")
                self._pymol.colour_atoms(selection+" and res_sel", colour)

    def colour_by_difference_in_variability(self, groups1, groups2, chain_id=None) :
        """
        Colour by the variability in the first grouping minus the variability in the second.
        """
        descriptor1 = self._value_per_position("backbone", "calculate_variability", groups=groups1)
        descriptor2 = self._value_per_position("backbone", "calculate_variability", groups=groups2)
        descriptor = descriptor1 - descriptor2
        self.__zero_bfactors(chain_id)
        self._colour_residues(descriptor, set_bfactors=True, selection="backbone", chain_id=chain_id)
        descriptor1 = self._value_per_position("sidechain", "calculate_variability", groups=groups1)
        descriptor2 = self._value_per_position("sidechain", "calculate_variability", groups=groups2)
        descriptor = descriptor1 - descriptor2
        self._colour_residues(descriptor, set_bfactors=False, selection="sidechain", chain_id=chain_id)
        
    def colour_by_contacts(self, type="crystal_contacts", group=None, chain_id=None) :
        """
        Colour backbone red to blue by frequency of occurrence of contacts. Contacts can either be with a small molecule (type="small_molecules") or
        protein crystal contacts (contacts type = "crystal_contacts"), or PISA predicted biologically relevant protein-protein contacts (type="protein_protein")
        """
        if type == "small_molecules" :
            
            try: 
                from Polyphony.Credo import Credo_Alignment_Array
            except ImportError:
                print "! Credo import failed for some reason. Can't run this routine. Sorry."
                return
            array = Credo_Alignment_Array(self._aligned)
        elif type == "crystal_contacts" :
            try :
                from Polyphony.Contacts import Contact_Alignment_Array
            except ImportError:
                print "! NCONT import failed for some reason. Can't run this routine. Sorry."
                return
            array = Contact_Alignment_Array(self._aligned)
        elif type == "protein_protein" :
            try :
                from Polyphony.Piccolo import Piccolo_Alignment_Array
                PICCOLO_INSTALLED = True
            except ImportError:
                print "! PICCOLO import failed for some reason. Can't run this routine. Sorry."
                return
            array = Piccolo_Alignment_Array(self._aligned)
        else :
            print "! Contact type must = small_molecules, crystal_contacts or protein_protein"
            return
        
        if group != None :
            array = array.subset(group)
            
        totals = array.count_per_alignment_position()
        #sizes = 0.5 + totals/float(numpy.max(totals))
        descriptor = 0.1 + 100.0 * totals/array.size
        
        objSel, objIndx = self._get_selection(chain_id)
        if not objSel : return

        self._colour_residues(descriptor, set_bfactors=True, selection="backbone", chain_id=chain_id)

        #self._pymol.hide_everything(objSel)
        #self._pymol.show_ribbon(objSel)
        #self._pymol.colour_atoms(objSel, "blue")
        #self._pymol.make_gradient("blue_red",numpy.max(totals)+1)
        #
        #for i in range(self._aligned.length()) :
        #    ires = self.get_residue_number(objIndx, i)
        #    if ires != None and totals[i] > 0 :
        #        self._pymol.colour_atoms(objSel+" and resi "+str(ires), "blue_red"+str(totals[i]))
                   
    def ids_for_groups(self, groups) :
        """
        Return the chain ids for the given groups
        """
        return self._aligned.ids_for_groups(groups)
    
    def group_biggest_clusters(self, num_cluster_pairs=1, property = "backbone") :
        """
        Create groups by clustering structures by a given property (property = "backbone","sidechain","sequence" etc. as defined in polyphony.cfg). After hierarchical clustering the biggest subtree is chosen. The size of a subtree is determined by counting the leaves (protein structures) within its two child subtrees. Size is chosen to be the smaller of these two numbers.
        For the largest subtree the protein chain identifiers within its two child subtrees are output. More pairs of child subtrees can be returned by increasing num_cluster_pairs.
        Output is a list of size num_cluster_pairs*2+1. The lists of the chains in each of the pairs of subtrees are in the first num_cluster_pairs*2, all other chains are in the
        last list in output. Groups are not mutually exclusive.
        """
        
        # Get/calculate selected property
        properties = Properties()
        array = properties.get_array(property, self._aligned)

        # Calculate a distance matrix
        structmat = Structure_Matrix(array)
        
        # Calculate a hierarchical tree from the matrix
        tree = Tree(structmat.data, structmat.get_labels())

        # Find the members of the largest subtree
        groups = tree.biggest_left_right_others(num_cluster_pairs)
        
        return groups

    def group_by_property(self, num_clusters, property = "backbone") :
        """
        Create groups by clustering structures by a given property (property = "backbone","sidechain","sequence" etc. as defined in polyphony.cfg) and cutting the hierarchical tree into a specified
        number of clusters. See http://bonsai.ims.u-tokyo.ac.jp/~mdehoon/software/cluster/cluster.pdf for more information on how this is done.
        """
        # Get/calculate selected property
        properties = Properties()
        array = properties.get_array(property, self._aligned)

        # Calculate a distance matrix
        structmat = Structure_Matrix(array)
        
        # Calculate a hierarchical tree from the matrix
        tree = Tree(structmat.data, structmat.get_labels())
        
        # Cut tree into clusters
        clusters = tree.cut(num_clusters)
        
        return clusters

    def group_by_sequence(self, pc_id_cutoff=90) :
        """
        Group by percentage sequence minimum percentage sequence identity. Set pc_id_cutoff to change cutoff.
        """
        res_array = Residue_Alignment_Array(self._aligned)
        groups = res_array.cluster_by_sequence_identity(pc_id_cutoff)
        return groups
    
    def group_by_pdb(self) :
        """
        Put chains from the same pdb into groups
        """
        return self._aligned.group_by_pdb()
        
    def colour_groups(self, pair_of_lists) :
        """
        Colour proteins by group membership. Input is a pair of lists containing members of two groups. Run the
        load_all_structures() function first.
        """
        for id in pair_of_lists[0] :
            pdb_code, model_no, chain_letter = ids_from_id(id, blank_chain_null=True)
            selection = id+" and chain "+chain_letter
            self._pymol.colour_atoms(selection,"red")
        for id in pair_of_lists[1] :
            pdb_code, model_no, chain_letter = ids_from_id(id, blank_chain_null=True)
            selection = id+" and chain "+chain_letter
            self._pymol.colour_atoms(selection,"blue")
    
    def _concatinate_structures(self, id_list, directory, filename) :
        """
        cat all pdb files in directory into filename
        """
        import shutil, re
        
        destination = open(filename, 'wb')
        for id in id_list :
            filename = directory+"/"+id+".pdb"

            # Put id into model header
            ifile = open(filename, "r")
            lines = ifile.readlines()
            ifile.close()
            ofile = open(filename, "w")
            for line in lines:
                ofile.write(re.sub(r'^MODEL', 'MODEL\t'+id, line))
            ofile.close()            
            shutil.copyfileobj(open(filename, 'rb'), destination)
        destination.close()
        
    def create_animation(self, id_list, filename, segment=None) :
        """
        Create a multimodel pdb file of the given structures in the order specified.
        
        Input Parameters
        ----------------
        
        id_list : list of type string
            list of alignment ids in order
            
        filename : string
            name of pdb file to create (must have .pdb or no extension)
            
        segment : list of int
            pair of residue alignment positions specifying the start and end of the conserved segment to be used for superimposition
        """        
        # Keep list of structures already loaded
        before = self._loaded_structures

        # Load all structures
        self.load_structures(segment=segment, id_list=id_list)
        
        # Save all structures to a temporary directory
        import uuid
        temp_dir_name = os.getcwd()+"/"+str(uuid.uuid4()) 
        self.save_structures(temp_dir_name, id_list)
        
        # Create a concatinated multimodel pdb file
        self._concatinate_structures(id_list, temp_dir_name, filename)
        name = filename.split('/')[-1].split('.')[0]
        
        # Load concatinated file as a pymol movie
        self._pymol.load(filename, name)
        
        # Remove tempory directory
        import shutil
        #shutil.rmtree(temp_dir_name)
        
        # Remove structures from pymol that weren't already loaded
        for id in id_list :
            if id not in before :
                self.delete_structures([id])
    
    def colour_by_variance(self, property, groups, chain_id=None) :
        """
        Colour variance within the num_groups largest cluster pairs
        """
        
        # Calculate subtree variances
        descriptor = self._value_per_position(property, "calculate_group_variance", groups)
        
        if property == "sidechain" :
            self._colour_residues(descriptor, set_bfactors=False, selection="sidechain", chain_id=chain_id)            
        elif property == "backbone" :
            # Set bfactors to calculated b-factors and colour by b-factor    
            self.__zero_bfactors(chain_id)
            self._colour_residues(descriptor, set_bfactors=True, selection="backbone", chain_id=chain_id)
        else :
            self._colour_residues(descriptor, set_bfactors=True, selection="allatoms", chain_id=chain_id)

    def colour_conserved_segments(self, threshold=0.5) :
        """
        Colour regions of conserved backbone conformation blue and the rest red. The threshold is in standard deviations below the mean.
        """
        if threshold < 0.0 :
            threshold = 0.0

        kt_array = Kappa_Tau_Alignment_Array(self._aligned)
        segments = kt_array.find_conserved_segments(threshold=threshold)
        if len(segments) == 0 :
            print "No conserved segments found. Try increasing the threshold."
            return
        
        # Show ribbon with conserved segments coloured red
        objSel = self._selection
        objIndx = self._aligned.index_from_id(self._representative)
        self._pymol.hide_everything(objSel)
        self._pymol.show_ribbon(objSel)
        self._pymol.colour_atoms(objSel, "red")
        for segment in segments :
            # residue numbers of first and last residue in segment
            ires0 = self.get_residue_number(objIndx, segment[0])
            ires1 = self.get_residue_number(objIndx, segment[1])
            # colour all residues within that range red
            selection = objSel + " and resi "+str(ires0)+"-"+str(ires1)
            self._pymol.colour_atoms(selection, "blue")        
        
    def calc_dihedral(self, resnum1, resnum2, resnum3, resnum4, atm1="CA", atm2="CA", atm3="CA", atm4="CA", chain_id=None) :
        """
        Calculate an dihedral angle (in degrees) between atoms in all structures in the alignment.
        """
        
        # Select pymol object to colour
        objSel, objIndx = self._get_selection(chain_id)
        if not objSel : return
            
        sel1 = objSel+" and resi "+str(resnum1)+" and name "+atm1
        sel2 = objSel+" and resi "+str(resnum2)+" and name "+atm2
        sel3 = objSel+" and resi "+str(resnum3)+" and name "+atm3
        sel4 = objSel+" and resi "+str(resnum4)+" and name "+atm4
               
        self._pymol.dihedral(sel1,sel2,sel3,sel4,"dihedral")

        pos1 = self.res2pos[objIndx, resnum1]
        pos2 = self.res2pos[objIndx, resnum2]
        pos3 = self.res2pos[objIndx, resnum3]
        pos3 = self.res2pos[objIndx, resnum4]
              
        return self._aligned.calc_angle(pos1,pos2,pos3,pos4,atm1,atm2,atm3,atm4)

    def calc_angle(self, resnum1, resnum2, resnum3, atm1="CA", atm2="CA", atm3="CA", chain_id=None) :
        """
        Calculate an angle (in degrees) between atoms in all structures in the alignment.
        """
        
        # Select pymol object to colour
        objSel, objIndx = self._get_selection(chain_id)
        if not objSel : return
            
        sel1 = objSel+" and resi "+str(resnum1)+" and name "+atm1
        sel2 = objSel+" and resi "+str(resnum2)+" and name "+atm2
        sel3 = objSel+" and resi "+str(resnum3)+" and name "+atm3
               
        self._pymol.angle(sel1,sel2,sel3,"angle")

        pos1 = self.res2pos[objIndx, resnum1]
        pos2 = self.res2pos[objIndx, resnum2]
        pos3 = self.res2pos[objIndx, resnum3]
              
        return self._aligned.calc_angle(pos1,pos2,pos3,atm1,atm2,atm3)

    def calc_distance(self, resnum1, resnum2, atm1="CA", atm2="CA", chain_id=None) :
        """
        Calculate a distance (in Angstoms) between atoms in all structures in the alignment.
        """
        
        # Select pymol object to colour
        objSel, objIndx = self._get_selection(chain_id)
        if not objSel : return
            
        sel1 = objSel+" and resi "+str(resnum1)+" and name "+atm1
        sel2 = objSel+" and resi "+str(resnum2)+" and name "+atm2
               
        self._pymol.distance(sel1,sel2,"distance")

        pos1 = self.res2pos[objIndx, resnum1]
        pos2 = self.res2pos[objIndx, resnum2]
              
        return self._aligned.calc_distance(pos1,pos2,atm1,atm2)
        
        