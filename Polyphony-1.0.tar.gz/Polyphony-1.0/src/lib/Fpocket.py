"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Initial import CONFIG
from Polyphony.Utils import run_silently
from Bio.PDB import PDBParser
import os, stat, re, numpy, shutil
from collections import defaultdict

# Check Fpocket is installed
fpocket_exe = CONFIG.get('executables','fpocket')
if os.access(fpocket_exe,os.F_OK) == False :
    print "Fpocket excutable not found."
    raise ImportError
        
from Polyphony.Property_Arrays import Structure_Property_Array, Structural_Alignment_Property_Array
from Polyphony.Jalview import JalviewFeatureFileCreator

class Pocket_Array(Structure_Property_Array) :
    
    """
    Class to run the Fpocket program (http://fpocket.sourceforge.net/) on a protein chain, parse the results and record a per residue summary of the pockets found. For each residue the following information are stored: [pocket id, score, drug score, bfactor, hydrophicity, polarity, volume, charge, number main chain atoms, number sidechain atoms] for the largest pocket a residue is part of.
    """
    
    data_type = float                   # data are the pocket descriptors produced by fpocket
    data_dim = 10                       # 9 dimensional data
    dim_names = ["pocket id", "score", "drug score", "bfactor", "hydrophicity", "polarity", "volume", "charge", "mchain atoms", "sidechain atoms"]
    data_labels = "isdbhpvcms"          # id, score, drug score, b-factor, hydrophobicity, polarity, volume, charge, number of atoms forming the pocket, main-chain atom count, side-chain atom count (per residue)
    data_directory = "pockets"          # directory where calculated results are stored
    padding = 0                         # number of residues to mask out either side of gaps and at termini

    def __init__(self, alignment, alignment_index, update = False) :
        Structure_Property_Array.__init__(self, alignment, alignment_index, update)
            
    def _calculate(self) :
        """
        Run Fpocket interatomic contacts calculation and store results in an array
        """
        chain_file = CONFIG.get('directories','data')+"chains/"+self.pdb_chain_code+".pdb"
        results_directory = CONFIG.get('directories','data')+"/"+self.data_directory
        shutil.copy(chain_file,results_directory)
        chain_file = results_directory+"/"+self.pdb_chain_code+".pdb"
        fpocket_command = fpocket_exe + " -f " + chain_file
        # Run script
        os.system(fpocket_command)
        output_directory = results_directory+"/"+self.pdb_chain_code+"_out/"
        # Extract data from results file
        return self._parse_files(output_directory)

    def _parse_files(self, output_directory):
        """
        parse Fpocket output
        """
        info_file = output_directory+self.pdb_chain_code+"_info.txt"
        pockets = self._parse_info_file(info_file)
        pdb_parser = PDBParser()
        
        data = numpy.ma.zeros(self.length*self.data_dim)
        data.shape = self.length,self.data_dim
        data.mask = False
        
        # Get list of residue numbers in protein chain
        residues = self.alignment.get_residues(self.pdb_chain_code)
        residue_numbers = [res.id[1] for res in residues]

        # loop through each pocket found
        for i in range(len(pockets)) :
            
            # put required descriptors into a list
            id = float(i + 1)
            score = pockets[i]["Score"]
            drug_score = pockets[i]["Druggability Score"]
            bfactor = pockets[i]["Flexibility"]
            hydrophobicity = pockets[i]["Hydrophobicity score"]
            polarity = pockets[i]["Polarity score"]
            volume = pockets[i]["Volume score"]
            charge = pockets[i]["Charge score"]
            pocket_data = [id,score,drug_score,bfactor,hydrophobicity,polarity,volume,charge]
            
            # Find residues lining pocket
            atm_file = output_directory+"/pockets/pocket"+str(i)+"_atm.pdb"
            atms = self._parse_pocket_pdb(atm_file)
            #atms = run_silently(pdb_parser.get_structure,"p"+str(i),atm_file)
            
            # For each residue add in pocket data (don't overwrite if already assigned since pockets are sorted by decreasing score)
            for res_num in atms :
                mc_count = atms[res_num][0]
                sc_count = atms[res_num][1]
                try :
                    res_idx = residue_numbers.index(res_num)
                except ValueError :
                    # Residue in Fpockets but not in Polyphony - ignore
                    continue
                if data[res_idx][0] == 0 :
                    data[res_idx] = pocket_data + [mc_count,sc_count]
        return data
    
    def _parse_pocket_pdb(self, atm_filename) :
        file = open(atm_filename,"r")
        backbone_names =["  N", " CA", "  C", "  O"]
        atms = {}
        for line in file :
            if line.startswith("ATOM") :
                resnum = int(line[22:26])
                atom_name = line[13:16]
                if resnum not in atms :
                    atms[resnum] = [0,0]
                if atom_name in backbone_names :
                    atms[resnum][0] += 1
                else :
                    atms[resnum][1] += 1
        file.close()
        return atms
        
    def _parse_info_file(self, info_filename) :
        file = open(info_filename,"r")
        idParser = re.compile("[0-9][0-9]*")
        varnameParser = re.compile("[a-zA-Z][a-zA-Z- ]*[a-zA-Z]")
        varParser = re.compile("-*[0-9][0-9.]*$")

        pockets = []
        for line in file :
            if line.startswith("Pocket") : # Beginning of pocket description
                id = int(idParser.findall(line)[0])
                variables = {}
            elif not line.isspace() : # Pocket variable names and values
                name = varnameParser.findall(line)[0]
                value = varParser.findall(line)[0]
                if name != "" and value != "" :
                    variables[name] = float(value)
            else : # end of pocket
                pockets.append(variables)
        file.close()
        return pockets        

class Pocket_Alignment_Array(Structural_Alignment_Property_Array) :
    
    """
    Class for calculating (or reading) Fpocket (http://fpocket.sourceforge.net/) information for all residues in an alignment. Does this by creating a Pocket_Array object for each chain in an alignment.
    
    Parameters
    ----------

    structural_alignment : Structural_Alignment instance
        the alignment to which the descriptor applies. Features will be duplicated for each sequence.

    update : bool
        if set True then values are all calculated from scratch. Otherwise values pre-calculated for an alignment with the same name will be ready from disk.
        
    Examples
    --------
    
    >>> 
    >>> aligned = Structural_Alignment()
    >>> aligned.add_alignment("my_alignment.fasta")
    >>> pocket_array = Pocket_Alignment_Array(aligned, update=False)

    """

    
    data_directory = "pocket_arrays"   # directory where calculated results are stored
    data_file_extension = ".npy"        # extension of data files

    def __init__(self, structural_alignment, update = False) :
        Structural_Alignment_Property_Array.__init__(self, structural_alignment, Pocket_Array, update)
        
    def reduce(self) :
        """
        Return reduced version of data in a 2d array, use score
        """
        return self.data[:,:,1]

    def write_jalview_feature_file(self, filename) :
        """
        Create Jalview feature file for highlighting extremes of backbone conformation sequence alignment viewer.
        """
                
        self.make_jalview_feature_file(filename, "Pocket", "fpocket", "FFFF00", "FF6600", 1.5, 2.5, standardise=False)
    
    #def write_jalview_feature_file(self,filename) :
    #    """
    #    Write Jalview feature file with two types of feature: Fpocket, which is colour coded by overall pocket score and Dpocket, which is colour coded by the druggability score.
    #    """
    #    jalfile = JalviewFeatureFileCreator()
    #    jalfile.add_colour("Fpocket","FFFF00","FF6600",100,300)
    #    jalfile.add_colour("Dpocket","FFFF00","FF6600",0.5,0.8)
    #    ids = self.get_ids()
    #    res2pos, ires2pos, pos2res, pos2ires = self.alignment._create_residue_indices()
    #
    #    for i in range(self.size) :
    #        id = ids[i]
    #        for j in range(self.length) :
    #            if not self.data.mask[i,j][1] and not self.data[i,j][1] == 0  :
    #                # weight = score * num atms
    #                jalfile.add_feature("Pocket", id, pos2ires[i,j]+1, pos2ires[i,j]+1, "Fpocket", self.data[i,j][1] * self.data[i,j][8])
    #            if not self.data.mask[i,j][2] and not self.data[i,j][2] > 0.5 :
    #                # weight = score * num atms
    #                jalfile.add_feature("Pocket", id, pos2ires[i,j]+1, pos2ires[i,j]+1, "Dpocket", self.data[i,j][2])
    #    jalfile.write_file(filename)
    
    def calculate_distance_matrix(self, all_mask=False) :
        """
        Calculate a distance matrix using the manhatten distance metric.
        """
        if not type(all_mask) == bool :
            all_mask = self._expand_array(all_mask) 
        return self.calculate_manhatten_distance_matrix(all_mask)

    def percentage_in_druggable_pocket(self, min_dscore = 0.5) :
        """
        Return percentage of residues in each alignment position that are part of a druggable pocket.
        min_dscore = 0.5 : the minimum dscore used to define a druggable pocket. Default is authors recommendation.
        return : two 1D masked arrays, the first for mainchain and the second for side-chain atoms  
        """
        # Residues atoms lining drug-like pocket 
        dscore_values = self.data[:,:,2]
        boolean_data = dscore_values > min_dscore
                
        # For each alignment position, count residues with main chain atoms in drug-like pockets ?
        mc_counts = self.data[:,:,8]
        boolean_mc = mc_counts > 0
        boolean_mc_data = numpy.ma.logical_and(boolean_data,boolean_mc)
        mc_percent = 100.0 * numpy.ma.sum(boolean_mc_data,axis=0) / numpy.ma.count(boolean_mc_data,axis=0)

        # For each alignment position, count residues with side chain atoms in drug-like pockets ?
        sc_counts = self.data[:,:,9]
        boolean_sc = sc_counts > 0
        boolean_sc_data = numpy.ma.logical_and(boolean_data,boolean_sc)
        sc_percent = 100.0 * numpy.ma.sum(boolean_sc_data,axis=0) / numpy.ma.count(boolean_sc_data,axis=0)

        return mc_percent, sc_percent
    
    def percentage_in_pocket(self) :
        """
        Return two arrays, the first containing the percentage of mainchain atoms per alignment position that are part of an pocket, and the second the same but for sidechain atoms.
        """
        
        # For each alignment position, count residues with main chain atoms in pockets ?
        mc_counts = self.data[:,:,8]
        boolean_mc = mc_counts > 0
        mc_percent = 100.0 * numpy.ma.sum(boolean_mc,axis=0) / numpy.ma.count(boolean_mc,axis=0)

        # For each alignment position, count residues with side chain atoms in pockets ?
        sc_counts = self.data[:,:,9]
        boolean_sc = sc_counts > 0
        sc_percent = 100.0 * numpy.ma.sum(boolean_sc,axis=0) / numpy.ma.count(boolean_sc,axis=0)
        
        return mc_percent, sc_percent
    
    def find_cryptic_pockets(self, min_dscore = 0.5, pc_exist_cutoff = 30, min_res_count = 5) :
        """
        Identify druggable pockets that only occur in a small percentage of structures. EXPERIMENTAL
        """
        # Residues atoms lining drug-like pocket 
        dscore_values = self.data[:,:,2]
        boolean_data = dscore_values > min_dscore
        
        # Percentage less than cutoff (definition of cryptic)
        druggable_pc = 100.0 * numpy.ma.sum(boolean_data,axis=0) / numpy.ma.count(boolean_data,axis=0)
        cryptic = numpy.ma.logical_and(druggable_pc < pc_exist_cutoff, druggable_pc > 0)
        boolean_data[:, numpy.ma.logical_not(cryptic)] = False # exclude whole residue columns if not cryptic
        num_cryptic_residue_positions = numpy.ma.sum(cryptic)
        print "Number of residue positions in cryptic sites", num_cryptic_residue_positions

        # Structures that have more than min_res_count residues in cryptic binding sites
        cryptic_structure = numpy.ma.sum(boolean_data, axis=1) > min_res_count
        num_cryptic_structures = numpy.ma.sum(cryptic_structure)
        print "Number or structures with cryptic sites", num_cryptic_structures

        # For each alignment position, count residues with main chain atoms in drug-like cryptic pockets ?
        mc_counts = self.data[:,:,8]
        boolean_mc = mc_counts > 0
        boolean_mc_data = numpy.ma.logical_and(boolean_data,boolean_mc)

        # For each alignment position, count residues with side chain atoms in drug-like pockets ?
        sc_counts = self.data[:,:,9]
        boolean_sc = sc_counts > 0
        boolean_sc_data = numpy.ma.logical_and(boolean_data,boolean_sc)

        # Create arrays to store scores of in cryptic pockets
        mc_scores = numpy.ma.zeros(num_cryptic_structures*self.length)
        mc_scores.mask = False
        mc_scores.shape = num_cryptic_structures, self.length
        sc_scores = numpy.ma.zeros(num_cryptic_structures*self.length)
        sc_scores.mask = False
        sc_scores.shape = num_cryptic_structures, self.length
        
        structure_ids = []
        idx = 0
        ids = self.alignment.ids()
        for istruct in range(self.size) :
            if cryptic_structure[istruct] :
                structure_ids.append(ids[istruct])
                mc_scores[idx] = self.data[istruct,:,2].copy()
                mc_scores.mask[idx] += numpy.ma.logical_not(boolean_mc_data[istruct])
                sc_scores[idx] = self.data[istruct,:,2].copy()
                sc_scores.mask[idx] += numpy.ma.logical_not(boolean_sc_data[istruct])
                #numpy.putmask(sc_scores[idx], numpy.logical_not(boolean_sc_data[istruct]), 0.0)
                idx += 1
        
        return structure_ids, mc_scores, sc_scores
    
    def _pocket_overlap(self, lres_set, gres_set, min_res_overlap) :
        """
        return True if pockets are considered to be the same
        """
        # if local residue set is 
        if lres_set.issubset(gres_set) :
            return True
        elif lres_set.issuperset(gres_set) :
            return True 
        elif lres_set.isdisjoint(gres_set) :
            return False
        else :
            smaller = min(len(lres_set), len(gres_set))
            intersection = len(lres_set.intersection(gres_set))
            union = len(lres_set.union(gres_set))
            if 100.0 * intersection/smaller > min_res_overlap :
                return True
            else :
                return False
    
    def _update_or_append_pockets(self, seqi, local_pockets, global_pockets, min_res_overlap) :
        """
        Check where local_pocket matches an existing global pocket. If so, merge. Otherwise create new global_pocket. 
        """
        if len(global_pockets) == 0 :
            # First time round
            for lpocket in local_pockets :
                # Create tuple of (list of structure indices,set of residue numbers)
                global_pockets.append(([seqi],local_pockets[lpocket]))
        else :
            # For each local pocket, check whether it overlaps with a global pocket. If so merge and increment frequency, otherwise add new global pocket with frequency = 1.
            for lpoc in local_pockets :
                overlap = False
                lres_set = local_pockets[lpoc]
                for gpoc in global_pockets :
                    gres_set = gpoc[1]
                    # if overlap then merge residue sets and update frequency
                    if self._pocket_overlap(lres_set, gres_set, min_res_overlap) :
                        gpoc[0].append(seqi)
                        gpoc[1].update(lres_set)
                        overlap = True
                        break
                if overlap == False :
                    global_pockets.append(([seqi],lres_set))
        return global_pockets
              
    def pocket_occurrence_frequency(self, min_dscore = 0.5, min_pc_res_overlap = 80) :
        """
        Identity pockets by the residues that make them and count how many structures each pocket appears in. 
        """
        global_pockets = []
        # For each structure
        for seqi in range(self.size) :
            struct_data = self.data[seqi]
            # Collect together residues (alignment positions) belonging to each pocket
            local_pockets = defaultdict(set)
            for resi in range(self.length) :
                local_pocket_id = struct_data[resi][0]
                dscore = struct_data[resi][2]
                if dscore > min_dscore :
                    local_pockets[local_pocket_id].add(resi)
            global_pockets = self._update_or_append_pockets(seqi, local_pockets, global_pockets, min_pc_res_overlap)
        return global_pockets
                
    def most_druggable_structure_per_residue(self, min_dscore = 0.5) :
        """
        For each residue position find structure in which it has the highest druggability score.
        
        Input Parameters
        ----------------
        min_dscore : float (default 0.5)
            the minimum dscore used to define a druggable pocket        
        
        Returns
        -------
        
        max_structs: numpy masked array
            a 1D numpy masked array of length self.length. Positions are masked where a druggable pocket never exists (dscore always less that min_dscore). Other positions hold the index of the structure with the highest dscore at that alignment position. 
            
        max_pocks : numpy masked array
            a 1D numpy masked array of length self.length. Positions are masked where a druggable pocket never exists (dscore always less that min_dscore). Other positions hold the fpocket id of the pocket with the highest dscore at that alignment position. 
        """
        
        # For each residue position find maximum dscore and structure in which this score occurs. Mask positions where maximum dscore is below cutoff
        dscore_values = self.data[:,:,2]
        max_structs = numpy.ma.argmax(dscore_values, axis=0)
        max_scores = numpy.ma.max(dscore_values, axis=0)
        max_structs = numpy.ma.array(max_structs)
        max_structs.mask = max_scores.mask 
        max_structs.mask += max_scores < min_dscore
        
        # Get fpocket pocket ids for max scoring pockets 
        pocket_ids = self.data[:,:,0]
        max_pocks = numpy.ma.zeros(self.length)
        for resi in range(self.length) :
            max_pocks[resi] = pocket_ids[max_structs.data[resi], resi]
        max_pocks.mask = max_structs.mask
                
        return max_structs, max_pocks

    def max_dscore_per_residue(self) :
        """
        Find the maximum dscore per alignment position
        
        Returns
        -------
        
        a 1D numpy masked array of length self.length.  
        """
        
        # Residues atoms lining drug-like pocket 
        dscore_values = self.data[:,:,2]
        max_scores = numpy.ma.max(dscore_values, axis=0)
        
        return max_scores
    
    def most_druggable_pockets(self, min_dscore = 0.9, max_pockets = None) :
        """
        Identify the most druggable pockets for each region of a protein from amongst the structures in the alignment
        
        Parameters
        ----------
        min_dscore: float
            the minimum Fpocket dscore to be considered. The default is 0.9 which is higher than the published cutoff of 0.5 because whole alignment positions are considered.

        max_pockets : int (default None)
            the maximum number of pockets to return. Pockets are sorted by descending number of residues.
            
        Returns
        -------
        pocket_dictionary: dict 
            identified pockets are integer ids starting at 0 and in order of decreasing size (number of residues). These are the dictionary keys. The values is a list of length 2 containing the id of the structure for in which the pocket was found and the fpocket id of the pocket
            
        pocket_idx_array: 1d numpy masked array
            array of length equal to the length of the alignment. For each alignment position the array contains pocket number (keys of pocket_dictionary) assigned or masked if no pockets were found. 
        """
        
        # Find most druggable structure per residue.
        best_structs, max_pocks = self.most_druggable_structure_per_residue(min_dscore)
        ids = self.alignment.ids()
        
        # Number structures by decreasing number of residues  
        best_remaining_structs = best_structs.compressed()
        remaining_struct_indices = list(set(best_remaining_structs))
        remaining_struct_indices.sort()
        counts = [numpy.sum(best_remaining_structs == i) for i in remaining_struct_indices]
        order = list(numpy.argsort(counts))
        order.reverse()
        
        # If more pockets left than specified cutoff, trim them back
        if max_pockets != None and max_pockets < len(remaining_struct_indices) :
            order = order[:max_pockets]
            
        pocket_ids = [remaining_struct_indices[i] for i in order]
        
        # Create dictionary with one entry per pocket. To each pocket entry add a list containing the id of the structure to which the pocket belongs as the only item
        pocket_dictionary = {}
        for i in range(len(pocket_ids)) :
            pocket_dictionary[i] = [ids[pocket_ids[i]]]
        
        # Assign each residue it a new structure idx based upon frequency of occurrence 
        pocket_idx_array = numpy.ma.zeros(self.alignment.length(), int)
        pocket_idx_array.mask = True
        for i in range(self.alignment.length()) :
            struct_idx = best_structs[i]
            try :
                pocket_idx_array[i] = pocket_ids.index(struct_idx)
                pocket_idx_array.mask[i] = False
            except ValueError: # no selected pockets at this alignment position
                pass
            
        # Find all unique chain, pocket pairs
        best_struct_ids = [ids[i] for i in best_remaining_structs]
        best_structs_pocks = max_pocks.compressed()
        pair_array = numpy.column_stack((best_struct_ids, best_structs_pocks))
        pair_list = pair_array.tolist()
        pair_list.sort()
        unique_pairs = [x for i, x in enumerate(pair_list) if not i or x != pair_list[i-1]]

        # Add Fpocket id to pocket dictionary
        for pair in unique_pairs :
            struct_id = pair[0]
            fpocket_id = int(float(pair[1]))
            try :
                new_pocket_id = [k for k, v in pocket_dictionary.iteritems() if v[0] == struct_id][0]
                pocket_dictionary[new_pocket_id].append(fpocket_id)
            except IndexError :
                pass

        return pocket_dictionary, pocket_idx_array
    
    def atoms_in_pocket(self, chain_id, fpocket_id) :
        """
        For a given structure identifier and fpocket pocket id, return the atoms that line that pocket
        
        Parameters
        ----------
        chain_id : string
            structure identifier e.g. \"1P38_A\"
            
        fpocket_id : integer
            fpocket pocket identifier starting at 1 for the highest scoring pocket
            
        Returns
        -------
        atoms : dict
            keys id residue number, values are a set of atom names
        
        """
        atm_filename = CONFIG.get('directories','data')+"pockets/"+chain_id+"_out/pockets/pocket"+str(fpocket_id-1)+"_atm.pdb"
        file = open(atm_filename,"r")
        atoms = defaultdict(set)
        for line in file :
            if line.startswith("ATOM") :
                resnum = line[22:26].strip()
                atom_name = line[13:16].strip()
                atoms[resnum].add(atom_name)
        file.close()
        return atoms
