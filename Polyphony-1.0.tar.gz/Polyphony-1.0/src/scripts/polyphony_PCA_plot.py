#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file_property_and_bool, Properties
from Polyphony.Stats import do_PCA_on_property_array

## Main program

# Read alignment file and locations of data directories
filename, update, property, show_labels = read_command_line_file_property_and_bool("Produce a PCA plot for a given alignment and property. Use -b option to show labels.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate selected property
properties = Properties()
array = properties.get_array(property, aligned, update)
        
# Calculate residue position loadings for given 1st 3 principal components
scores, loadings = do_PCA_on_property_array(array, show_plot="grid", spectrum=True, show_labels=show_labels)

