#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file, Properties
import numpy

## Main program

# Read alignment file and locations of data directories
filename, update = read_command_line_file("Locates the most druggable pockets in different regions of protein. REQUIRES Fpocket to be installed and \"pockets\" to be uncommented in polyphony.cfg")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate selected property
properties = Properties()
array = properties.get_array("pockets", aligned, update)

# Find most druggable structure per residue.
best_structs, max_pocks = array.most_druggable_pockets(0.9)

# Best pockets
print
print "Most druggable pockets by decreasing size (number of residues in lining) and for each the structure and Fpocket pocket id :"
print best_structs
print

# Print pocket index next to consensus sequence
pocket_string = ""
seq_string = ""
seq_list = aligned.get_consensus_sequence()
length = len(seq_list)
for i in range(length) :
    if max_pocks.mask[i] :
        pocket_string += "-"
    else :
        pocket_string += str(int(max_pocks[i]))
    seq_string += seq_list[i]
    
print "Location of each pocket in consensus sequence :"

# Break into blocks of 50 residues
for i in range(length/50) :
    min = i*50
    max = min+50
    print pocket_string[min:max]
    print seq_string[min:max]
    print
min = 50*(length/50)+1
max = length
print pocket_string[min:max]
print seq_string[min:max]
print
