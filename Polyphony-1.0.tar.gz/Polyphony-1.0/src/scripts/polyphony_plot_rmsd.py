#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file_and_string, Properties
from Polyphony.Plotting import plot_alignment_properties
import numpy

## Main program

# Read alignment file and locations of data directories
filename, ref_id, update = read_command_line_file_and_string("Plot rmsd for alignment against a reference chain. The reference can be selected by providing a chain id otherwise the one with most ordered residues is used.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate selected property
properties = Properties()
array = properties.get_array("calphas", aligned, update)

# Calculate root mean squared fluctuation for each alignment position 
calpha_rmsds = array.rmsd(reference_id=ref_id)

# Get/calculate relative sidechain coords
array = properties.get_array("sidechain", aligned, update)

# Calculate root mean squared fluctuation for each alignment position 
sidechain_rmsds = array.rmsd(reference_id=ref_id)

# Write to file
ids = aligned.ids()
outputfile = open("rmsd.csv","w")
outputfile.write("id, c-alpha, sidechain\n")
for i in range(len(ids)) :
    outputfile.write("%s, %f, %f\n" % (ids[i], calpha_rmsds[i], sidechain_rmsds[i]))
outputfile.close()

# Plot
combined_rmsds = numpy.dstack((calpha_rmsds, sidechain_rmsds))
xlabels = aligned.ids()
plot_alignment_properties(combined_rmsds, "RMSD", xlabels, ["C-alphas", "Sidechains"])
