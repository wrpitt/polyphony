#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file, Properties
from Polyphony.Comparison_Matrices import Residue_Matrix, Structure_Matrix
from Polyphony.Trees import Tree as Ptree
from Polyphony.Residues import Residue_Alignment_Array
from Polyphony.Stats import do_PCA_on_property_array

from ete2 import Tree as Etree, faces
import numpy

# Ete2 tree diagram parameters
nameFace = faces.AttrFace("name", fsize=12, fgcolor="#009000")
def mylayout(node):
    # If node is a leaf, add the nodes name and a its scientific
    # name
    if node.is_leaf():
        # Add an static face that handles the node name
        faces.add_face_to_node(nameFace, node, column=0)
        # text faces support multiline. We add a text face
        # with the whole description of each leaf.
        descFace = faces.TextFace(header_info[node.name]['name'], fsize=10)
        # Note that this faces is added in "aligned" mode
        faces.add_face_to_node(descFace, node, column=0, aligned=True)

## Main program

# Read alignment file and locations of data directories
filename, update = read_command_line_file("Produce tree of structures based upon backbone conformation similarity weighted by PCA loadings from first 90% sequence identity group. Experimental approach requiring alignment containing homogous groups of structures. REQUIRES Ete2, pychem.mva")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)
header_info = aligned.get_header_info()

# Get/calculate selected property
properties = Properties()
array = properties.get_array("backbone", aligned, update)
        
# Use subset of structures
res_array = properties.get_array("sequence", aligned, update)
groups = res_array.cluster_by_sequence_identity(cut_off = 90)
array2 = array.subset(groups[0])

# Calculate residue position loadings for given 1st principle component
scores, loadings = do_PCA_on_property_array(array2, max_pc_chains_to_ignore=10, components=[0])

weights = numpy.absolute(loadings)

# Calculate distance matrix weighted by PCA loadings
structmat = array.calculate_distance_matrix(weights=weights)

# Calculate tree using hierarchical clustering 
tree = Ptree(structmat, aligned.ids(), scale=False)

# Write out tree in newick format
filename = "backbone_PC1.newick"
tree.write_Newick_file(filename)

# Show tree using ete2
t = Etree(filename)
t.show(mylayout)
