#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file_and_property, Properties
from Polyphony.Comparison_Matrices import Structure_Matrix
from Polyphony.Trees import Tree as Ptree
from Polyphony.Residues import Residue_Alignment_Array

from ete2 import Tree as Etree, faces, TreeStyle
import numpy, os


# Ete2 tree diagram parameters

nameFace = faces.AttrFace("name", fsize=12, fgcolor="#009000")
def mylayout(node):
    # If node is a leaf, add the nodes name and a its scientific
    # name
    if node.is_leaf():
        # Add an static face that handles the node name
        faces.add_face_to_node(nameFace, node, column=0)
        # text faces support multiline. We add a text face
        # with the whole description of each leaf.
        descFace = faces.TextFace(header_info[node.name]['name'], fsize=10)
        # Note that this faces is added in "aligned" mode
        faces.add_face_to_node(descFace, node, column=0, aligned=True)
        
        # Add an image if node.name".png" or ".gif" file exists in an ./images directory
        png_file = "./images/"+node.name+".png"
        gif_file = "./images/"+node.name+".gif"
        svg_file = "./images/"+node.name+".svg"
        if os.path.exists(png_file) :
            faces.add_face_to_node(faces.ImgFace(png_file), node, 1)
        elif os.path.exists(gif_file) :
            faces.add_face_to_node(faces.ImgFace(gif_file), node, 1)
        elif os.path.exists(svg_file) :
            faces.add_face_to_node(faces.ImgFace(svg_file), node, 1)

def circular_tree() :
    ts = TreeStyle()
    ts.show_leaf_name = True
    ts.mode = "c"
    ts.arc_start = -180 # 0 degrees = 3 o'clock
    ts.arc_span = 180
    return ts

def rotated_tree() :
    ts = TreeStyle()
    ts.rotation = 270
    return ts

## Main program

# Read alignment file and locations of data directories
filename, update, property = read_command_line_file_and_property("Calculate dendrogram (tree) of structures based upon clustering by provided property. Plot tree using Ete2 module and write out Newick format file. REQUIRES Ete2")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get info about each structure from the pdb header
header_info = aligned.get_header_info()

# Get/calculate selected property
properties = Properties()
array = properties.get_array(property, aligned, update)

# Calculate structure difference matrix
structmat = Structure_Matrix(array, update)

# Calculate tree using hierarchical clustering
ids = aligned.ids()
tree = Ptree(structmat.get_distance_matrix(), ids, scale=False)

# Write out tree in newick format
tree.write_Newick_file(property+".newick")

# Show tree using ete2
t = Etree(property+".newick")
#t.show(mylayout, tree_style=circular_tree())
#t.show(mylayout, tree_style = rotated_tree() )
t.show(mylayout)
