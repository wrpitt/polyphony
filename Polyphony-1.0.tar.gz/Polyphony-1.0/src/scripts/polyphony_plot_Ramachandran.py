#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file_and_property, Properties
from Polyphony.Plotting import plot_contour_and_scatter


## Main program

# Read alignment file and locations of data directories
filename, update, property = read_command_line_file_and_property("Plot composite Ramachandran plot for the structures in the alignment. Default for curvature/torsion version. Select -p \"phipsi\" for traditional version. Point colour is always by region in Ramachandran plot.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate phi,psi dihedral angles 
properties = Properties()

if property == "phipsi" :
    # Plot tradition Ramachandran plot
    array = properties.get_array("phipsi", aligned, update)
    colours = array.ramachandran_colours() 
   
    phipsis = array.data
    phipsis = phipsis.flatten()
    phipsis.shape = len(phipsis)/2, 2
    plot_contour_and_scatter(phipsis,5.0,-180.0,180.0,-180.0,180.0, 45.0, colours = colours, axis_labels=['phi','psi'])
elif property == "backbone" :
    # Plot curvature against torsion
    array = properties.get_array("phipsi", aligned, update)
    colours = array.ramachandran_colours() 
    array = properties.get_array("backbone", aligned, update)
    kts = array.data
    kts = kts.flatten()
    kts.shape = len(kts)/2, 2
    plot_contour_and_scatter(kts,0.1,0.0,5.0,-2.5,2.5, 1.0, colours=colours, axis_labels=['curvature','torsion'])
else :
    print "Please select phipsi or backbone as properties to plot"
