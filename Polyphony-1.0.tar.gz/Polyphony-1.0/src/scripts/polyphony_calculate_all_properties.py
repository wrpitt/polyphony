#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

"""
Calculate all properties on a given file. The list of allowed properties is read from the polyphony.conf file. See :doc:`config` for more information on this file. The resulting property arrays are stored on disk in the ~/Polyphony data directory so that they don't need to be recalculated, allowing a more interactive analysis of the data. If one or more property calculation fails, please comment out the corresponding line in the polyphony.conf file.
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file, Properties
    
## Main program

# Read alignment file and locations of data directories
filename, update = read_command_line_file("Calculate all properties on a given file.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate all properties
properties = Properties()
for property in properties.get_names() :
    array = properties.get_array(property, aligned, update)

print "\nFinished calculating all properties"

