#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


"""
Plot a structural properties as a function of structure. 
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file_property_positions_and_dimensions, Properties
from Polyphony.Plotting import plot_alignment_properties
    
## Main program

# Read alignment file and locations of data directories
filename, update, property, alignment_positions, dimensions = read_command_line_file_property_positions_and_dimensions("Plot a graph of each property values against structure.")

if not (len(alignment_positions) == 1 or len(dimensions) == 1) :
    raise RuntimeError("Either the number of alignment positions or the number of dimensions must equal 1")
    
# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate selected property
properties = Properties()
array = properties.get_array(property, aligned, update)

# Get slice
slice_array = array.slice(alignment_positions, dimensions)

# Data and axis labels
xy_data = slice_array.data.T
xlabels = aligned.ids()
length = aligned.size()
if len(alignment_positions) > 1 :
    ylabels = alignment_positions
    size = len(alignment_positions)
    xy_data.shape = size,length
elif len(dimensions) > 1 :
    ylabels = numpy.array(array.dim_names)[dimensions]
    size = len(dimensions)
    xy_data.shape = size,length
else :
    ylabels = None
    xy_data.shape = length

#Plot line plot    
plot_alignment_properties(xy_data, "slice", xlabels, [property], legend=ylabels)

print xy_data


