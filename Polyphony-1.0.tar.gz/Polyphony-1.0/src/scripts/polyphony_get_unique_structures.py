#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

"""
Produce a representative set of structures for a given alignment
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file, Properties
from Polyphony.Trees import Tree
from Polyphony.Comparison_Matrices import Structure_Matrix

    
## Main program

# Read alignment file and locations of data directories
filename, update = read_command_line_file("Produce a non-redundant set of structures for a given alignment. The choice between redundant structures is made based upon alphabetical order of the ids. Write a fasta file containing only the chosen structures.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate selected property
properties = Properties()
array = properties.get_array("backbone", aligned, update)

# Calculate structure difference matrix
structmat = Structure_Matrix(array, update)

# Find duplicates
dups = structmat.single_linkage_clusters(0.001)
if len(dups) == 0 :
    print "No duplicated found"
    exit()

dup_ids = aligned.ids_for_groups(dups)

# Calculate tree using hierarchical clustering
ids = aligned.ids()

# Uniques
uniques = ids
for i in dup_ids:
    for j in i :
        uniques.remove(j)

# Choose one from eeach duplicate cluster based on alphabetical order of ids
for i in dup_ids:
    i.sort()
    print i
    uniques.append(i[0])
        
# Write fasta file
unique_indices = [aligned.index_from_id(i) for i in uniques]
subset = aligned.subset(unique_indices)
subset.write_alignment_file(filename.split('.')[-2]+"_unique.fasta")
