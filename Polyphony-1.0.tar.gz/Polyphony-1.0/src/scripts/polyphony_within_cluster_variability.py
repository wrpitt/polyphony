#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


"""
Produce a representative set of structures for a given alignment
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file_property_and_number, Properties
from Polyphony.Trees import Tree
from Polyphony.Comparison_Matrices import Structure_Matrix
from Polyphony.Plotting import plot_alignment_properties
import numpy
    
## Main program

# Read alignment file and locations of data directories
filename, update, property, number = read_command_line_file_property_and_number("Produce a non-redundant set of structures for a given alignment. A recommended cutoff when using backbone conformation is 0.025. Write a fasta file containing only the chosen structures.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate selected property
properties = Properties()
array = properties.get_array(property, aligned, update)

# Calculate structure difference matrix
structmat = Structure_Matrix(array, update)

# Calculate tree using hierarchical clustering
ids = aligned.ids()
tree = Tree(structmat.data, ids, scale=False)

# Group by flat clusters
groups = tree.flat_clusters(number)
variability_list = []
for group in groups :
    if len(group) > 2 :
        subarray = array.subset(group)
        variability_list.append(subarray.calculate_variability())

var_array = numpy.ma.array(variability_list)
var_avg = numpy.ma.average(var_array,axis=0)


overall_var = array.calculate_variability()
numpy.putmask(overall_var.data, overall_var.mask, 0.0)
diff = overall_var - var_avg

composite = numpy.vstack((var_avg, overall_var, diff))

xlabels = aligned.get_consensus_sequence()
#plot_alignment_properties(var_array, "intragroup variability", xlabels, [str(i) for i  in range(len(variability_list))])
plot_alignment_properties(composite, "intragroup variability", xlabels, ["var_avg", "overall_var", "diff"], legend=["var_avg", "overall_var", "diff"])
