#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


"""
Produce a representative set of structures for a given alignment
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file_property_and_number, Properties
from Polyphony.Trees import Tree
from Polyphony.Comparison_Matrices import Structure_Matrix

    
## Main program

# Read alignment file and locations of data directories
filename, update, property, number = read_command_line_file_property_and_number("Produce a non-redundant set of structures for a given alignment. A recommended cutoff when using backbone conformation is 0.025. Write a fasta file containing only the chosen structures.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate selected property
properties = Properties()
array = properties.get_array(property, aligned, update)

# Calculate structure difference matrix
structmat = Structure_Matrix(array, update)

# Calculate tree using hierarchical clustering
ids = aligned.ids()
tree = Tree(structmat.data, ids, scale=False)

# Get non redundant set
indices,ids = tree.non_redundant_set(number, array)
print ids

# Write fasta file
subset = aligned.subset(indices)
subset.write_alignment_file("non_redundant.fasta")
