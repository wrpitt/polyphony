#!/usr/bin/python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from Polyphony.Initial import CONFIG
import os, glob, shutil, re, mmap, fileinput, sys


"""
Run by typing "python create_fasta_file.py -f my_cluster.html"
The input html file should be output from the RCSB sequence similarity webtool.
e.g. "http://www.rcsb.org/pdb/explore/sequenceCluster.do?structureId=1HUW&entity=1&cluster=2856&seqid=70"
The pdb files will be downloaded if necessary and a .fasta alignment file will be created. Please view
this alignment using your favourite multiple alignment software package. Correct alignment if necessary.

Please be aware that if the program tries to download a lot of files then the ftp server complains. If this happens you will need to rerun the script until all your files have been downloaded. The location of the ftp server is specified in :doc:`config`.
"""

from optparse import OptionParser, OptionGroup
from Polyphony.Prepare_Fasta_File import Prepare_Input_Data
import string, os


def read_command_line():
    """
    Read and check command line options. 
    """
    # Define commnad line parser options
    usage = "usage: %prog [options]"
    parser = OptionParser()
    
    # Option 1, sequence similarity cluster around a given pdb chain 
    group1 = OptionGroup(parser, "Specifications for a RCSB sequence cluster")
    group1.add_option("-p", "--pdbc", dest="pdbcode", help="pdb code of target protein. \n Please note for NMR ensembles, only the first model will be used. If you would like to analyse all models, copy the pdb file to the current directory, use the -m option and then manually add the resulting sequences to your fasta file.")
    group1.add_option("-c", "--chain", dest="chaincode", help="single letter chain code for target. default = \"\"", default = "")
    group1.add_option("-s", "--similarity", dest="similarity", help="Percentage sequence similarity cutoff, must be one of [100|95|90|70|50|40|30], default = 95", choices=["100","95","90","70","50","40","30"], default="95")
    parser.add_option_group(group1)
    
    # Option 2, provide your own sequence alignment file
    group2 = OptionGroup(parser, "Own sequence alignment specifications")
    group2.add_option("-f", "--fasta-file", dest="alignment_filename", help="name of sequence alignment file to use")
    parser.add_option_group(group2)

    # Option 3, provide directory full of pdb files
    group3 = OptionGroup(parser, "Directory of pdb files")
    group3.add_option("-d", "--directory", dest="directory", help="Specific a directory containing the pdb files you want use. Can be the current directory (.). Note Biopython halts reading pdb files if the element column on the far right has lower case letters e.g. Cl. You'll need to manually edit this to continue. Not my fault, sorry.")
    group3.add_option("-e", "--use_existing_names", dest="use_existing_names", help="Use existing names, after replacing underscores with hyphens. Otherwise fake pdb codes will be created for each file.", default=False, action="store_true")
    
    parser.add_option_group(group3)
    
    # Option 4, single multimodel pdb file e.g. MD trajectory
    group4 = OptionGroup(parser, "Selection from multimodel pdb")
    group4.add_option("-m", "--multimodel_pdb", dest="multimodel_pdb_filename")
    group4.add_option("-r", "--range", action="store", type="int", dest="mrange", nargs=3, help="Range (3 values, start, end and step size. Use spaces between values and start at 0)")
    parser.add_option_group(group4)

    parser.add_option("-u", "--update", dest="update", help="use this option if you want to re-extract all sequence data from pdb files", default=False, action="store_true")
    parser.add_option("-a", "--use_all_models", dest="models", help="If pdbs contain multiple models, treate them as separate chains. Otherwise use first model only (default)", default=False, action="store_true")
    
    (options, args) = parser.parse_args()        

    # Check options used correctly
    if options.alignment_filename == None and options.pdbcode == None and options.directory == None and options.multimodel_pdb_filename == None:
        print "You must choose one of the -p, -f, -d or -m input options"
        parser.print_help()
        exit(1)

    if ((options.alignment_filename != None) + (options.pdbcode != None) + (options.directory != None) + (options.multimodel_pdb_filename != None)) > 1:
        print "You must choose only one of the -p, -f, -d or -m input options"
        parser.print_help()
        exit(1)
                
    chain_id = None
    if options.pdbcode != None:
            
        print "\nYou have specified the following pdb cluster : pdbcode = \""+str(options.pdbcode)+"\", chain = \""+str(options.chaincode)+"\", similarity = "+str(options.similarity)+"%"
        if options.pdbcode == None :
            print "!!!Error. You must provide a PDB code."
            exit()
        if len(options.pdbcode) != 4 :
            print "!!!Error. PDB code are 4 characters long."
            exit()
        if len(options.chaincode) > 1 :
            print "!!!Error. PDB chain codes should no longer than 1 character."
            exit()

        chain_id = string.upper(options.pdbcode) + "_" + string.upper(options.chaincode)

    elif options.alignment_filename != None:
        
        print "Working with pre-existing alignment file", options.alignment_filename
        if not os.path.isfile(options.alignment_filename) :
            raise IOError("!!! File not found")
        
    elif options.directory != None :
        
        print "Extracting stuctures from the following directory", options.directory
        if not os.path.exists(options.directory) :
            raise IOError("!!! Directory not found")
            
    elif options.multimodel_pdb_filename != None :
        
        print "Extracting stuctures from single multimodel pdb file", options.multimodel_pdb_filename
        if not os.path.isfile(options.multimodel_pdb_filename) :
            raise IOError("!!! File not found")
        if options.mrange != None :
            print "The following snapshots will be used:", range(options.mrange[0],options.mrange[1],options.mrange[2])
            
    else :
        print "You must choose -p, -f, -d or -m input options"
        parser.print_help()
        exit(1)

    if options.update == True :
        print "Amino acid residue names and numbers will be updated."
        
    if options.models == True :
        print "Using all models in PDB files."
        
        
    return options.alignment_filename, chain_id, options.similarity, options.directory, options.use_existing_names, options.multimodel_pdb_filename, options.mrange, options.update, options.models

def line_count(filename):
    """
    Counts to the number of lines in a file (from Stackoverflow)
    """
    f = open(filename)                  
    lines = 0
    buf_size = 1024 * 1024
    read_f = f.read # loop optimization

    buf = read_f(buf_size)
    while buf:
        lines += buf.count('\n')
        buf = read_f(buf_size)
    f.close()
    print "number of lines", lines
    return lines

def multimodel_pdb(filename):
    """
    Look for ENDMDL record in pdb file
    """
    size = os.stat(filename).st_size
    print "file size: ", size
    in_file = open(filename, 'r')
    contents = mmap.mmap(in_file.fileno(), size, access=mmap.ACCESS_READ)
    endmdl_matches = contents.find("ENDMDL")
    contents.close()
    in_file.close()
    return endmdl_matches != -1

def convert_to_multimodel_pdb(filename):
    """
    Take pdb file with structures separated with END (e.g. produced by VMD) and replace with MODEL/ENDMDL records. MEMORY INTENSIVE FOR LARGE FILES. 
    """
    num_lines = line_count(filename)
    for line in fileinput.input(filename, inplace=1) :
        if fileinput.isfirstline() :
            line = "MODEL\n"+line
        if fileinput.lineno() != num_lines : 
           line = re.sub("END", "ENDMDL\nMODEL", line)
        else :
           line = re.sub("END", "ENDMDL", line)            
        #if fileinput.isstdin() :
        #    line = "ENDMDL\n"
        sys.stdout.write(line)
    fileinput.close()

def split_multimodel_file(filename, prefix) :
    """
    Split multimodel file into individual files. This avoids loading very large files into biopython objects in memory.
    """
    model_parser = re.compile("^MODEL")
    endmdl_parser = re.compile("^ENDMDL")
    atom_parser = re.compile("^ATOM")
    hetatm_parser = re.compile("^HETATM")
    
    # Check for MODEL/ENDMDL
    if not multimodel_pdb(filename) :
        convert_to_multimodel_pdb(filename)
        
    in_file = open(filename, 'r')
    indx = 0
    model_found=False
    for line in in_file :
        model_matches = model_parser.search(line)
        endmdl_matches = endmdl_parser.search(line)
        atom_matches = atom_parser.search(line)
        hetatm_matches = hetatm_parser.search(line)
        
        if model_matches != None :
            out_filename = prefix+str(indx)+".pdb"
            out_file = open(out_filename, "w")
            model_found = True
        elif endmdl_matches != None and model_found :
            out_file.close()
            indx += 1
        elif (atom_matches != None or hetatm_matches != None) and model_found :
            out_file.write(line)
    in_file.close()
    if not model_found :
        print "!!No models found in file."

def cat_multimodel_file(prefix, mrange) :
    """
    Concatinate selected model files into a single pdb
    """
    destination = open(prefix[:-1]+"-selected.pdb", 'w')
    destination.write("TITLE\n")
    # Selected range
    if mrange == None :
        mrange = range(len(glob.glob(prefix+"*.pdb")))
    else :
        mrange = range(mrange[0], mrange[1], mrange[2]) 

    for imod in mrange :
        filename = prefix+str(imod)+".pdb"
        destination.write("MODEL\t"+str(imod+1)+'\n')
        shutil.copyfileobj(open(filename, 'rb'), destination)
        destination.write("ENDMDL\t"+str(imod+1)+'\n')
    destination.close()

def replace_HIP_etc(prefix, mrange) :
    """
    Replace Amberforcefield non-standard residue codes with standard equivalents. For example HID, HIE, HIP residues with HIS. Biopython doesn't recognise the former and they only differ in protonation state.
    """
    #import fileinput
    #for imod in range(mrange[0],mrange[1],mrange[2]) :
    #    filename = prefix+str(imod)+".pdb"
    #    for line in fileinput.FileInput(filename,inplace=1):
    #        line = line.replace("HID","HIS")
    #        line = line.replace("HIE","HIS")
    #        line = line.replace("HIP","HIS")
    
    import re
    hid = re.compile('HID')
    hip = re.compile('HIP')
    hie = re.compile('HIE')
    cyx = re.compile('CYX')
    nln = re.compile('NLN')
    ols = re.compile('OLS')
    olt = re.compile('OLT')
    olp = re.compile('OLP')
    hyp = re.compile('HYP')
    
    # Selected range
    if mrange == None :
        mrange = range(len(glob.glob(prefix+"*.pdb")))
    else :
        mrange = range(mrange[0], mrange[1], mrange[2]) 

    for imod in mrange :
        filename = prefix+str(imod)+".pdb"    
        # Read contents or file
        infile = open(filename,"r")
        contents = infile.read()
        infile.close()
        # Replace residue names
        contents = hid.sub('HIS', contents)
        contents = hip.sub('HIS', contents)
        contents = hie.sub('HIS', contents)
        contents = cyx.sub('CYS', contents)
        contents = nln.sub('ASN', contents)
        contents = ols.sub('SER', contents)
        contents = olt.sub('THR', contents)
        contents = olp.sub('PRO', contents)
        contents = hyp.sub('PRO', contents)
        # Overwrite file
        outfile = open(filename,"w")
        outfile.write(contents)
        outfile.close()
        
def replace_HIP_etc_for_pdbs(directory) :
    """
    Replace Amberforcefield non-standard residue codes with standard equivalents. For example HID, HIE, HIP residues with HIS. Biopython doesn't recognise the former and they only differ in protonation state.
    """
    
    import re
    hid = re.compile('HID')
    hip = re.compile('HIP')
    hie = re.compile('HIE')
    cyx = re.compile('CYX')
    nln = re.compile('NLN')
    ols = re.compile('OLS')
    olt = re.compile('OLT')
    olp = re.compile('OLP')
    hyp = re.compile('HYP')
    
    files = glob.glob(directory+"/*.pdb")
    for filename in files :
        # Read contents or file
        infile = open(filename,"r")
        contents = infile.read()
        infile.close()
        # Replace residue names
        contents = hid.sub('HIS', contents)
        contents = hip.sub('HIS', contents)
        contents = hie.sub('HIS', contents)
        contents = cyx.sub('CYS', contents)
        contents = nln.sub('ASN', contents)
        contents = ols.sub('SER', contents)
        contents = olt.sub('THR', contents)
        contents = olp.sub('PRO', contents)
        contents = hyp.sub('PRO', contents)
        # Overwrite file
        outfile = open(filename,"w")
        outfile.write(contents)
        outfile.close()
        
def get_started() :
    """
    Create a fasta file containing sequences and ids of structures to be analysed. Input required : A pdb code, a chain letter and a
    percentage similarity (e.g. -p 2ONL -c A -s 40). Collectively, these options specify a RSCB sequence cluster.
    The members of which will be downloaded from the RSCB website.    
    """
    alignment_filename, chain_id, similarity, directory, use_existing_names, multimodel_pdb_filename, mrange, update, models = read_command_line()
    preparer = Prepare_Input_Data(CONFIG)
    if  chain_id != None:
        preparer.create_fasta_file_by_similarity(chain_id,similarity,update)
    elif alignment_filename != None :
        preparer.check_alignment_file(alignment_filename, update)
    elif directory != None :
        replace_HIP_etc_for_pdbs(directory)
        preparer.create_fasta_file_from_pdbs(directory, use_existing_names, update, models=models)
    elif multimodel_pdb_filename != None :
        # Split multimodel pdb into individual file
        prefix = multimodel_pdb_filename.split('/')[-1].split('.')[0]+"_"
        split_multimodel_file(multimodel_pdb_filename, prefix)
        replace_HIP_etc(prefix, mrange)
        # Create fasta file and store pdbs for selected models
        preparer.create_fasta_file_from_pdb(multimodel_pdb_filename, prefix, mrange, update)
        # Create single pdb file containing selected models
        cat_multimodel_file(prefix, mrange)

        # Remove split files from current directory        
        for file in glob.glob(prefix+"*.pdb") :
            os.remove(file)

filename = get_started()
