#!/usr/bin/env python
"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file, Properties
from Polyphony.Plotting import plot_alignment_properties
import numpy

## Main program

# Read alignment file and locations of data directories
filename, update = read_command_line_file("Plot RMSF for alignment")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate calpha coords
properties = Properties()
array = properties.get_array("calphas", aligned, update)

# Calculate root mean squared fluctuation for each alignment position 
calpha_rmsfs = array.rmsf()

# Get/calculate relative sidechain coords
array = properties.get_array("sidechain", aligned, update)

# Calculate root mean squared fluctuation for each alignment position 
sidechain_rmsfs = array.rmsf()

combined_rmsfs = numpy.dstack((calpha_rmsfs, sidechain_rmsfs))
# Plot
xlabels = aligned.get_consensus_sequence()
plot_alignment_properties(combined_rmsfs, "rmsf", xlabels, ["C-alphas", "Sidechains"])
