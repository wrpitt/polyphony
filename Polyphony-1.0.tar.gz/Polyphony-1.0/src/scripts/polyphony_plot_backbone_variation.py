#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file, Properties

import pylab, numpy

def plot_scatter(x_var, y_var, labels) :
    # Plot one against the other
    pylab.scatter(x_var,y_var)
    pylab.xlabel(labels[0], fontsize=24)
    pylab.ylabel(labels[1], fontsize=24)
    pylab.xticks(fontsize=16)
    pylab.yticks(fontsize=16)
#    pylab.title('Variation in Backbone Conformation')
    
    labels = [str(i) for i in range(aligned.length())]
    x_cut = numpy.max(x_var)/2.0
    y_cut = numpy.max(y_var)/2.0
    for label,x,y in zip(labels,x_var, y_var):
        if x > x_cut or y > y_cut :
            pylab.annotate(label, 
                    xy=(x,y), xytext=(-20,20), 
                    textcoords='offset points', ha='right', va='bottom',
                    bbox=dict(boxstyle='round,pad=0.5', fc='yellow', alpha=0.5),
                    arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0')
                    )
    
    pylab.show()
    
## Main program

# Read alignment file and locations of data directories
filename, update = read_command_line_file("Plot variation in curvature/torsion against variation in phi/psi for each residue position.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

properties = Properties()

# Get/calculate phi,psi dihedral angles and calculate distance matrix
phipsi_array = properties.get_array("phipsi", aligned, update)
phipsi_var = phipsi_array.calculate_variability()

# Get/calculate curvature, torsion values and calculate distance matrix
kt_array = properties.get_array("backbone", aligned, update)
kt_var = kt_array.calculate_variability()

plot_scatter(phipsi_var, kt_var, labels=["Phi/Psi variation", "Curvature/Torsion variation"])

# Calculate C-alpha RMSF per residue
calpha_array = properties.get_array("calphas", aligned, update)
rmsfs = calpha_array.rmsf()

plot_scatter(rmsfs, kt_var, labels=["RMSF", "Curvature/Torsion variation"])

plot_scatter(rmsfs, phipsi_var, labels=["RMSF", "Phi/Psi variation"])

