#!/usr/bin/env python

"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file_and_property, Properties
    
## Main program

# Read alignment file and locations of data directories
filename, update, property = read_command_line_file_and_property("Create a Jalview feature file annotating property values. To view the results, first load your alignment into Jalview, then in the resulting window file->load features/annotations.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate selected property
properties = Properties()
array = properties.get_array(property, aligned, update)

# Write Jalview feature file
array.write_jalview_feature_file(property+".ano")


