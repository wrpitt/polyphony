#!/usr/bin/env python
"""
    Polyphony. Python code for the analysis of protein structure ensembles.
    
    Copyright (C) 2013  William R. Pitt

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file_property_and_groups, Properties, reduce
from Polyphony.Jalview import JalviewFeatureFileCreator
from Polyphony.Stats import do_PCA_on_property_array
    
## Main program

# Read alignment file and locations of data directories
filename, update, property, seq_id_cutoff = read_command_line_file_property_and_groups("Do principal component analysis on given property for given alignment and report important residue positions for first principal component as a Jalview feature file")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate selected property
properties = Properties()
array = properties.get_array(property, aligned, update)

jfeatures = JalviewFeatureFileCreator("PCA", "loadings", "FFDDBB", "CC3300", 1.5, 2.5)

# Create groups by sequence identity if required
if seq_id_cutoff > 0 :
    
    # Calculate sequence based groups
    residue_array = properties.get_array("sequence", aligned, update)
    groups = residue_array.cluster_by_sequence_identity(cut_off = seq_id_cutoff)

    # Loop through each group, doing PCA on each separately
    idx = 0
    print groups
    for group in groups :
        sub_array = array.subset(group)
        filename = "PCA_loadings_s"+str(idx)+".ano"
        print group
        print sub_array.size, sub_array.length
        # Do PCA
        scores, loadings = do_PCA_on_property_array(sub_array, max_pc_chains_to_ignore=10, components=[0,1,2])
        
        # Reduce to 1d descriptor of same length as alignment
        descriptor = reduce(loadings, "sum_abs")
        
        # Create features for residues with loadings greater than 1 standard deviation above the mean
        jfeatures.add_features_from_1d_descriptor(aligned, descriptor, cutoff=1.0)
        
        idx += 1
        
filename = "PCA_loadings.ano"    
jfeatures.write_file(filename)


