#!/usr/bin/python

# This script should be run in ipython after starting pymol -R in another window.

from Polyphony.Pymol import Pymol_Viz
cdk2 = Pymol_Viz("clust_1HCK_A_95.fasta","cdk2")
cdk2.colour_by_most_druggable_structure(max_pockets=3)

# Use PyMol menu option Setting>Surfaces>Cavities and Pockets (culled)