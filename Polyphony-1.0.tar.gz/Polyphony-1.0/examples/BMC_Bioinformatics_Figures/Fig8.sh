#!/usr/bin/sh

./Fig8.py  -f clust_1HCK_A_95.fasta

