#!/usr/bin/python

from Polyphony.Trees import Tree
from Polyphony.Comparison_Matrices import Structure_Matrix
from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file_and_property, Properties
from Polyphony.Plotting import plot_alignment_properties
    
## Main program

# Read alignment file and locations of data directories
filename, update, property = read_command_line_file_and_property("Plot a graph of each structures property values against sequence.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate selected property
properties = Properties()
array = properties.get_array(property, aligned, update)

# Cluster by protein-protein interactions
clust_array = properties.get_array("ppi", aligned, update)
structmat = Structure_Matrix(clust_array)
tree = Tree(structmat.data, structmat.get_labels())

# Group into active and inactive
groups = tree.biggest_left_right_others(1)
unbound = groups[0]
bound = groups[1]

# Calculate amplification
amplifications = array.calculate_group_variance([unbound,bound], separate_components=True)

# Plot property, coloured by group
#xlabels = aligned.get_consensus_sequence()
xlabels = None
plot_alignment_properties(amplifications, property, xlabels, array.dim_names)
