#!/usr/bin/sh

polyphony_plot_Ramachandran.py -f clust_1HCK_A_95.fasta
