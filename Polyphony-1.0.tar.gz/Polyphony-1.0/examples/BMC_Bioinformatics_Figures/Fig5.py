#!/usr/bin/python

from Polyphony.Pymol import Pymol_Viz

# You need to do "pymol -R" in a separate unix shell. The following will load and align all CDK2 chains in two groups "bound" and "unbound". This may take some time depending on your hardware. To get close to Figure 5, use PyMol menu options to show as ribbons,and colour groups red and blue respectively. Smooth ribbon come with the Display>Quality>Maximum Quality. 

# Get started and load representative structure into PyMol
cdk2 = Pymol_Viz("clust_1HCK_A_95.fasta","cdk2")

# This bit requires the Piccolo database to be installed so I have commented it out and structure numbers lists are explicitly included instead.

## Group in to bound and unbound structures
#groups = cdk2.group_biggest_clusters(property="ppi")
#unbound = groups[0]
#bound = groups[1]

unbound = [152, 151, 147, 145, 159, 143, 161, 162, 163, 164, 138, 166, 167, 137, 136, 170, 171, 135, 173, 174, 175, 176, 177, 178, 134, 180, 133, 131, 183, 184, 185, 186, 129, 188, 189, 128, 127, 126, 193, 194, 195, 119, 116, 112, 108, 106, 105, 202, 104, 204, 101, 100, 96, 95, 209, 210, 211, 94, 93, 91, 90, 84, 217, 82, 219, 220, 221, 74, 67, 61, 225, 226, 227, 228, 58, 55, 231, 232, 233, 52, 46, 45, 237, 43, 239, 240, 42, 242, 243, 244, 245, 246, 41, 40, 249, 250, 251, 252, 253, 254, 255, 38, 37, 258, 36, 260, 35, 262, 33, 32, 265, 31, 30, 29, 27, 25, 23, 272, 22, 274, 21, 19, 277, 278, 279, 280, 16, 282, 283, 15, 12, 286, 11, 10, 289, 5, 4]
bound = [13, 261, 267, 141, 102, 49, 70, 247, 172, 156, 263, 144, 271, 114, 80, 79, 269, 110, 109, 72, 8, 66, 191, 165, 107, 236, 142, 65, 140, 64, 51, 181, 230, 207, 149, 71, 81, 155, 287, 50, 97, 76, 169, 89, 199, 44, 179, 266, 238, 121, 78, 264, 268, 99, 59, 168, 154, 288, 92, 88, 229, 7, 24, 73, 198, 57, 150, 157, 273, 201, 148, 125, 257, 9, 83, 182, 113, 118, 120, 248, 256, 103, 122, 153, 63, 215, 98, 223, 235, 28, 224, 234, 34, 216, 26, 281, 213, 241, 222, 276, 259, 200, 20, 14, 18, 6, 115, 187, 117, 206, 56, 54, 146, 139, 208, 123, 130, 160, 275, 48, 212, 87, 203, 17, 214, 77, 3, 132, 62, 60, 111, 270, 124, 69, 196, 192, 285, 86, 218, 284, 2, 75, 53, 47, 158, 39, 85, 68, 205, 190, 1, 197, 0]

# Convert the lists of alignment index numbers to chain ids
unbound_ids = cdk2.ids_for_groups(unbound)
bound_ids = cdk2.ids_for_groups(bound)

# Find preferred segment of structurally conserved residues. Try experimenting with the cutoff. The default value of 0.5 can be a bit high.
cdk2.colour_conserved_segments(0.1)

# Load all structures in each group into a PyMol group allowing them to be coloured separately
# They then aligned using your chosen segment. This will take a few minutes
cdk2.load_structures(id_list=unbound_ids, segment=[101,111], pymol_group="unbound")
cdk2.load_structures(id_list=bound_ids, segment=[101,111], pymol_group="bound")