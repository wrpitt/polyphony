#!/usr/bin/env python

from Polyphony.Trees import Tree
from Polyphony.Comparison_Matrices import Structure_Matrix
from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file, Properties
from Polyphony.Plotting import plot_alignment_properties
import numpy
    
## Main program

# Read alignment file and locations of data directories
filename, update = read_command_line_file("Plot a graph of each structures property values against sequence.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Cluster by protein-protein interactions
properties = Properties()
clust_array = properties.get_array("ppi", aligned, update)
structmat = Structure_Matrix(clust_array, update)
tree = Tree(structmat.data, structmat.get_labels())

# Group into active and inactive
groups = tree.biggest_left_right_others(1)
unbound = groups[0]
bound = groups[1]

print "Number of unbound and bound chains", len(unbound), len(bound)
unbound_ids = aligned.ids_for_groups(unbound)
num_unbound_structures = len(set([i[:4] for i in unbound_ids]))
bound_ids = aligned.ids_for_groups(bound)
num_bound_structures = len(set([i[:4] for i in bound_ids]))
print "Number of unbound and bound strictures", num_unbound_structures, num_bound_structures

# Get/calculate backbone conformation
array = properties.get_array("backbone", aligned, update)

# Calculate variability in unbound structures
unbound_array = array.subset(unbound)
unbound_variability = unbound_array.calculate_variability()

# Calculate variability in bound structures
bound_array = array.subset(bound)
bound_variability = bound_array.calculate_variability()

# Get Calpha bfactors
array = properties.get_array("bfactor", aligned, update)

# Calculate average in unbound structures
unbound_array = array.subset(unbound)
unbound_bfactors = unbound_array.average_per_residue()

# Calculate average in bound structures
bound_array = array.subset(bound)
bound_bfactors = bound_array.average_per_residue()

# Get crystal contacts
array = properties.get_array("crystal_contacts", aligned, update)
# Reduce contacts to 1 or 0
numpy.putmask(array.data,array.data>0,1.0)

# Calculate average in unbound structures
unbound_array = array.subset(unbound)
unbound_contacts = unbound_array.average_per_residue(sliding_window=1)

# Calculate average in bound structures
bound_array = array.subset(bound)
bound_contacts = bound_array.average_per_residue(sliding_window=1)

# Array for plotting
variability = numpy.vstack((unbound_variability, bound_variability))
#print "Sum variability, unbound and bound", numpy.sum(unbound_variability.data),  numpy.sum(bound_variability.data)
bfactors = numpy.vstack((unbound_bfactors, bound_bfactors))
#print "Sum avg bfactor, unbound and bound", numpy.sum(unbound_bfactors.data),  numpy.sum(bound_bfactors.data)
contacts = numpy.vstack((unbound_contacts, bound_contacts))
#print "Sum avg bfactor, unbound and bound", numpy.sum(unbound_bfactors.data),  numpy.sum(bound_bfactors.data)
composite = numpy.dstack((variability,bfactors,contacts))

xlabels = aligned.get_consensus_sequence()
#xlabels = None
plot_alignment_properties(composite, "var_vs_bfactors_unbound_bound", xlabels, ["Conformational Variability", "Average B-factors", "Crystal Contacts"], xlabel_font_size='large')
