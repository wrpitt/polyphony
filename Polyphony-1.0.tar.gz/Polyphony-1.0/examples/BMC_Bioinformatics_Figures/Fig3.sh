#!/usr/bin/sh

polyphony_plot_backbone_variation.py  -f clust_1HCK_A_95.fasta
