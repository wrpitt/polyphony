from Polyphony.Pymol import Pymol_Viz

# You need to do "pymol -R" in a separate unix shell.
 
# Get started and load representative structure into PyMol
cdk2 = Pymol_Viz("clust_1HCK_A_95.fasta","cdk2")
cdk2.colour_by_variability()
