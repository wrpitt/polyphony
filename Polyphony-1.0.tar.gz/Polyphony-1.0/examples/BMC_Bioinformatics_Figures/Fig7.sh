#!/usr/bin/sh

./Fig7.py  -f clust_1HCK_A_95.fasta

