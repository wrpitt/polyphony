#!/usr/bin/python

from Polyphony.Trees import Tree
from Polyphony.Comparison_Matrices import Structure_Matrix
from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file, Properties
from Polyphony.Plotting import plot_alignment_properties
import numpy, os
    
    
def get_subset_alignment(aligned, kinase_names, kinase) :
    """
    Produce a subset alignment and write to a file. Next time through just read in this file.
    """
    # The first time through, write to alignment file (so results can be stored for future use)
    filename = kinase_names[idx]+"_subset.fasta"
    sub_aligned = Structural_Alignment()
    try:
        # Read it in from previous run
        sub_aligned.add_alignment(filename)
    except IOError :
        # Create subset alignment
        subset = aligned.subset(kinase)
        # Write new file
        subset.write_alignment_file(filename)
        # Read it in again
        sub_aligned.add_alignment(filename)

    return sub_aligned

def calculate_intra_group_variability(sub_array, groups) :
    """
    Calculate average intra group variability and overall variability per alignment position
    """
    variability_list = []
    for group in groups :
        if len(group) > 2 :
            sub_sub_array = sub_array.subset(group)
            variability_list.append(sub_sub_array.calculate_variability())

    # Calculate average withion group variability at each alignment position
    if len(variability_list) > 0 :
        var_array = numpy.ma.array(variability_list)
        var_avg = numpy.ma.average(var_array,axis=0)
        vars.append(var_avg)
    else :
        vars.append(numpy.ma.zeros(sub_array.length))

    # Calculate overall variability at each alignment position
    overall_var = sub_array.calculate_variability()
    numpy.putmask(overall_var.data, overall_var.mask, 0.0)

    # Take the difference and store 
    #diffs.append(overall_var - var_avg)
    
    return vars, overall_var

    
## Main program

# Read alignment file and locations of data directories
filename, update = read_command_line_file("Plot a graph of each structures property values against sequence.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Cluster by sequence identity
properties = Properties()
clust_array = properties.get_array("sequence", aligned, update)
structmat = Structure_Matrix(clust_array, update)
tree = Tree(structmat.data, structmat.get_labels())

# Group into active and inactive
kinases = tree.flat_clusters(5)
kinase_names = ["CDK6","CDK2","ERK2","p38a","JNK3"] # same everytime I hope

# Get/calculate backbone conformation
array = properties.get_array("backbone", aligned, update)

idx = 0
vars = []
amps_list = []
p_list = []
# For each separate kinase
for kinase in kinases :
    
    # Create alignment of each kinase separately
    sub_aligned = get_subset_alignment(aligned, kinase_names, kinase)
    
    # Get backbone conformation array
    sub_array = properties.get_array("backbone", sub_aligned, update)
    
    # Calculate structure difference matrix
    structmat = Structure_Matrix(sub_array, update)
    
    # Calculate tree using hierarchical clustering
    ids = sub_aligned.ids()
    tree = Tree(structmat.data, ids, scale=False)
    
    # Group into very similar structures (by backbone conformation)
    groups = tree.flat_clusters(0.01)
    print kinase_names[idx]
    print "Number of groups:"
    print len(groups)
    print "Group sizes:"
    print [len(i) for i in groups]

    # Calculate amplifications
    amps = sub_array.calculate_group_variance(groups)
    amps_list.append(amps)
    
    # Calculate ANOVA
    p = sub_array.ANOVA(groups)
    p = numpy.max(p, axis=1)
    p_list.append(p)
    
    idx += 1

# Put into numpy array for plotting and add consensus over all kinases (average)
amps = numpy.array(amps_list)
consensus_amps = numpy.average(amps, axis=0)
amps = numpy.vstack((amps, consensus_amps))
amps = amps.T
amps.shape = 1, amps.shape[0], amps.shape[1]

# Do same for ANOVA probability
ps = numpy.ma.array(p_list)
consensus_ps = numpy.ma.average(ps, axis=0)
ps = numpy.ma.vstack((ps, consensus_ps))
ps = ps.T
ps.shape = 1, ps.shape[0], ps.shape[1]

# Create X-labels for each kinase from the sequence of the first structure in the alignment. Add consensus sequence (CDK2 usually because it has the most structures)
xlabels = []
for kinase in kinases :
    xlabels.append(list(aligned.get_sequence(kinase[0])))
xlabels.append(aligned.get_consensus_sequence())
xlabels = numpy.array(xlabels)

# Plot vertically stack graphs for eacn kinase and consensus
kinase_names.append("consensus")
xlabels = None
plot_alignment_properties(amps, "Variance", xlabels, kinase_names, yrange=(0.0,1.0), xlabel_font_size='large')
#plot_alignment_properties(ps, "Variance", xlabels, kinase_names, yrange=(0.0,1.0), xlabel_font_size='large')
