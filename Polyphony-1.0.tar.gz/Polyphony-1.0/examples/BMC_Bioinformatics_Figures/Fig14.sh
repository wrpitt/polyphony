#!/usr/bin/sh

./Fig14.py  -f -f cgmc_all.fasta

