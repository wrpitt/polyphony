#!/usr/bin/python

from Polyphony.Trees import Tree
from Polyphony.Comparison_Matrices import Structure_Matrix
from Polyphony.Structural_Alignment import Structural_Alignment
from Polyphony.Utils import read_command_line_file_and_property, Properties
from Polyphony.Plotting import plot_alignment_properties
from Polyphony.Stats import do_PCA_on_property_array, plot_PC1_vs_PC2

    
## Main program

# Read alignment file and locations of data directories
filename, update, property = read_command_line_file_and_property("Plot a graph of each structures property values against sequence.")

# Create structural alignment
aligned = Structural_Alignment()
aligned.add_alignment(filename)

# Get/calculate selected property
properties = Properties()
array = properties.get_array(property, aligned, update)

# This bit requires the Piccolo database to be installed so I have commented it out and structure numbers lists are explicitly included instead.
#
## Cluster by protein-protein interactions
#clust_array = properties.get_array("ppi", aligned, update)
#structmat = Structure_Matrix(clust_array)
#tree = Tree(structmat.data, structmat.get_labels())
#
## Group into active and inactive
#groups = tree.biggest_left_right_others(1)
#unbound = groups[0]
#bound = groups[1]

unbound = [152, 151, 147, 145, 159, 143, 161, 162, 163, 164, 138, 166, 167, 137, 136, 170, 171, 135, 173, 174, 175, 176, 177, 178, 134, 180, 133, 131, 183, 184, 185, 186, 129, 188, 189, 128, 127, 126, 193, 194, 195, 119, 116, 112, 108, 106, 105, 202, 104, 204, 101, 100, 96, 95, 209, 210, 211, 94, 93, 91, 90, 84, 217, 82, 219, 220, 221, 74, 67, 61, 225, 226, 227, 228, 58, 55, 231, 232, 233, 52, 46, 45, 237, 43, 239, 240, 42, 242, 243, 244, 245, 246, 41, 40, 249, 250, 251, 252, 253, 254, 255, 38, 37, 258, 36, 260, 35, 262, 33, 32, 265, 31, 30, 29, 27, 25, 23, 272, 22, 274, 21, 19, 277, 278, 279, 280, 16, 282, 283, 15, 12, 286, 11, 10, 289, 5, 4]
bound = [13, 261, 267, 141, 102, 49, 70, 247, 172, 156, 263, 144, 271, 114, 80, 79, 269, 110, 109, 72, 8, 66, 191, 165, 107, 236, 142, 65, 140, 64, 51, 181, 230, 207, 149, 71, 81, 155, 287, 50, 97, 76, 169, 89, 199, 44, 179, 266, 238, 121, 78, 264, 268, 99, 59, 168, 154, 288, 92, 88, 229, 7, 24, 73, 198, 57, 150, 157, 273, 201, 148, 125, 257, 9, 83, 182, 113, 118, 120, 248, 256, 103, 122, 153, 63, 215, 98, 223, 235, 28, 224, 234, 34, 216, 26, 281, 213, 241, 222, 276, 259, 200, 20, 14, 18, 6, 115, 187, 117, 206, 56, 54, 146, 139, 208, 123, 130, 160, 275, 48, 212, 87, 203, 17, 214, 77, 3, 132, 62, 60, 111, 270, 124, 69, 196, 192, 285, 86, 218, 284, 2, 75, 53, 47, 158, 39, 85, 68, 205, 190, 1, 197, 0]

# Plot property, coloured by group
xlabels = aligned.get_consensus_sequence()

# Calculate residue position loadings for given 1st principle component
scores, loadings = do_PCA_on_property_array(array, groups=[unbound,bound], show_plot="simple", show_labels=True)
